import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: {
          50: "#f1f4f9",
          100: "#dde4ef",
          200: "#c0cde1",
          300: "#96abcd",
          400: "#6683b4",
          500: "#46649b",
          600: "#354e80",
          700: "#2c4069",
          800: "#1e2d4d",
          900: "#16233c",
          950: "#0d1526",
        },
        forest: {
          50: "#f0f7f4",
          100: "#dbece3",
          200: "#b9d9c9",
          300: "#8dbfa8",
          400: "#5e9f84",
          500: "#3f8368",
          600: "#2d6952",
          700: "#245443",
          800: "#1e4336",
          900: "#19372d",
          950: "#0c1f19",
        },
      },
      boxShadow: {
        card: "0 1px 2px 0 rgb(16 24 40 / 0.04), 0 1px 3px 0 rgb(16 24 40 / 0.06)",
        pop: "0 8px 24px -4px rgb(16 24 40 / 0.12), 0 2px 6px -2px rgb(16 24 40 / 0.07)",
      },
    },
  },
  plugins: [],
};

export default config;
