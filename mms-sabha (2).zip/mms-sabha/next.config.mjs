import path from "node:path";
import { fileURLToPath } from "node:url";

const dir = path.dirname(fileURLToPath(import.meta.url));

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // The "@/..." alias is declared in tsconfig.json; it is repeated here so the
  // bundler resolves it the same way whatever editor or tooling is in use.
  webpack(config) {
    config.resolve.alias = {
      ...config.resolve.alias,
      "@": path.join(dir, "src"),
    };
    return config;
  },
  turbopack: {
    root: dir,
    resolveAlias: {
      "@": "./src",
    },
  },
};

export default nextConfig;
