# MMS Sabha — Contribution Management System

A cloud dashboard for a Palli committee to run its Kuri schemes: members,
monthly cash contributions, paid and pending status, receipts, WhatsApp
reminders, and financial reports. Amounts in Indian Rupees (₹), interface in
English.

Built with Next.js 15 (App Router), TypeScript, Tailwind CSS, Firebase
Authentication, Cloud Firestore, Recharts and Lucide icons. Everything used is
on a free tier.

---

## 1. Run it

```bash
npm install
npm run dev          # http://localhost:3000
```

With no Firebase keys the app starts in **local development mode**: it is fully
usable, but every record is kept in your browser's `localStorage` only. It is
not stored in any cloud database, not shared between devices or
administrators, and not backed up. A banner says so on every screen.

On first run, the login page asks you to create the first administrator
(President). Then: create a scheme → add members → assign them to the scheme →
record payments.

Other scripts:

```bash
npm run build        # production build
npm start            # serve the production build
npm run typecheck    # tsc --noEmit
npm run verify       # 48 checks over the financial rules (see §6)
```

---

## 2. Connect Firebase (the cloud mode)

1. Create a project at <https://console.firebase.google.com> — the free
   **Spark** plan is enough.
2. **Build → Authentication → Get started → Email/Password → Enable.**
3. **Build → Firestore Database → Create database** → production mode, region
   `asia-south1` (Mumbai) for the lowest latency from Kerala.
4. **Project settings → Your apps → Web app (`</>`)** → register, and copy the
   `firebaseConfig` values.
5. Copy the example env file and fill it in:

   ```bash
   cp .env.local.example .env.local
   ```

   ```
   NEXT_PUBLIC_FIREBASE_API_KEY=...
   NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
   NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-project
   NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.firebasestorage.app
   NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=...
   NEXT_PUBLIC_FIREBASE_APP_ID=...
   NEXT_PUBLIC_ORG_ID=default
   ```

   These `NEXT_PUBLIC_*` values are published to the browser by design — a
   Firebase web config is an identifier, not a secret. All real access control
   lives in the security rules. **Never** put a service account key in this
   project.

6. Deploy the rules and indexes:

   ```bash
   npm install -g firebase-tools
   firebase login
   firebase use --add            # select your project
   firebase deploy --only firestore:rules,firestore:indexes
   ```

7. Create the first administrator:
   - **Authentication → Users → Add user** — email and password.
   - Sign in to the app with it. While the organization has no
     `settings/settings` document, that first sign-in claims the President
     record and writes the settings document, which closes the window
     permanently. The rules allow this exactly once.

8. Restart `npm run dev`. The banner disappears and the app is on Firestore.

### Adding the other administrators

Under **Admin Management**, a President adds a name, email and role. That puts
the email on the access list. The person also needs a Firebase Authentication
account with the same email, created once in the Firebase console
(**Authentication → Users → Add user**). Until that account exists, the record
grants nothing.

Creating another person's sign-in credentials from inside the app is not
possible on the free plan: doing it in the browser would sign the current
administrator out, and doing it properly needs the Admin SDK in a Cloud
Function, which requires Firebase's paid **Blaze** plan. This is the one place
where the free tier costs a manual step. See §7.

---

## 3. Deploy to Vercel

```bash
npm install -g vercel
vercel            # first run links the project
vercel --prod
```

Then in **Vercel → Project → Settings → Environment Variables**, add the same
seven `NEXT_PUBLIC_*` variables for Production (and Preview if you use it), and
redeploy. Finally, add your Vercel domain under **Firebase → Authentication →
Settings → Authorized domains**, or sign-in will be rejected in production.

A git push to the connected branch deploys automatically.

---

## 4. What each screen does

| Screen | What it is for |
| --- | --- |
| **Dashboard** | Live figures — members, active schemes, total and current-month collection, total pending, paid and pending members. Monthly collection chart (collected against expected), paid-vs-pending split, recent transactions, upcoming due dates, recent audit activity. |
| **Kuri Schemes** | Create, edit and archive schemes; contribution amount, duration, start month, due day, member limit. Detail page shows the roster with each member's standing, and a month-by-month expected / collected / pending table. |
| **Members** | The register, with search and filters by status and scheme. Detail page shows per-scheme standing, outstanding balance and full payment history. |
| **Payments** | The collection sheet: pick a scheme and a month and see every member's state, with a one-click Record for anyone outstanding. |
| **Record Payment** | The payment entry form. Only months that are due and still open are offered, pre-filled with the exact outstanding amount. |
| **Payment History** | Every payment, filterable by date range, scheme, member and method, with running totals and exports. |
| **Pending Payments** | Every contribution that has fallen due and is not settled, with Remind and Record actions per row. |
| **WhatsApp Reminders** | Pending list, a personalised message per member that you review and can edit, then open in WhatsApp. Includes a log of messages prepared. |
| **Reports** | Daily, monthly, yearly, scheme-wise, member-wise, pending and transaction reports, with date / scheme / member filters and CSV, Excel, PDF and print output. |
| **Admin Management** | The access list: add administrators, change roles, disable accounts. |
| **Settings** | Organization name, logo, contact details, currency, scheme defaults, reminder day, reminder message template, receipt prefix. |

### Receipts

Every payment gets a sequential receipt number (`RCPT-2026-0001`, prefix
configurable). The receipt page prints on its own, without app chrome, and
shows the audit history of that payment underneath.

---

## 5. How the money is protected

These rules are enforced in three places: in the form, in the repository
before any write, and again in `firestore.rules` — so a client that bypasses
the interface still cannot corrupt the ledger.

- **No payment is ever created or marked paid automatically.** Nothing in the
  codebase writes a payment except an administrator submitting the form.
- **No fabricated data.** There is no seed script and no demo data. Every
  figure on every screen is computed from records that were entered.
- **No duplicate collection.** Each `(scheme, member, month)` has one
  `periodLedger` document holding the total collected. A payment and its ledger
  entry are written in a single Firestore transaction, so two administrators
  recording the same contribution at the same moment cannot both succeed.
- **No over-collection.** A month already settled in full is refused; a top-up
  larger than the balance is refused. Part payments are allowed and add up.
- **No payment is ever deleted.** There is no delete action anywhere. A wrong
  figure is corrected, a reason is required, and the original values are kept
  in `paymentAuditLogs`. A corrected payment is flagged as such.
- **Every record is attributed.** Who received the cash, who entered the
  record, when, and who corrected it and why. `createdByUid` must equal the
  caller's own uid, so it cannot be forged.
- **A correction cannot move money.** The member, scheme and contribution
  month of an existing payment can never change — only the figures.
- **The contribution amount locks.** Once a scheme has payments against it,
  its monthly amount can no longer be edited.
- **Members and schemes are archived, not deleted,** so history stays
  meaningful.

### Roles

| | President | Treasurer | Additional Admin |
| --- | --- | --- | --- |
| Record payments | ✓ | ✓ | ✓ |
| Correct payments | ✓ | ✓ | |
| Members | ✓ | ✓ | ✓ |
| Schemes | ✓ | ✓ | |
| Reports and reminders | ✓ | ✓ | ✓ |
| Settings | ✓ | ✓ | |
| Manage administrators | ✓ | | |

Ordinary members have no access at all — there is no member-facing login. The
rules deny every read and write to anyone whose email is not on the access
list with `active: true`, and the last active President cannot be disabled, so
the dashboard cannot be locked out.

---

## 6. Verification

`npm run verify` runs 48 checks against the repository and the calculation
module — duplicate refusal, over-collection refusal, part payments, the period
ledger, pending maths, corrections and the audit trail, archiving, the amount
lock, and administrator rules. It prints the actual refusal message for each
rejected write.

```
48 passed, 0 failed
```

The build and all 22 routes were also checked (`npm run build`, then every
route served over HTTP).

---

## 7. What would need a paid service

Everything in the app works on free tiers. Three things would not:

1. **Automatic WhatsApp sending.** This app prepares a personalised message
   and opens WhatsApp with it filled in; an administrator presses send. Sending
   without a human needs the official WhatsApp Business API through a provider
   such as Meta, Twilio or Gupshup — paid, and it requires template approval.
   The app never claims a message was delivered, because it cannot know.
2. **Creating other administrators' credentials from inside the app.** Needs
   the Firebase Admin SDK in a Cloud Function → Blaze plan. Today an Auth user
   is created once in the console; see §2.
3. **Scheduled server-side reminders on the 10th.** The reminder day is a
   schedule the dashboard shows and works from; firing it unattended needs
   Cloud Scheduler / Cloud Functions → Blaze plan. A free alternative is a
   Vercel Cron job on a paid-free hobby plan calling a route that emails the
   committee, which is not set up here.

Firestore's free tier (50k reads, 20k writes a day) is far above what a Palli
of a few hundred members generates.

---

## 8. Project layout

```
src/
  app/
    layout.tsx, providers.tsx, globals.css, page.tsx, not-found.tsx
    login/page.tsx
    (app)/                       protected dashboard routes
      layout.tsx                 AppShell: auth guard, sidebar, top bar
      dashboard/ schemes/ members/ payments/ history/
      pending/ reminders/ reports/ admins/ settings/
  components/
    layout/   Sidebar, Topbar, AppShell, nav
    ui/       Card, Button, Field, Input, Select, Table, Badge, Dialog,
              EmptyState, Alert, PageHeader, StatCard, Toast
    forms/    SchemeForm, MemberForm
    charts/   Recharts wrappers
    ExportBar, NoAccess
  lib/
    types.ts         domain model, roles and capabilities
    kuri.ts          all business maths (pure, no I/O)
    format.ts        ₹ and date formatting, WhatsApp number normalisation
    export.ts        CSV / Excel / PDF
    firebase.ts      the only place env vars are read
    DataProvider.tsx loads the snapshot, runs writes, refreshes
    auth/AuthProvider.tsx
    data/
      types.ts       the Repository contract both modes implement
      validate.ts    the financial rules
      firestore.ts   Cloud Firestore implementation (transactions)
      local.ts       local-mode implementation
scripts/verify.mts   the 48-check suite
firestore.rules      server-side access control
firestore.indexes.json
```

Firestore layout — one tree per organization, so one deployment can serve a
different Palli by changing `NEXT_PUBLIC_ORG_ID`:

```
organizations/{orgId}/
  settings/settings
  users/{emailLowercase}        role + active flag (the access list)
  members/{memberId}
  schemes/{schemeId}
  schemeMemberships/{schemeId__memberId}
  payments/{paymentId}
  periodLedger/{schemeId__memberId__period}
  paymentAuditLogs/{logId}
  reminders/{reminderId}
```

---

## 9. Configuring it for a different organization

Nothing in the source needs editing. Under **Settings**: organization name,
logo, contact details, currency symbol, default contribution amount, default
duration, default members per scheme, default due day, reminder day, reminder
message template and receipt prefix. Each scheme then overrides the amount,
duration, due day and member limit for itself. To run a second organization
from the same codebase, deploy again with a different `NEXT_PUBLIC_ORG_ID`.
