/**
 * End-to-end check of the financial rules, run against the local repository
 * (which shares its validation and ledger logic with the Firestore one).
 *
 *   npx tsx scripts/verify.ts
 */

/* eslint-disable no-console */

// Minimal localStorage so the local repository can run outside a browser.
class MemoryStorage {
  private map = new Map<string, string>();
  getItem(k: string): string | null {
    return this.map.has(k) ? this.map.get(k)! : null;
  }
  setItem(k: string, v: string): void {
    this.map.set(k, v);
  }
  removeItem(k: string): void {
    this.map.delete(k);
  }
}
(globalThis as unknown as { window: unknown }).window = { localStorage: new MemoryStorage() };

const { LocalRepository } = await import("../src/lib/data/local.js");
const { pendingRows, memberStandings, dashboardStats, addMonths, schemePeriods } = await import(
  "../src/lib/kuri.js"
);

let passed = 0;
let failed = 0;

function check(label: string, condition: boolean, detail = ""): void {
  if (condition) {
    passed += 1;
    console.log(`  PASS  ${label}`);
  } else {
    failed += 1;
    console.log(`  FAIL  ${label}${detail ? ` — ${detail}` : ""}`);
  }
}

async function expectRejection(label: string, fn: () => Promise<unknown>): Promise<void> {
  try {
    await fn();
    check(label, false, "the write was accepted but should have been rejected");
  } catch (err) {
    check(label, true);
    console.log(`        → ${err instanceof Error ? err.message : String(err)}`);
  }
}

const repo = new LocalRepository("default");
const actor = { uid: "usr_test", name: "Test Treasurer" };

console.log("\nPure calculations");
check("addMonths rolls over the year", addMonths("2026-11", 3) === "2027-02");
check("addMonths goes backwards", addMonths("2026-01", -1) === "2025-12");
check("a 12-month scheme has 12 periods", schemePeriods({
  id: "x",
  orgId: "default",
  name: "x",
  monthlyAmount: 5000,
  durationMonths: 12,
  startMonth: "2026-01",
  dueDay: 10,
  memberLimit: 60,
  status: "active",
  notes: "",
  createdAt: "",
  updatedAt: "",
}).length === 12);

console.log("\nSetup");
const scheme = await repo.createScheme(
  {
    name: "MMS Sabha 2026",
    monthlyAmount: 5000,
    durationMonths: 12,
    startMonth: "2026-01",
    dueDay: 10,
    memberLimit: 2,
    status: "active",
    notes: "",
  },
  actor,
);
check("scheme created", scheme.monthlyAmount === 5000);

const amina = await repo.createMember(
  {
    memberCode: "PK-0001",
    fullName: "Amina Rasheed",
    phone: "9847012345",
    address: "Kannur",
    joiningDate: "2026-01-01",
    status: "active",
    notes: "",
  },
  actor,
);
const basheer = await repo.createMember(
  {
    memberCode: "PK-0002",
    fullName: "Basheer Koya",
    phone: "9847099999",
    address: "Thalassery",
    joiningDate: "2026-01-01",
    status: "active",
    notes: "",
  },
  actor,
);
check("two members created", Boolean(amina.id && basheer.id));

await expectRejection("duplicate Member ID is refused", () =>
  repo.createMember(
    {
      memberCode: "PK-0001",
      fullName: "Someone Else",
      phone: "9000000000",
      address: "",
      joiningDate: "2026-01-01",
      status: "active",
      notes: "",
    },
    actor,
  ),
);

await expectRejection("same name and phone is refused as a duplicate person", () =>
  repo.createMember(
    {
      memberCode: "PK-0003",
      fullName: "Amina Rasheed",
      phone: "98470 12345",
      address: "",
      joiningDate: "2026-01-01",
      status: "active",
      notes: "",
    },
    actor,
  ),
);

console.log("\nScheme assignment");
await repo.assignMember(scheme.id, amina.id, "2026-01-01");
await repo.assignMember(scheme.id, basheer.id, "2026-01-01");
check("both members assigned", (await repo.load()).memberships.filter((m) => m.active).length === 2);

await expectRejection("assigning the same member twice is refused", () =>
  repo.assignMember(scheme.id, amina.id, "2026-01-01"),
);

const carried = await repo.createMember(
  {
    memberCode: "PK-0004",
    fullName: "Suhra Ummer",
    phone: "9847011111",
    address: "",
    joiningDate: "2026-02-01",
    status: "active",
    notes: "",
  },
  actor,
);
await expectRejection("the member limit is enforced", () =>
  repo.assignMember(scheme.id, carried.id, "2026-02-01"),
);

console.log("\nRecording payments");
const base = {
  schemeId: scheme.id,
  paidOn: "2026-01-08",
  method: "cash" as const,
  receivedBy: "Treasurer",
  referenceNo: "RB-11",
  notes: "",
};

const pay1 = await repo.recordPayment(
  { ...base, memberId: amina.id, period: "2026-01", amount: 5000 },
  actor,
);
check("payment recorded with a receipt number", pay1.receiptNo.includes("RCPT-"));
check("the recording administrator is stamped on it", pay1.createdByName === actor.name);

await expectRejection("paying a fully settled month again is refused", () =>
  repo.recordPayment({ ...base, memberId: amina.id, period: "2026-01", amount: 5000 }, actor),
);

await expectRejection("more than the monthly contribution is refused", () =>
  repo.recordPayment({ ...base, memberId: basheer.id, period: "2026-01", amount: 6000 }, actor),
);

await expectRejection("a month outside the scheme is refused", () =>
  repo.recordPayment({ ...base, memberId: basheer.id, period: "2027-06", amount: 5000 }, actor),
);

await expectRejection("a fractional amount is refused", () =>
  repo.recordPayment({ ...base, memberId: basheer.id, period: "2026-02", amount: 2500.5 }, actor),
);

await expectRejection("a payment dated before the contribution month is refused", () =>
  repo.recordPayment(
    { ...base, paidOn: "2025-12-31", memberId: basheer.id, period: "2026-02", amount: 5000 },
    actor,
  ),
);

await expectRejection("a member not in the scheme cannot pay into it", () =>
  repo.recordPayment({ ...base, memberId: carried.id, period: "2026-01", amount: 5000 }, actor),
);

console.log("\nPart payments");
const part1 = await repo.recordPayment(
  { ...base, memberId: basheer.id, period: "2026-01", amount: 2000 },
  actor,
);
check("a part payment is accepted", part1.amount === 2000);

await expectRejection("a top-up beyond the balance is refused", () =>
  repo.recordPayment({ ...base, memberId: basheer.id, period: "2026-01", amount: 4000 }, actor),
);

await repo.recordPayment(
  { ...base, memberId: basheer.id, period: "2026-01", amount: 3000 },
  actor,
);
let snap = await repo.load();
const ledger = snap.ledgers.find(
  (l) => l.memberId === basheer.id && l.period === "2026-01",
);
check("the period ledger totals both part payments", ledger?.paidAmount === 5000, String(ledger?.paidAmount));

console.log("\nPending calculation");
snap = await repo.load();
const pending = pendingRows({
  members: snap.members,
  schemes: snap.schemes,
  memberships: snap.memberships,
  ledgers: snap.ledgers,
  asOfPeriod: "2026-03",
});
// Both members owe Feb and Mar; Jan is settled for both.
check("January is not pending for anyone", !pending.some((r) => r.period === "2026-01"));
check(
  "February and March are pending for both members",
  pending.filter((r) => r.period === "2026-02").length === 2 &&
    pending.filter((r) => r.period === "2026-03").length === 2,
);
check(
  "pending total is correct",
  pending.reduce((s, r) => s + r.pendingAmount, 0) === 20000,
  String(pending.reduce((s, r) => s + r.pendingAmount, 0)),
);
check(
  "a month that has not started is not pending",
  !pending.some((r) => r.period > "2026-03"),
);

const standing = memberStandings(amina.id, {
  members: snap.members,
  schemes: snap.schemes,
  memberships: snap.memberships,
  ledgers: snap.ledgers,
  asOfPeriod: "2026-03",
});
check("member standing shows the right outstanding", standing[0]?.outstanding === 10000);
check("member standing shows what was paid", standing[0]?.totalPaid === 5000);

const stats = dashboardStats(
  snap.members,
  snap.schemes,
  snap.memberships,
  snap.payments,
  snap.ledgers,
  "2026-03",
);
check("total collection matches the payments", stats.totalCollection === 10000);
check("pending total matches", stats.totalPending === 20000);

console.log("\nCorrections and the audit trail");
await expectRejection("a correction without a reason is refused", () =>
  repo.editPayment(
    pay1.id,
    {
      amount: 4000,
      paidOn: "2026-01-08",
      method: "cash",
      receivedBy: "Treasurer",
      referenceNo: "",
      notes: "",
      reason: "",
    },
    actor,
  ),
);

await repo.editPayment(
  pay1.id,
  {
    amount: 4000,
    paidOn: "2026-01-09",
    method: "cash",
    receivedBy: "Treasurer",
    referenceNo: "RB-11",
    notes: "Recounted at the meeting",
    reason: "Entered as 5000 but 4000 was received",
  },
  actor,
);
snap = await repo.load();
const corrected = snap.payments.find((p) => p.id === pay1.id);
check("the corrected amount is stored", corrected?.amount === 4000);
check("the record is flagged as corrected", corrected?.corrected === true);
check("the corrector is recorded", corrected?.updatedByName === actor.name);

const logs = snap.auditLogs.filter((l) => l.paymentId === pay1.id);
check("two audit entries exist for this payment", logs.length === 2);
const updateLog = logs.find((l) => l.action === "update");
check("the original amount is preserved in the audit log", updateLog?.before?.amount === 5000);
check("the reason is preserved", (updateLog?.reason ?? "").includes("4000 was received"));

const amendedLedger = (await repo.load()).ledgers.find(
  (l) => l.memberId === amina.id && l.period === "2026-01",
);
check("the ledger follows the correction", amendedLedger?.paidAmount === 4000);

snap = await repo.load();
const afterCorrection = pendingRows({
  members: snap.members,
  schemes: snap.schemes,
  memberships: snap.memberships,
  ledgers: snap.ledgers,
  asOfPeriod: "2026-03",
});
check(
  "January becomes pending again for the corrected member",
  afterCorrection.some((r) => r.memberId === amina.id && r.period === "2026-01" && r.pendingAmount === 1000),
);

console.log("\nArchiving");
await repo.setSchemeStatus(scheme.id, "archived", actor);
await expectRejection("an archived scheme cannot take payments", () =>
  repo.recordPayment({ ...base, memberId: basheer.id, period: "2026-02", amount: 5000 }, actor),
);
await repo.setSchemeStatus(scheme.id, "active", actor);

await expectRejection("removing a member who has paid is refused", () =>
  repo.unassignMember(scheme.id, amina.id),
);

await repo.setMemberStatus(amina.id, "archived", actor);
snap = await repo.load();
check(
  "archiving a member keeps every payment",
  snap.payments.filter((p) => p.memberId === amina.id).length === 1,
);
check(
  "an archived member drops out of the pending list",
  !pendingRows({
    members: snap.members,
    schemes: snap.schemes,
    memberships: snap.memberships,
    ledgers: snap.ledgers,
    asOfPeriod: "2026-03",
  }).some((r) => r.memberId === amina.id),
);

console.log("\nScheme amount lock");
await expectRejection("the monthly amount cannot change once money is in", () =>
  repo.updateScheme(scheme.id, { monthlyAmount: 6000 }, actor),
);

console.log("\nAdministrators");
await repo.bootstrapFirstAdmin({ name: "President", email: "pres@example.com", password: "secret1" });
await repo.createAdmin(
  { name: "Treasurer", email: "treas@example.com", role: "treasurer", password: "secret2" },
  actor,
);
await expectRejection("a duplicate administrator email is refused", () =>
  repo.createAdmin(
    { name: "Again", email: "PRES@example.com", role: "admin", password: "secret3" },
    actor,
  ),
);
await expectRejection("a short password is refused", () =>
  repo.createAdmin({ name: "Weak", email: "w@example.com", role: "admin", password: "123" }, actor),
);
const presId = (await repo.load()).users.find((u) => u.email === "pres@example.com")!.id;
await expectRejection("the last President cannot be disabled", () =>
  repo.updateAdmin(presId, { active: false }, actor),
);
await expectRejection("wrong credentials are refused", () =>
  repo.localSignIn("pres@example.com", "wrong"),
);
const signedIn = await repo.localSignIn("pres@example.com", "secret1");
check("correct credentials sign in", signedIn.role === "president");

console.log(`\n${passed} passed, ${failed} failed\n`);
process.exit(failed === 0 ? 0 : 1);
