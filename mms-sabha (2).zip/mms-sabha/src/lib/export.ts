/**
 * Report export. CSV and Excel are generated in the browser; PDF uses jsPDF.
 * All three are free, with no external service involved.
 *
 * The heavy libraries are imported dynamically so they are only downloaded
 * when an administrator actually exports something.
 */

export interface Column<T> {
  header: string;
  /** Value used for CSV/Excel/PDF cells. */
  value: (row: T) => string | number;
  align?: "left" | "right";
}

function download(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function csvCell(value: string | number): string {
  const s = String(value ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function exportCSV<T>(rows: T[], columns: Column<T>[], filename: string): void {
  const head = columns.map((c) => csvCell(c.header)).join(",");
  const body = rows.map((r) => columns.map((c) => csvCell(c.value(r))).join(",")).join("\n");
  // BOM so Excel opens ₹ and Malayalam names correctly.
  download(new Blob([`﻿${head}\n${body}`], { type: "text/csv;charset=utf-8" }), `${filename}.csv`);
}

export async function exportXLSX<T>(
  rows: T[],
  columns: Column<T>[],
  filename: string,
  sheetName = "Report",
): Promise<void> {
  const XLSX = await import("xlsx");
  const data = [
    columns.map((c) => c.header),
    ...rows.map((r) => columns.map((c) => c.value(r))),
  ];
  const sheet = XLSX.utils.aoa_to_sheet(data);
  sheet["!cols"] = columns.map((c) => ({ wch: Math.max(12, c.header.length + 4) }));
  const book = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(book, sheet, sheetName.slice(0, 31));
  const out = XLSX.write(book, { bookType: "xlsx", type: "array" }) as ArrayBuffer;
  download(
    new Blob([out], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    }),
    `${filename}.xlsx`,
  );
}

export async function exportPDF<T>(
  rows: T[],
  columns: Column<T>[],
  filename: string,
  meta: { title: string; subtitle?: string; organization: string },
): Promise<void> {
  const { jsPDF } = await import("jspdf");
  const autoTable = (await import("jspdf-autotable")).default;

  const doc = new jsPDF({ orientation: columns.length > 6 ? "landscape" : "portrait" });

  doc.setFontSize(14);
  doc.text(meta.organization, 14, 16);
  doc.setFontSize(11);
  doc.text(meta.title, 14, 23);
  if (meta.subtitle) {
    doc.setFontSize(9);
    doc.setTextColor(110);
    doc.text(meta.subtitle, 14, 29);
    doc.setTextColor(0);
  }

  autoTable(doc, {
    startY: meta.subtitle ? 34 : 28,
    head: [columns.map((c) => c.header)],
    body: rows.map((r) => columns.map((c) => String(c.value(r)))),
    styles: { fontSize: 8, cellPadding: 2 },
    headStyles: { fillColor: [30, 45, 77], textColor: 255, fontStyle: "bold" },
    alternateRowStyles: { fillColor: [247, 249, 252] },
    columnStyles: Object.fromEntries(
      columns.map((c, i) => [i, { halign: c.align ?? "left" }]),
    ),
    margin: { left: 14, right: 14 },
  });

  const generated = new Date().toLocaleString("en-IN");
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i += 1) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(130);
    doc.text(
      `Generated ${generated}  ·  Page ${i} of ${pages}`,
      14,
      doc.internal.pageSize.getHeight() - 8,
    );
  }

  doc.save(`${filename}.pdf`);
}

/** "pending-payments-2026-11-15" */
export function stamp(base: string): string {
  return `${base}-${new Date().toISOString().slice(0, 10)}`;
}
