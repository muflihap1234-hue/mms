"use client";

/**
 * Loads the organization's records once and keeps them in memory, so every
 * screen computes its figures from the same set of real records.
 *
 * Every write goes through the repository (which validates, maintains the
 * period ledger and writes the audit trail), then re-reads the snapshot. At
 * Palli scale — a handful of schemes, tens of members, a few hundred payments
 * a year — this is both simpler and faster than per-screen queries.
 */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

import { getRepository } from "./data";
import { DomainError, type Repository, type Snapshot } from "./data/types";
import { defaultSettings } from "./types";
import { ORG_ID } from "./firebase";
import { useAuth } from "./auth/AuthProvider";
import type { Actor } from "./data/types";

interface DataState {
  repo: Repository;
  snapshot: Snapshot;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  /** Runs a repository write, then refreshes. Throws a readable message. */
  run: <T>(fn: (repo: Repository, actor: Actor) => Promise<T>) => Promise<T>;
}

const emptySnapshot: Snapshot = {
  users: [],
  members: [],
  schemes: [],
  memberships: [],
  payments: [],
  ledgers: [],
  auditLogs: [],
  reminders: [],
  settings: defaultSettings(ORG_ID),
};

const DataContext = createContext<DataState | null>(null);

export function readableError(err: unknown): string {
  if (err instanceof DomainError) return err.message;
  if (err && typeof err === "object" && "code" in err) {
    const code = String((err as { code: unknown }).code);
    if (code.includes("permission-denied")) {
      return "Your account is not allowed to make this change.";
    }
    if (code.includes("unavailable") || code.includes("network")) {
      return "Could not reach the database. Check your connection and try again.";
    }
    if (code.includes("failed-precondition")) {
      return "The record changed while you were editing it. Reload and try again.";
    }
  }
  if (err instanceof Error) return err.message;
  return "Something went wrong. Please try again.";
}

export function DataProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const repo = useMemo(() => getRepository(), []);
  const [snapshot, setSnapshot] = useState<Snapshot>(emptySnapshot);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const next = await repo.load();
      setSnapshot(next);
      setError(null);
    } catch (err) {
      setError(readableError(err));
    } finally {
      setLoading(false);
    }
  }, [repo]);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    void refresh();
  }, [user, refresh]);

  const run = useCallback(
    async <T,>(fn: (repo: Repository, actor: Actor) => Promise<T>): Promise<T> => {
      if (!user) throw new DomainError("not_signed_in", "You are not signed in.");
      const actor: Actor = { uid: user.id, name: user.name };
      try {
        const result = await fn(repo, actor);
        await refresh();
        return result;
      } catch (err) {
        throw new Error(readableError(err));
      }
    },
    [repo, refresh, user],
  );

  const value = useMemo<DataState>(
    () => ({ repo, snapshot, loading, error, refresh, run }),
    [repo, snapshot, loading, error, refresh, run],
  );

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export function useData(): DataState {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error("useData must be used inside <DataProvider>.");
  return ctx;
}

/** Convenience lookups used across pages. */
export function useLookups() {
  const { snapshot } = useData();
  return useMemo(() => {
    const memberById = new Map(snapshot.members.map((m) => [m.id, m]));
    const schemeById = new Map(snapshot.schemes.map((s) => [s.id, s]));
    return {
      memberById,
      schemeById,
      memberName: (id: string) => memberById.get(id)?.fullName ?? "Unknown member",
      memberCode: (id: string) => memberById.get(id)?.memberCode ?? "—",
      schemeName: (id: string) => schemeById.get(id)?.name ?? "Unknown scheme",
      currency: snapshot.settings.currencySymbol || "₹",
    };
  }, [snapshot]);
}
