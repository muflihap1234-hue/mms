/**
 * Pure business logic for Kuri schemes.
 *
 * Nothing in this file touches the database or React. Every figure the
 * dashboard and the reports show is produced here from real records, so the
 * same inputs always give the same numbers.
 */

import type {
  Member,
  Payment,
  PeriodLedger,
  Scheme,
  SchemeMembership,
} from "./types";
import { ledgerId } from "./types";

/** Adds `n` months to a "YYYY-MM" period. */
export function addMonths(period: string, n: number): string {
  const [y, m] = period.split("-").map(Number);
  if (!y || !m) return period;
  const total = y * 12 + (m - 1) + n;
  const ny = Math.floor(total / 12);
  const nm = (total % 12) + 1;
  return `${ny}-${String(nm).padStart(2, "0")}`;
}

export function monthsBetween(from: string, to: string): number {
  const [fy, fm] = from.split("-").map(Number);
  const [ty, tm] = to.split("-").map(Number);
  if (!fy || !fm || !ty || !tm) return 0;
  return ty * 12 + tm - (fy * 12 + fm);
}

/** Every contribution period of a scheme, in order. */
export function schemePeriods(scheme: Scheme): string[] {
  const out: string[] = [];
  for (let i = 0; i < scheme.durationMonths; i += 1) {
    out.push(addMonths(scheme.startMonth, i));
  }
  return out;
}

export function schemeEndMonth(scheme: Scheme): string {
  return addMonths(scheme.startMonth, Math.max(0, scheme.durationMonths - 1));
}

export function schemeDueDate(scheme: Scheme, period: string): string {
  return `${period}-${String(scheme.dueDay).padStart(2, "0")}`;
}

/**
 * Periods of a scheme that are already due as of `asOfPeriod` (inclusive).
 * A period that has not started yet is not pending — it is simply not due.
 */
export function duePeriods(scheme: Scheme, asOfPeriod: string): string[] {
  return schemePeriods(scheme).filter((p) => p <= asOfPeriod);
}

export function schemeTotalValue(scheme: Scheme): number {
  return scheme.monthlyAmount * scheme.durationMonths;
}

export interface PendingRow {
  schemeId: string;
  schemeName: string;
  memberId: string;
  memberCode: string;
  memberName: string;
  phone: string;
  period: string;
  dueAmount: number;
  paidAmount: number;
  pendingAmount: number;
  dueDate: string;
}

export interface MemberSchemeStanding {
  schemeId: string;
  schemeName: string;
  monthlyAmount: number;
  periodsDue: number;
  totalDue: number;
  totalPaid: number;
  outstanding: number;
  /** Periods already due with nothing or only part collected. */
  pendingPeriods: string[];
  /** Periods not yet started. */
  upcomingPeriods: string[];
}

export interface LedgerIndex {
  get(schemeId: string, memberId: string, period: string): PeriodLedger | undefined;
}

export function buildLedgerIndex(ledgers: PeriodLedger[]): LedgerIndex {
  const map = new Map<string, PeriodLedger>();
  for (const l of ledgers) map.set(ledgerId(l.schemeId, l.memberId, l.period), l);
  return {
    get: (schemeId, memberId, period) => map.get(ledgerId(schemeId, memberId, period)),
  };
}

/** Rebuilds the ledger from raw payments. Used by local mode and by repair. */
export function ledgersFromPayments(
  payments: Payment[],
  schemes: Scheme[],
  orgId: string,
): PeriodLedger[] {
  const schemeById = new Map(schemes.map((s) => [s.id, s]));
  const map = new Map<string, PeriodLedger>();
  for (const p of payments) {
    const key = ledgerId(p.schemeId, p.memberId, p.period);
    const existing = map.get(key);
    if (existing) {
      existing.paidAmount += p.amount;
      existing.paymentIds.push(p.id);
      continue;
    }
    map.set(key, {
      id: key,
      orgId,
      schemeId: p.schemeId,
      memberId: p.memberId,
      period: p.period,
      dueAmount: schemeById.get(p.schemeId)?.monthlyAmount ?? p.amount,
      paidAmount: p.amount,
      paymentIds: [p.id],
      updatedAt: p.updatedAt ?? p.createdAt,
    });
  }
  return [...map.values()];
}

export interface StandingInput {
  members: Member[];
  schemes: Scheme[];
  memberships: SchemeMembership[];
  ledgers: PeriodLedger[];
  asOfPeriod: string;
}

/** Every unpaid or part-paid period that is already due, one row each. */
export function pendingRows(input: StandingInput): PendingRow[] {
  const { members, schemes, memberships, ledgers, asOfPeriod } = input;
  const index = buildLedgerIndex(ledgers);
  const memberById = new Map(members.map((m) => [m.id, m]));
  const rows: PendingRow[] = [];

  for (const scheme of schemes) {
    if (scheme.status === "archived") continue;
    const periods = duePeriods(scheme, asOfPeriod);
    if (periods.length === 0) continue;

    const active = memberships.filter((ms) => ms.schemeId === scheme.id && ms.active);
    for (const ms of active) {
      const member = memberById.get(ms.memberId);
      if (!member || member.status === "archived") continue;

      for (const period of periods) {
        // A member who joined after a period started is not liable for it.
        if (ms.joinedAt.slice(0, 7) > period) continue;
        const paid = index.get(scheme.id, member.id, period)?.paidAmount ?? 0;
        const pending = scheme.monthlyAmount - paid;
        if (pending <= 0) continue;
        rows.push({
          schemeId: scheme.id,
          schemeName: scheme.name,
          memberId: member.id,
          memberCode: member.memberCode,
          memberName: member.fullName,
          phone: member.phone,
          period,
          dueAmount: scheme.monthlyAmount,
          paidAmount: paid,
          pendingAmount: pending,
          dueDate: schemeDueDate(scheme, period),
        });
      }
    }
  }

  rows.sort((a, b) =>
    a.period === b.period ? a.memberName.localeCompare(b.memberName) : a.period < b.period ? -1 : 1,
  );
  return rows;
}

export function memberStandings(
  memberId: string,
  input: StandingInput,
): MemberSchemeStanding[] {
  const { schemes, memberships, ledgers, asOfPeriod } = input;
  const index = buildLedgerIndex(ledgers);
  const mine = memberships.filter((ms) => ms.memberId === memberId && ms.active);
  const out: MemberSchemeStanding[] = [];

  for (const ms of mine) {
    const scheme = schemes.find((s) => s.id === ms.schemeId);
    if (!scheme) continue;
    const all = schemePeriods(scheme);
    const liable = all.filter((p) => p >= ms.joinedAt.slice(0, 7));
    const due = liable.filter((p) => p <= asOfPeriod);
    const upcoming = liable.filter((p) => p > asOfPeriod);

    let totalPaid = 0;
    const pendingPeriods: string[] = [];
    for (const p of liable) {
      const paid = index.get(scheme.id, memberId, p)?.paidAmount ?? 0;
      totalPaid += paid;
      if (p <= asOfPeriod && paid < scheme.monthlyAmount) pendingPeriods.push(p);
    }
    const totalDue = due.length * scheme.monthlyAmount;

    out.push({
      schemeId: scheme.id,
      schemeName: scheme.name,
      monthlyAmount: scheme.monthlyAmount,
      periodsDue: due.length,
      totalDue,
      totalPaid,
      outstanding: Math.max(0, totalDue - totalPaid),
      pendingPeriods,
      upcomingPeriods: upcoming,
    });
  }
  return out;
}

export interface DashboardStats {
  totalMembers: number;
  activeSchemes: number;
  totalCollection: number;
  currentMonthCollection: number;
  totalPending: number;
  paidMembersThisMonth: number;
  pendingMembersThisMonth: number;
}

export function dashboardStats(
  members: Member[],
  schemes: Scheme[],
  memberships: SchemeMembership[],
  payments: Payment[],
  ledgers: PeriodLedger[],
  asOfPeriod: string,
): DashboardStats {
  const pending = pendingRows({ members, schemes, memberships, ledgers, asOfPeriod });
  const thisMonthPending = new Set(
    pending.filter((r) => r.period === asOfPeriod).map((r) => r.memberId),
  );
  const index = buildLedgerIndex(ledgers);

  const liableThisMonth = new Set<string>();
  for (const scheme of schemes) {
    if (scheme.status === "archived") continue;
    if (!duePeriods(scheme, asOfPeriod).includes(asOfPeriod)) continue;
    for (const ms of memberships) {
      if (ms.schemeId !== scheme.id || !ms.active) continue;
      if (ms.joinedAt.slice(0, 7) > asOfPeriod) continue;
      const paid = index.get(scheme.id, ms.memberId, asOfPeriod)?.paidAmount ?? 0;
      liableThisMonth.add(ms.memberId);
      if (paid >= scheme.monthlyAmount) {
        // fully settled for this month in this scheme
      }
    }
  }
  const paidThisMonth = [...liableThisMonth].filter((id) => !thisMonthPending.has(id));

  return {
    totalMembers: members.filter((m) => m.status === "active").length,
    activeSchemes: schemes.filter((s) => s.status === "active").length,
    totalCollection: payments.reduce((s, p) => s + p.amount, 0),
    currentMonthCollection: payments
      .filter((p) => p.paidOn.slice(0, 7) === asOfPeriod)
      .reduce((s, p) => s + p.amount, 0),
    totalPending: pending.reduce((s, r) => s + r.pendingAmount, 0),
    paidMembersThisMonth: paidThisMonth.length,
    pendingMembersThisMonth: thisMonthPending.size,
  };
}

export interface MonthlySeriesPoint {
  period: string;
  label: string;
  collected: number;
  expected: number;
}

/** Collection per calendar month over the last `months` months. */
export function monthlyCollectionSeries(
  payments: Payment[],
  schemes: Scheme[],
  memberships: SchemeMembership[],
  asOfPeriod: string,
  months = 12,
): MonthlySeriesPoint[] {
  const out: MonthlySeriesPoint[] = [];
  for (let i = months - 1; i >= 0; i -= 1) {
    const period = addMonths(asOfPeriod, -i);
    const collected = payments
      .filter((p) => p.paidOn.slice(0, 7) === period)
      .reduce((s, p) => s + p.amount, 0);

    let expected = 0;
    for (const scheme of schemes) {
      if (!schemePeriods(scheme).includes(period)) continue;
      const count = memberships.filter(
        (ms) => ms.schemeId === scheme.id && ms.active && ms.joinedAt.slice(0, 7) <= period,
      ).length;
      expected += count * scheme.monthlyAmount;
    }
    out.push({ period, label: period, collected, expected });
  }
  return out;
}

export function nextMemberCode(members: Member[], prefix = "PK"): string {
  let max = 0;
  for (const m of members) {
    const match = /(\d+)\s*$/.exec(m.memberCode);
    if (match) max = Math.max(max, Number(match[1]));
  }
  return `${prefix}-${String(max + 1).padStart(4, "0")}`;
}

export function nextReceiptNo(payments: Payment[], prefix: string): string {
  const year = new Date().getFullYear();
  let max = 0;
  for (const p of payments) {
    const match = new RegExp(`^${prefix}-${year}-(\\d+)$`).exec(p.receiptNo ?? "");
    if (match) max = Math.max(max, Number(match[1]));
  }
  return `${prefix}-${year}-${String(max + 1).padStart(4, "0")}`;
}

export function renderReminder(
  template: string,
  values: { memberName: string; amount: string; month: string; organizationName: string; schemeName: string },
): string {
  return template
    .replace(/\{\{\s*memberName\s*\}\}/g, values.memberName)
    .replace(/\{\{\s*amount\s*\}\}/g, values.amount)
    .replace(/\{\{\s*month\s*\}\}/g, values.month)
    .replace(/\{\{\s*organizationName\s*\}\}/g, values.organizationName)
    .replace(/\{\{\s*schemeName\s*\}\}/g, values.schemeName);
}
