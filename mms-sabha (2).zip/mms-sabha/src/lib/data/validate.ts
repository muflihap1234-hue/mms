/**
 * Validation shared by both repositories.
 *
 * These are the financial rules of the system. They run before any write in
 * local mode, before any write in Firestore, and are mirrored in
 * `firestore.rules` so a client that skips this code still cannot corrupt the
 * ledger.
 */

import { schemePeriods } from "../kuri";
import type { Member, Payment, PeriodLedger, Scheme, SchemeMembership } from "../types";
import { DomainError, type MemberInput, type PaymentInput, type SchemeInput } from "./types";

const PERIOD_RE = /^\d{4}-(0[1-9]|1[0-2])$/;
const DATE_RE = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;

export function assertPeriod(period: string, field = "Payment month"): void {
  if (!PERIOD_RE.test(period)) {
    throw new DomainError("bad_period", `${field} must be a valid month (YYYY-MM).`);
  }
}

export function assertDate(date: string, field = "Date"): void {
  if (!DATE_RE.test(date)) {
    throw new DomainError("bad_date", `${field} must be a valid date (YYYY-MM-DD).`);
  }
}

export function assertAmount(amount: number, field = "Amount"): void {
  if (!Number.isFinite(amount) || !Number.isInteger(amount)) {
    throw new DomainError("bad_amount", `${field} must be a whole number of rupees.`);
  }
  if (amount <= 0) {
    throw new DomainError("bad_amount", `${field} must be greater than zero.`);
  }
  if (amount > 10_000_000) {
    throw new DomainError("bad_amount", `${field} looks too large. Please check the figure.`);
  }
}

export function validateMemberInput(
  input: MemberInput,
  existing: Member[],
  selfId?: string,
): void {
  if (input.fullName.trim().length < 2) {
    throw new DomainError("bad_name", "Full name is required.");
  }
  const digits = input.phone.replace(/\D/g, "");
  if (digits.length < 10) {
    throw new DomainError("bad_phone", "Enter a valid phone number (at least 10 digits).");
  }
  assertDate(input.joiningDate, "Joining date");

  const code = input.memberCode.trim().toLowerCase();
  if (!code) throw new DomainError("bad_code", "Member ID is required.");

  for (const m of existing) {
    if (m.id === selfId) continue;
    if (m.memberCode.trim().toLowerCase() === code) {
      throw new DomainError(
        "duplicate_code",
        `Member ID "${input.memberCode}" is already used by ${m.fullName}.`,
      );
    }
    if (
      m.status !== "archived" &&
      m.phone.replace(/\D/g, "") === digits &&
      m.fullName.trim().toLowerCase() === input.fullName.trim().toLowerCase()
    ) {
      throw new DomainError(
        "duplicate_member",
        `${m.fullName} already exists with this phone number (${m.memberCode}).`,
      );
    }
  }
}

export function validateSchemeInput(input: SchemeInput): void {
  if (input.name.trim().length < 2) {
    throw new DomainError("bad_name", "Scheme name is required.");
  }
  assertAmount(input.monthlyAmount, "Monthly contribution");
  if (!Number.isInteger(input.durationMonths) || input.durationMonths < 1 || input.durationMonths > 120) {
    throw new DomainError("bad_duration", "Duration must be between 1 and 120 months.");
  }
  assertPeriod(input.startMonth, "Start month");
  if (!Number.isInteger(input.dueDay) || input.dueDay < 1 || input.dueDay > 28) {
    throw new DomainError("bad_due_day", "Monthly due date must be a day from 1 to 28.");
  }
  if (!Number.isInteger(input.memberLimit) || input.memberLimit < 1 || input.memberLimit > 1000) {
    throw new DomainError("bad_limit", "Member limit must be between 1 and 1000.");
  }
}

export interface PaymentContext {
  member: Member | undefined;
  scheme: Scheme | undefined;
  membership: SchemeMembership | undefined;
  /** Existing ledger entry for this member/scheme/period, if any. */
  ledger: PeriodLedger | undefined;
}

/**
 * The guard that stands between an administrator and the ledger.
 *
 * Returns the amount already collected for the period so the caller can write
 * the new ledger total. Throws a DomainError the UI shows verbatim otherwise.
 */
export function validatePayment(input: PaymentInput, ctx: PaymentContext): number {
  assertAmount(input.amount, "Amount");
  assertPeriod(input.period, "Payment month");
  assertDate(input.paidOn, "Payment date");

  if (!input.receivedBy.trim()) {
    throw new DomainError("no_receiver", "Record who received the payment.");
  }

  const { member, scheme, membership, ledger } = ctx;

  if (!member) throw new DomainError("no_member", "Select a member.");
  if (member.status === "archived") {
    throw new DomainError("member_archived", `${member.fullName} is archived. Restore the member first.`);
  }
  if (!scheme) throw new DomainError("no_scheme", "Select a Kuri scheme.");
  if (scheme.status === "archived") {
    throw new DomainError("scheme_archived", `"${scheme.name}" is archived and cannot take payments.`);
  }
  if (!membership || !membership.active) {
    throw new DomainError(
      "not_assigned",
      `${member.fullName} is not assigned to "${scheme.name}". Assign the member to the scheme first.`,
    );
  }
  if (!schemePeriods(scheme).includes(input.period)) {
    throw new DomainError(
      "period_outside_scheme",
      `${input.period} is outside the contribution period of "${scheme.name}".`,
    );
  }
  if (membership.joinedAt.slice(0, 7) > input.period) {
    throw new DomainError(
      "period_before_joining",
      `${member.fullName} joined this scheme after ${input.period}, so no contribution is due for that month.`,
    );
  }
  if (input.paidOn.slice(0, 7) < input.period) {
    throw new DomainError(
      "paid_before_period",
      "Payment date cannot be earlier than the contribution month it settles.",
    );
  }

  const alreadyPaid = ledger?.paidAmount ?? 0;
  if (alreadyPaid >= scheme.monthlyAmount) {
    throw new DomainError(
      "already_paid",
      `${member.fullName} has already paid ${input.period} in full for "${scheme.name}". Edit the existing payment instead of adding a second one.`,
    );
  }
  if (alreadyPaid + input.amount > scheme.monthlyAmount) {
    const remaining = scheme.monthlyAmount - alreadyPaid;
    throw new DomainError(
      "over_collection",
      `Only ₹${remaining.toLocaleString("en-IN")} is outstanding for ${input.period}. Reduce the amount, or correct the earlier payment.`,
    );
  }

  return alreadyPaid;
}

/** Validation for a correction to an existing payment. */
export function validatePaymentEdit(
  amount: number,
  paidOn: string,
  reason: string,
  payment: Payment,
  scheme: Scheme | undefined,
  ledger: PeriodLedger | undefined,
): void {
  assertAmount(amount, "Amount");
  assertDate(paidOn, "Payment date");
  if (reason.trim().length < 3) {
    throw new DomainError(
      "no_reason",
      "Give a reason for the correction. It is stored in the audit history.",
    );
  }
  if (!scheme) throw new DomainError("no_scheme", "The scheme for this payment no longer exists.");

  const otherPaid = Math.max(0, (ledger?.paidAmount ?? payment.amount) - payment.amount);
  if (otherPaid + amount > scheme.monthlyAmount) {
    const remaining = scheme.monthlyAmount - otherPaid;
    throw new DomainError(
      "over_collection",
      `Other payments already cover part of ${payment.period}. The most this payment can be is ₹${remaining.toLocaleString("en-IN")}.`,
    );
  }
}
