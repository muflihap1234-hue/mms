/**
 * Cloud Firestore repository.
 *
 * Layout — one document tree per organization, so one deployment can serve a
 * different Palli without any code change:
 *
 *   organizations/{orgId}
 *     settings/settings
 *     users/{emailLowercase}          role + active flag (the access list)
 *     members/{memberId}
 *     schemes/{schemeId}
 *     schemeMemberships/{schemeId__memberId}
 *     payments/{paymentId}
 *     periodLedger/{schemeId__memberId__period}
 *     paymentAuditLogs/{logId}
 *     reminders/{reminderId}
 *
 * Money is only ever written inside `runTransaction`, together with the period
 * ledger document, so two administrators recording the same contribution at
 * the same moment cannot both succeed.
 */

import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  runTransaction,
  setDoc,
  updateDoc,
  type Firestore,
  type Transaction,
} from "firebase/firestore";

import { firestore } from "../firebase";
import { nextReceiptNo } from "../kuri";
import {
  defaultSettings,
  ledgerId,
  type AdminUser,
  type Member,
  type OrgSettings,
  type Payment,
  type PaymentAuditLog,
  type PeriodLedger,
  type ReminderLog,
  type Scheme,
  type SchemeMembership,
} from "../types";
import {
  DomainError,
  type Actor,
  type MemberInput,
  type PaymentEdit,
  type PaymentInput,
  type Repository,
  type SchemeInput,
  type Snapshot,
} from "./types";
import {
  validateMemberInput,
  validatePayment,
  validatePaymentEdit,
  validateSchemeInput,
} from "./validate";

function now(): string {
  return new Date().toISOString();
}

function rid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
}

export function membershipId(schemeId: string, memberId: string): string {
  return `${schemeId}__${memberId}`;
}

export class FirestoreRepository implements Repository {
  readonly mode = "firebase" as const;
  private readonly orgId: string;
  private readonly db: Firestore;

  constructor(orgId: string) {
    this.orgId = orgId;
    this.db = firestore();
  }

  private path(coll: string): string {
    return `organizations/${this.orgId}/${coll}`;
  }

  private col(coll: string) {
    return collection(this.db, this.path(coll));
  }

  private docRef(coll: string, id: string) {
    return doc(this.db, this.path(coll), id);
  }

  private async all<T>(coll: string): Promise<T[]> {
    const snap = await getDocs(this.col(coll));
    return snap.docs.map((d) => ({ ...(d.data() as T), id: d.id }));
  }

  async load(): Promise<Snapshot> {
    const [users, members, schemes, memberships, payments, ledgers] = await Promise.all([
      this.all<AdminUser>("users"),
      this.all<Member>("members"),
      this.all<Scheme>("schemes"),
      this.all<SchemeMembership>("schemeMemberships"),
      this.all<Payment>("payments"),
      this.all<PeriodLedger>("periodLedger"),
    ]);

    // Audit and reminder history can grow without bound; only the recent tail
    // is needed by the UI, and the full history stays queryable in Firestore.
    const [auditSnap, reminderSnap, settingsSnap] = await Promise.all([
      getDocs(query(this.col("paymentAuditLogs"), orderBy("at", "desc"), limit(300))),
      getDocs(query(this.col("reminders"), orderBy("openedAt", "desc"), limit(300))),
      getDoc(this.docRef("settings", "settings")),
    ]);

    const settings = settingsSnap.exists()
      ? { ...defaultSettings(this.orgId), ...(settingsSnap.data() as OrgSettings), id: "settings" }
      : defaultSettings(this.orgId);

    return {
      users,
      members,
      schemes,
      memberships,
      payments,
      ledgers,
      auditLogs: auditSnap.docs.map((d) => ({ ...(d.data() as PaymentAuditLog), id: d.id })),
      reminders: reminderSnap.docs.map((d) => ({ ...(d.data() as ReminderLog), id: d.id })),
      settings,
    };
  }

  // ------------------------------------------------------------- access list

  /** The access-list document for a signed-in email, or null if not an admin. */
  async findAdminByEmail(email: string): Promise<AdminUser | null> {
    const id = email.trim().toLowerCase();
    const snap = await getDoc(this.docRef("users", id));
    if (!snap.exists()) return null;
    return { ...(snap.data() as AdminUser), id };
  }

  async isOrgInitialized(): Promise<boolean> {
    const snap = await getDoc(this.docRef("settings", "settings"));
    return snap.exists();
  }

  /**
   * First-run claim. Allowed only while the organization has no settings
   * document — the security rules enforce the same window, and writing the
   * settings document in the same step closes it permanently.
   */
  async bootstrapFirstAdmin(input: {
    uid: string;
    name: string;
    email: string;
  }): Promise<AdminUser> {
    const email = input.email.trim().toLowerCase();
    if (await this.isOrgInitialized()) {
      throw new DomainError(
        "already_setup",
        "This organization is already set up. Ask an existing President to add your account.",
      );
    }
    const user: AdminUser = {
      id: email,
      orgId: this.orgId,
      name: input.name.trim() || email,
      email,
      role: "president",
      active: true,
      createdAt: now(),
    };
    await setDoc(this.docRef("users", email), { ...user, uid: input.uid });
    await setDoc(this.docRef("settings", "settings"), defaultSettings(this.orgId));
    return user;
  }

  /** Links the Firebase Auth uid to an invited admin on their first sign-in. */
  async claimUid(email: string, uid: string): Promise<void> {
    await updateDoc(this.docRef("users", email.trim().toLowerCase()), { uid });
  }

  // ---------------------------------------------------------------- members

  async createMember(input: MemberInput, _actor: Actor): Promise<Member> {
    void _actor;
    const existing = await this.all<Member>("members");
    validateMemberInput(input, existing);
    const id = rid();
    const member: Member = {
      ...input,
      id,
      orgId: this.orgId,
      createdAt: now(),
      updatedAt: now(),
    };
    await setDoc(this.docRef("members", id), member);
    return member;
  }

  async updateMember(id: string, patch: Partial<MemberInput>, _actor: Actor): Promise<void> {
    void _actor;
    const existing = await this.all<Member>("members");
    const current = existing.find((m) => m.id === id);
    if (!current) throw new DomainError("not_found", "Member not found.");
    const merged = { ...current, ...patch };
    validateMemberInput(
      {
        memberCode: merged.memberCode,
        fullName: merged.fullName,
        phone: merged.phone,
        address: merged.address,
        joiningDate: merged.joiningDate,
        status: merged.status,
        notes: merged.notes,
      },
      existing,
      id,
    );
    await updateDoc(this.docRef("members", id), { ...patch, updatedAt: now() });
  }

  async setMemberStatus(id: string, status: Member["status"], _actor: Actor): Promise<void> {
    void _actor;
    await updateDoc(this.docRef("members", id), { status, updatedAt: now() });
    if (status === "archived") {
      const memberships = await this.all<SchemeMembership>("schemeMemberships");
      await Promise.all(
        memberships
          .filter((ms) => ms.memberId === id && ms.active)
          .map((ms) => updateDoc(this.docRef("schemeMemberships", ms.id), { active: false })),
      );
    }
  }

  // ---------------------------------------------------------------- schemes

  async createScheme(input: SchemeInput, _actor: Actor): Promise<Scheme> {
    void _actor;
    validateSchemeInput(input);
    const id = rid();
    const scheme: Scheme = {
      ...input,
      id,
      orgId: this.orgId,
      createdAt: now(),
      updatedAt: now(),
    };
    await setDoc(this.docRef("schemes", id), scheme);
    return scheme;
  }

  async updateScheme(id: string, patch: Partial<SchemeInput>, _actor: Actor): Promise<void> {
    void _actor;
    const snap = await getDoc(this.docRef("schemes", id));
    if (!snap.exists()) throw new DomainError("not_found", "Scheme not found.");
    const current = { ...(snap.data() as Scheme), id };
    const merged = { ...current, ...patch };
    validateSchemeInput({
      name: merged.name,
      monthlyAmount: merged.monthlyAmount,
      durationMonths: merged.durationMonths,
      startMonth: merged.startMonth,
      dueDay: merged.dueDay,
      memberLimit: merged.memberLimit,
      status: merged.status,
      notes: merged.notes,
    });

    if (patch.monthlyAmount !== undefined && patch.monthlyAmount !== current.monthlyAmount) {
      const payments = await this.all<Payment>("payments");
      const used = payments.filter((p) => p.schemeId === id).length;
      if (used > 0) {
        throw new DomainError(
          "amount_locked",
          `${used} payment(s) have already been recorded against this scheme, so the monthly contribution can no longer be changed. Create a new scheme for a different amount.`,
        );
      }
    }
    await updateDoc(this.docRef("schemes", id), { ...patch, updatedAt: now() });
  }

  async setSchemeStatus(id: string, status: Scheme["status"], _actor: Actor): Promise<void> {
    void _actor;
    await updateDoc(this.docRef("schemes", id), { status, updatedAt: now() });
  }

  async assignMember(schemeId: string, memberId: string, joinedAt: string): Promise<void> {
    const [schemeSnap, memberSnap, memberships] = await Promise.all([
      getDoc(this.docRef("schemes", schemeId)),
      getDoc(this.docRef("members", memberId)),
      this.all<SchemeMembership>("schemeMemberships"),
    ]);
    if (!schemeSnap.exists()) throw new DomainError("not_found", "Scheme not found.");
    if (!memberSnap.exists()) throw new DomainError("not_found", "Member not found.");
    const scheme = schemeSnap.data() as Scheme;
    const member = memberSnap.data() as Member;

    const id = membershipId(schemeId, memberId);
    const existing = memberships.find((ms) => ms.id === id);
    if (existing?.active) {
      throw new DomainError("already_assigned", `${member.fullName} is already in this scheme.`);
    }
    const activeCount = memberships.filter((ms) => ms.schemeId === schemeId && ms.active).length;
    if (activeCount >= scheme.memberLimit) {
      throw new DomainError(
        "scheme_full",
        `"${scheme.name}" has reached its limit of ${scheme.memberLimit} members. Raise the limit in the scheme settings to add more.`,
      );
    }
    const membership: SchemeMembership = {
      id,
      orgId: this.orgId,
      schemeId,
      memberId,
      joinedAt,
      active: true,
    };
    await setDoc(this.docRef("schemeMemberships", id), membership);
  }

  async unassignMember(schemeId: string, memberId: string): Promise<void> {
    const payments = await this.all<Payment>("payments");
    if (payments.some((p) => p.schemeId === schemeId && p.memberId === memberId)) {
      throw new DomainError(
        "has_payments",
        "This member has payments recorded in the scheme. Payment records are never removed — leave the member in the scheme, or archive the member instead.",
      );
    }
    await updateDoc(this.docRef("schemeMemberships", membershipId(schemeId, memberId)), {
      active: false,
    });
  }

  // --------------------------------------------------------------- payments

  async recordPayment(input: PaymentInput, actor: Actor): Promise<Payment> {
    const [memberSnap, schemeSnap, membershipSnap, payments] = await Promise.all([
      getDoc(this.docRef("members", input.memberId)),
      getDoc(this.docRef("schemes", input.schemeId)),
      getDoc(this.docRef("schemeMemberships", membershipId(input.schemeId, input.memberId))),
      this.all<Payment>("payments"),
    ]);

    const member = memberSnap.exists()
      ? ({ ...(memberSnap.data() as Member), id: input.memberId })
      : undefined;
    const scheme = schemeSnap.exists()
      ? ({ ...(schemeSnap.data() as Scheme), id: input.schemeId })
      : undefined;
    const membership = membershipSnap.exists()
      ? ({ ...(membershipSnap.data() as SchemeMembership), id: membershipSnap.id })
      : undefined;

    const settingsSnap = await getDoc(this.docRef("settings", "settings"));
    const prefix =
      (settingsSnap.exists() ? (settingsSnap.data() as OrgSettings).receiptPrefix : "") || "RCPT";

    const paymentId = rid();
    const key = ledgerId(input.schemeId, input.memberId, input.period);

    const payment = await runTransaction(this.db, async (tx: Transaction) => {
      const ledgerRef = this.docRef("periodLedger", key);
      const ledgerSnap = await tx.get(ledgerRef);
      const ledger = ledgerSnap.exists()
        ? ({ ...(ledgerSnap.data() as PeriodLedger), id: key })
        : undefined;

      // Re-validated inside the transaction against the just-read ledger, so a
      // second administrator submitting the same contribution concurrently is
      // rejected rather than double-counted.
      const alreadyPaid = validatePayment(input, { member, scheme, membership, ledger });

      const record: Payment = {
        id: paymentId,
        orgId: this.orgId,
        memberId: input.memberId,
        schemeId: input.schemeId,
        period: input.period,
        amount: input.amount,
        paidOn: input.paidOn,
        method: input.method,
        receivedBy: input.receivedBy.trim(),
        referenceNo: input.referenceNo.trim(),
        notes: input.notes.trim(),
        receiptNo: nextReceiptNo(payments, prefix),
        createdAt: now(),
        createdByUid: actor.uid,
        createdByName: actor.name,
        updatedAt: null,
        updatedByUid: null,
        updatedByName: null,
        corrected: false,
      };

      tx.set(this.docRef("payments", paymentId), record);
      tx.set(ledgerRef, {
        id: key,
        orgId: this.orgId,
        schemeId: input.schemeId,
        memberId: input.memberId,
        period: input.period,
        dueAmount: scheme!.monthlyAmount,
        paidAmount: alreadyPaid + input.amount,
        paymentIds: [...(ledger?.paymentIds ?? []), paymentId],
        updatedAt: now(),
      } satisfies PeriodLedger);

      const logId = rid();
      tx.set(this.docRef("paymentAuditLogs", logId), {
        id: logId,
        orgId: this.orgId,
        paymentId,
        action: "create",
        before: null,
        after: record,
        reason: "Payment recorded",
        actorUid: actor.uid,
        actorName: actor.name,
        at: now(),
      } satisfies PaymentAuditLog);

      return record;
    });

    return payment;
  }

  async editPayment(paymentId: string, patch: PaymentEdit, actor: Actor): Promise<void> {
    await runTransaction(this.db, async (tx: Transaction) => {
      const paymentRef = this.docRef("payments", paymentId);
      const paymentSnap = await tx.get(paymentRef);
      if (!paymentSnap.exists()) throw new DomainError("not_found", "Payment not found.");
      const before = { ...(paymentSnap.data() as Payment), id: paymentId };

      const schemeSnap = await tx.get(this.docRef("schemes", before.schemeId));
      const scheme = schemeSnap.exists()
        ? ({ ...(schemeSnap.data() as Scheme), id: before.schemeId })
        : undefined;

      const key = ledgerId(before.schemeId, before.memberId, before.period);
      const ledgerRef = this.docRef("periodLedger", key);
      const ledgerSnap = await tx.get(ledgerRef);
      const ledger = ledgerSnap.exists()
        ? ({ ...(ledgerSnap.data() as PeriodLedger), id: key })
        : undefined;

      validatePaymentEdit(patch.amount, patch.paidOn, patch.reason, before, scheme, ledger);

      const after: Payment = {
        ...before,
        amount: patch.amount,
        paidOn: patch.paidOn,
        method: patch.method,
        receivedBy: patch.receivedBy.trim(),
        referenceNo: patch.referenceNo.trim(),
        notes: patch.notes.trim(),
        updatedAt: now(),
        updatedByUid: actor.uid,
        updatedByName: actor.name,
        corrected: true,
      };

      tx.set(paymentRef, after);
      if (ledger) {
        tx.update(ledgerRef, {
          paidAmount: ledger.paidAmount - before.amount + after.amount,
          updatedAt: now(),
        });
      }

      const logId = rid();
      tx.set(this.docRef("paymentAuditLogs", logId), {
        id: logId,
        orgId: this.orgId,
        paymentId,
        action: "update",
        before,
        after,
        reason: patch.reason.trim(),
        actorUid: actor.uid,
        actorName: actor.name,
        at: now(),
      } satisfies PaymentAuditLog);
    });
  }

  // -------------------------------------------------------------- reminders

  async logReminder(entry: Omit<ReminderLog, "id" | "orgId">): Promise<void> {
    const id = rid();
    await setDoc(this.docRef("reminders", id), { ...entry, id, orgId: this.orgId });
  }

  // --------------------------------------------------------------- settings

  async saveSettings(patch: Partial<OrgSettings>, _actor: Actor): Promise<void> {
    void _actor;
    await setDoc(
      this.docRef("settings", "settings"),
      { ...patch, id: "settings", orgId: this.orgId, updatedAt: now() },
      { merge: true },
    );
  }

  // ----------------------------------------------------------------- admins

  /**
   * Adds an administrator to the access list.
   *
   * On the Firebase free (Spark) plan a web client cannot create another
   * account's Auth credentials without signing the current administrator out,
   * and doing it server-side needs Cloud Functions, which require the paid
   * Blaze plan. So this writes the role record, and the new administrator
   * either signs up with this email or is created once in the Firebase console.
   * Until an Auth account exists for the email, the record grants nothing.
   */
  async createAdmin(
    input: { name: string; email: string; role: AdminUser["role"]; password: string },
    _actor: Actor,
  ): Promise<void> {
    void _actor;
    const email = input.email.trim().toLowerCase();
    if (!email.includes("@")) throw new DomainError("bad_email", "Enter a valid email address.");
    const existing = await getDoc(this.docRef("users", email));
    if (existing.exists()) {
      throw new DomainError("duplicate_admin", "An administrator with this email already exists.");
    }
    const user: AdminUser = {
      id: email,
      orgId: this.orgId,
      name: input.name.trim(),
      email,
      role: input.role,
      active: true,
      createdAt: now(),
    };
    await setDoc(this.docRef("users", email), user);
  }

  async updateAdmin(
    id: string,
    patch: Partial<Pick<AdminUser, "name" | "role" | "active">>,
    _actor: Actor,
  ): Promise<void> {
    void _actor;
    const users = await this.all<AdminUser>("users");
    const target = users.find((u) => u.id === id);
    if (!target) throw new DomainError("not_found", "Administrator not found.");
    const otherPresidents = users.filter(
      (u) => u.active && u.role === "president" && u.id !== id,
    ).length;
    if (
      otherPresidents === 0 &&
      target.role === "president" &&
      (patch.active === false || (patch.role !== undefined && patch.role !== "president"))
    ) {
      throw new DomainError(
        "last_president",
        "At least one active President must remain so the dashboard cannot be locked out.",
      );
    }
    await updateDoc(this.docRef("users", id), patch);
  }
}
