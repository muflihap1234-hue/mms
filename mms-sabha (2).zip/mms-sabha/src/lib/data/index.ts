import { ORG_ID, firebaseConfigured } from "../firebase";
import { FirestoreRepository } from "./firestore";
import { LocalRepository } from "./local";
import type { DataMode, Repository } from "./types";

let cached: Repository | null = null;

/** The active repository. Firestore when configured, local mode otherwise. */
export function getRepository(): Repository {
  if (cached) return cached;
  cached = firebaseConfigured
    ? new FirestoreRepository(ORG_ID)
    : new LocalRepository(ORG_ID);
  return cached;
}

export function dataMode(): DataMode {
  return firebaseConfigured ? "firebase" : "local";
}

export function asLocal(repo: Repository): LocalRepository | null {
  return repo instanceof LocalRepository ? repo : null;
}

export function asFirestore(repo: Repository): FirestoreRepository | null {
  return repo instanceof FirestoreRepository ? repo : null;
}

export { DomainError } from "./types";
export type {
  Actor,
  MemberInput,
  PaymentEdit,
  PaymentInput,
  Repository,
  SchemeInput,
  Snapshot,
} from "./types";
