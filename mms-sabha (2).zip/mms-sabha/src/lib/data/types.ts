import type {
  AdminUser,
  Member,
  OrgSettings,
  Payment,
  PaymentAuditLog,
  PeriodLedger,
  ReminderLog,
  Scheme,
  SchemeMembership,
} from "../types";

export type DataMode = "firebase" | "local";

/** Everything the dashboard needs, loaded in one pass. */
export interface Snapshot {
  users: AdminUser[];
  members: Member[];
  schemes: Scheme[];
  memberships: SchemeMembership[];
  payments: Payment[];
  ledgers: PeriodLedger[];
  auditLogs: PaymentAuditLog[];
  reminders: ReminderLog[];
  settings: OrgSettings;
}

export interface Actor {
  uid: string;
  name: string;
}

export interface PaymentInput {
  memberId: string;
  schemeId: string;
  period: string;
  amount: number;
  paidOn: string;
  method: Payment["method"];
  receivedBy: string;
  referenceNo: string;
  notes: string;
}

export interface PaymentEdit {
  amount: number;
  paidOn: string;
  method: Payment["method"];
  receivedBy: string;
  referenceNo: string;
  notes: string;
  reason: string;
}

export type MemberInput = Omit<
  Member,
  "id" | "orgId" | "createdAt" | "updatedAt"
>;

export type SchemeInput = Omit<Scheme, "id" | "orgId" | "createdAt" | "updatedAt">;

/**
 * Raised for every rule the application enforces before writing money:
 * duplicate collection, over-collection, unknown member, closed scheme.
 * Carries a message meant to be shown to the administrator verbatim.
 */
export class DomainError extends Error {
  readonly code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = "DomainError";
    this.code = code;
  }
}

/**
 * The storage contract. Both the Firestore repository and the local-mode
 * repository implement it, so no page or component knows which one is active.
 */
export interface Repository {
  readonly mode: DataMode;

  load(): Promise<Snapshot>;

  createMember(input: MemberInput, actor: Actor): Promise<Member>;
  updateMember(id: string, patch: Partial<MemberInput>, actor: Actor): Promise<void>;
  setMemberStatus(id: string, status: Member["status"], actor: Actor): Promise<void>;

  createScheme(input: SchemeInput, actor: Actor): Promise<Scheme>;
  updateScheme(id: string, patch: Partial<SchemeInput>, actor: Actor): Promise<void>;
  setSchemeStatus(id: string, status: Scheme["status"], actor: Actor): Promise<void>;

  assignMember(schemeId: string, memberId: string, joinedAt: string): Promise<void>;
  unassignMember(schemeId: string, memberId: string): Promise<void>;

  /** Atomic: writes the payment, the period ledger and the audit entry together. */
  recordPayment(input: PaymentInput, actor: Actor): Promise<Payment>;
  /** Atomic correction. The pre-change values are preserved in the audit log. */
  editPayment(paymentId: string, patch: PaymentEdit, actor: Actor): Promise<void>;

  logReminder(entry: Omit<ReminderLog, "id" | "orgId">): Promise<void>;

  saveSettings(patch: Partial<OrgSettings>, actor: Actor): Promise<void>;

  createAdmin(
    input: { name: string; email: string; role: AdminUser["role"]; password: string },
    actor: Actor,
  ): Promise<void>;
  updateAdmin(id: string, patch: Partial<Pick<AdminUser, "name" | "role" | "active">>, actor: Actor): Promise<void>;
}
