/**
 * LOCAL DEVELOPMENT MODE repository.
 *
 * Every record is kept in this browser's localStorage. Nothing is sent
 * anywhere and nothing is stored in any cloud database. This exists so the
 * complete application can be used and reviewed before Firebase credentials
 * are available — it is not a substitute for the cloud and the UI says so on
 * every screen.
 *
 * The financial rules are identical to the Firestore repository: the same
 * validation module runs, the same period ledger is maintained, and the same
 * audit entries are written.
 */

import {
  ledgerId,
  defaultSettings,
  type AdminUser,
  type Member,
  type OrgSettings,
  type Payment,
  type PaymentAuditLog,
  type PeriodLedger,
  type ReminderLog,
  type Scheme,
  type SchemeMembership,
} from "../types";
import { nextReceiptNo } from "../kuri";
import {
  DomainError,
  type Actor,
  type MemberInput,
  type PaymentEdit,
  type PaymentInput,
  type Repository,
  type SchemeInput,
  type Snapshot,
} from "./types";
import {
  validateMemberInput,
  validatePayment,
  validatePaymentEdit,
  validateSchemeInput,
} from "./validate";

// Storage key kept under the original name on purpose: renaming it would hide
// every record already saved in this browser. It is never shown to a user, so
// the MMS Sabha rename does not touch it.
const KEY = "palli-kuri:local-store:v1";

interface LocalStore {
  users: AdminUser[];
  members: Member[];
  schemes: Scheme[];
  memberships: SchemeMembership[];
  payments: Payment[];
  ledgers: PeriodLedger[];
  auditLogs: PaymentAuditLog[];
  reminders: ReminderLog[];
  settings: OrgSettings;
}

function emptyStore(orgId: string): LocalStore {
  return {
    users: [],
    members: [],
    schemes: [],
    memberships: [],
    payments: [],
    ledgers: [],
    auditLogs: [],
    reminders: [],
    settings: defaultSettings(orgId),
  };
}

function uid(prefix: string): string {
  const rand =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID().slice(0, 8)
      : Math.random().toString(36).slice(2, 10);
  return `${prefix}_${Date.now().toString(36)}${rand}`;
}

function now(): string {
  return new Date().toISOString();
}

export class LocalRepository implements Repository {
  readonly mode = "local" as const;
  private readonly orgId: string;

  constructor(orgId: string) {
    this.orgId = orgId;
  }

  private read(): LocalStore {
    if (typeof window === "undefined") return emptyStore(this.orgId);
    try {
      const raw = window.localStorage.getItem(KEY);
      if (!raw) return emptyStore(this.orgId);
      const parsed = JSON.parse(raw) as Partial<LocalStore>;
      const base = emptyStore(this.orgId);
      return {
        ...base,
        ...parsed,
        settings: { ...base.settings, ...(parsed.settings ?? {}) },
      };
    } catch {
      return emptyStore(this.orgId);
    }
  }

  private write(store: LocalStore): void {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(KEY, JSON.stringify(store));
  }

  private mutate<T>(fn: (store: LocalStore) => T): T {
    const store = this.read();
    const result = fn(store);
    this.write(store);
    return result;
  }

  async load(): Promise<Snapshot> {
    const s = this.read();
    return {
      users: s.users,
      members: s.members,
      schemes: s.schemes,
      memberships: s.memberships,
      payments: s.payments,
      ledgers: s.ledgers,
      auditLogs: s.auditLogs,
      reminders: s.reminders,
      settings: s.settings,
    };
  }

  // ---------------------------------------------------------------- local auth

  /** Local-mode sign in. Credentials never leave this browser. */
  async localSignIn(email: string, password: string): Promise<AdminUser> {
    const store = this.read();
    const user = store.users.find(
      (u) => u.email.toLowerCase() === email.trim().toLowerCase(),
    );
    if (!user || user.localPassword !== password) {
      throw new DomainError("bad_credentials", "Incorrect email or password.");
    }
    if (!user.active) {
      throw new DomainError("inactive", "This administrator account is disabled.");
    }
    return user;
  }

  async hasAnyAdmin(): Promise<boolean> {
    return this.read().users.length > 0;
  }

  /** First-run bootstrap in local mode: creates the President account. */
  async bootstrapFirstAdmin(input: {
    name: string;
    email: string;
    password: string;
  }): Promise<AdminUser> {
    return this.mutate((store) => {
      if (store.users.length > 0) {
        throw new DomainError("already_setup", "An administrator already exists.");
      }
      if (input.password.length < 6) {
        throw new DomainError("weak_password", "Use a password of at least 6 characters.");
      }
      const user: AdminUser = {
        id: uid("usr"),
        orgId: this.orgId,
        name: input.name.trim(),
        email: input.email.trim().toLowerCase(),
        role: "president",
        active: true,
        createdAt: now(),
        localPassword: input.password,
      };
      store.users.push(user);
      return user;
    });
  }

  // ------------------------------------------------------------------- members

  async createMember(input: MemberInput, _actor: Actor): Promise<Member> {
    void _actor;
    return this.mutate((store) => {
      validateMemberInput(input, store.members);
      const member: Member = {
        ...input,
        id: uid("mem"),
        orgId: this.orgId,
        createdAt: now(),
        updatedAt: now(),
      };
      store.members.push(member);
      return member;
    });
  }

  async updateMember(id: string, patch: Partial<MemberInput>, _actor: Actor): Promise<void> {
    void _actor;
    this.mutate((store) => {
      const i = store.members.findIndex((m) => m.id === id);
      if (i < 0) throw new DomainError("not_found", "Member not found.");
      const merged = { ...store.members[i]!, ...patch };
      validateMemberInput(
        {
          memberCode: merged.memberCode,
          fullName: merged.fullName,
          phone: merged.phone,
          address: merged.address,
          joiningDate: merged.joiningDate,
          status: merged.status,
          notes: merged.notes,
        },
        store.members,
        id,
      );
      store.members[i] = { ...merged, updatedAt: now() };
    });
  }

  async setMemberStatus(id: string, status: Member["status"], _actor: Actor): Promise<void> {
    void _actor;
    this.mutate((store) => {
      const m = store.members.find((x) => x.id === id);
      if (!m) throw new DomainError("not_found", "Member not found.");
      m.status = status;
      m.updatedAt = now();
      if (status === "archived") {
        for (const ms of store.memberships) {
          if (ms.memberId === id) ms.active = false;
        }
      }
    });
  }

  // ------------------------------------------------------------------- schemes

  async createScheme(input: SchemeInput, _actor: Actor): Promise<Scheme> {
    void _actor;
    return this.mutate((store) => {
      validateSchemeInput(input);
      const scheme: Scheme = {
        ...input,
        id: uid("sch"),
        orgId: this.orgId,
        createdAt: now(),
        updatedAt: now(),
      };
      store.schemes.push(scheme);
      return scheme;
    });
  }

  async updateScheme(id: string, patch: Partial<SchemeInput>, _actor: Actor): Promise<void> {
    void _actor;
    this.mutate((store) => {
      const i = store.schemes.findIndex((s) => s.id === id);
      if (i < 0) throw new DomainError("not_found", "Scheme not found.");
      const merged = { ...store.schemes[i]!, ...patch };
      validateSchemeInput({
        name: merged.name,
        monthlyAmount: merged.monthlyAmount,
        durationMonths: merged.durationMonths,
        startMonth: merged.startMonth,
        dueDay: merged.dueDay,
        memberLimit: merged.memberLimit,
        status: merged.status,
        notes: merged.notes,
      });

      const collected = store.payments.filter((p) => p.schemeId === id);
      if (collected.length > 0 && patch.monthlyAmount !== undefined && patch.monthlyAmount !== store.schemes[i]!.monthlyAmount) {
        throw new DomainError(
          "amount_locked",
          `${collected.length} payment(s) have already been recorded against this scheme, so the monthly contribution can no longer be changed. Create a new scheme for a different amount.`,
        );
      }
      store.schemes[i] = { ...merged, updatedAt: now() };

      // Keep ledger due amounts aligned with the scheme.
      for (const l of store.ledgers) {
        if (l.schemeId === id) l.dueAmount = store.schemes[i]!.monthlyAmount;
      }
    });
  }

  async setSchemeStatus(id: string, status: Scheme["status"], _actor: Actor): Promise<void> {
    void _actor;
    this.mutate((store) => {
      const s = store.schemes.find((x) => x.id === id);
      if (!s) throw new DomainError("not_found", "Scheme not found.");
      s.status = status;
      s.updatedAt = now();
    });
  }

  async assignMember(schemeId: string, memberId: string, joinedAt: string): Promise<void> {
    this.mutate((store) => {
      const scheme = store.schemes.find((s) => s.id === schemeId);
      if (!scheme) throw new DomainError("not_found", "Scheme not found.");
      const member = store.members.find((m) => m.id === memberId);
      if (!member) throw new DomainError("not_found", "Member not found.");

      const existing = store.memberships.find(
        (ms) => ms.schemeId === schemeId && ms.memberId === memberId,
      );
      if (existing?.active) {
        throw new DomainError("already_assigned", `${member.fullName} is already in this scheme.`);
      }
      const activeCount = store.memberships.filter(
        (ms) => ms.schemeId === schemeId && ms.active,
      ).length;
      if (activeCount >= scheme.memberLimit) {
        throw new DomainError(
          "scheme_full",
          `"${scheme.name}" has reached its limit of ${scheme.memberLimit} members. Raise the limit in the scheme settings to add more.`,
        );
      }
      if (existing) {
        existing.active = true;
        existing.joinedAt = joinedAt;
        return;
      }
      store.memberships.push({
        id: uid("msh"),
        orgId: this.orgId,
        schemeId,
        memberId,
        joinedAt,
        active: true,
      });
    });
  }

  async unassignMember(schemeId: string, memberId: string): Promise<void> {
    this.mutate((store) => {
      const paid = store.payments.some(
        (p) => p.schemeId === schemeId && p.memberId === memberId,
      );
      if (paid) {
        throw new DomainError(
          "has_payments",
          "This member has payments recorded in the scheme. Payment records are never removed — leave the member in the scheme, or archive the member instead.",
        );
      }
      const ms = store.memberships.find(
        (x) => x.schemeId === schemeId && x.memberId === memberId,
      );
      if (ms) ms.active = false;
    });
  }

  // ------------------------------------------------------------------ payments

  async recordPayment(input: PaymentInput, actor: Actor): Promise<Payment> {
    return this.mutate((store) => {
      const member = store.members.find((m) => m.id === input.memberId);
      const scheme = store.schemes.find((s) => s.id === input.schemeId);
      const membership = store.memberships.find(
        (ms) => ms.schemeId === input.schemeId && ms.memberId === input.memberId,
      );
      const key = ledgerId(input.schemeId, input.memberId, input.period);
      const ledger = store.ledgers.find((l) => l.id === key);

      const alreadyPaid = validatePayment(input, { member, scheme, membership, ledger });

      const payment: Payment = {
        id: uid("pay"),
        orgId: this.orgId,
        memberId: input.memberId,
        schemeId: input.schemeId,
        period: input.period,
        amount: input.amount,
        paidOn: input.paidOn,
        method: input.method,
        receivedBy: input.receivedBy.trim(),
        referenceNo: input.referenceNo.trim(),
        notes: input.notes.trim(),
        receiptNo: nextReceiptNo(store.payments, store.settings.receiptPrefix || "RCPT"),
        createdAt: now(),
        createdByUid: actor.uid,
        createdByName: actor.name,
        updatedAt: null,
        updatedByUid: null,
        updatedByName: null,
        corrected: false,
      };
      store.payments.push(payment);

      if (ledger) {
        ledger.paidAmount = alreadyPaid + input.amount;
        ledger.paymentIds.push(payment.id);
        ledger.updatedAt = now();
      } else {
        store.ledgers.push({
          id: key,
          orgId: this.orgId,
          schemeId: input.schemeId,
          memberId: input.memberId,
          period: input.period,
          dueAmount: scheme!.monthlyAmount,
          paidAmount: input.amount,
          paymentIds: [payment.id],
          updatedAt: now(),
        });
      }

      store.auditLogs.push({
        id: uid("aud"),
        orgId: this.orgId,
        paymentId: payment.id,
        action: "create",
        before: null,
        after: { ...payment },
        reason: "Payment recorded",
        actorUid: actor.uid,
        actorName: actor.name,
        at: now(),
      });

      return payment;
    });
  }

  async editPayment(paymentId: string, patch: PaymentEdit, actor: Actor): Promise<void> {
    this.mutate((store) => {
      const i = store.payments.findIndex((p) => p.id === paymentId);
      if (i < 0) throw new DomainError("not_found", "Payment not found.");
      const before = { ...store.payments[i]! };
      const scheme = store.schemes.find((s) => s.id === before.schemeId);
      const key = ledgerId(before.schemeId, before.memberId, before.period);
      const ledger = store.ledgers.find((l) => l.id === key);

      validatePaymentEdit(patch.amount, patch.paidOn, patch.reason, before, scheme, ledger);

      const after: Payment = {
        ...before,
        amount: patch.amount,
        paidOn: patch.paidOn,
        method: patch.method,
        receivedBy: patch.receivedBy.trim(),
        referenceNo: patch.referenceNo.trim(),
        notes: patch.notes.trim(),
        updatedAt: now(),
        updatedByUid: actor.uid,
        updatedByName: actor.name,
        corrected: true,
      };
      store.payments[i] = after;

      if (ledger) {
        ledger.paidAmount = ledger.paidAmount - before.amount + after.amount;
        ledger.updatedAt = now();
      }

      store.auditLogs.push({
        id: uid("aud"),
        orgId: this.orgId,
        paymentId,
        action: "update",
        before,
        after,
        reason: patch.reason.trim(),
        actorUid: actor.uid,
        actorName: actor.name,
        at: now(),
      });
    });
  }

  // ----------------------------------------------------------------- reminders

  async logReminder(entry: Omit<ReminderLog, "id" | "orgId">): Promise<void> {
    this.mutate((store) => {
      store.reminders.unshift({ ...entry, id: uid("rem"), orgId: this.orgId });
      store.reminders = store.reminders.slice(0, 500);
    });
  }

  // ------------------------------------------------------------------ settings

  async saveSettings(patch: Partial<OrgSettings>, _actor: Actor): Promise<void> {
    void _actor;
    this.mutate((store) => {
      store.settings = {
        ...store.settings,
        ...patch,
        id: "settings",
        orgId: this.orgId,
        updatedAt: now(),
      };
    });
  }

  // -------------------------------------------------------------------- admins

  async createAdmin(
    input: { name: string; email: string; role: AdminUser["role"]; password: string },
    _actor: Actor,
  ): Promise<void> {
    void _actor;
    this.mutate((store) => {
      if (input.password.length < 6) {
        throw new DomainError("weak_password", "Use a password of at least 6 characters.");
      }
      const email = input.email.trim().toLowerCase();
      if (!email.includes("@")) {
        throw new DomainError("bad_email", "Enter a valid email address.");
      }
      if (store.users.some((u) => u.email.toLowerCase() === email)) {
        throw new DomainError("duplicate_admin", "An administrator with this email already exists.");
      }
      store.users.push({
        id: uid("usr"),
        orgId: this.orgId,
        name: input.name.trim(),
        email,
        role: input.role,
        active: true,
        createdAt: now(),
        localPassword: input.password,
      });
    });
  }

  async updateAdmin(
    id: string,
    patch: Partial<Pick<AdminUser, "name" | "role" | "active">>,
    _actor: Actor,
  ): Promise<void> {
    void _actor;
    this.mutate((store) => {
      const u = store.users.find((x) => x.id === id);
      if (!u) throw new DomainError("not_found", "Administrator not found.");
      const activePresidents = store.users.filter(
        (x) => x.active && x.role === "president" && x.id !== id,
      ).length;
      if (
        activePresidents === 0 &&
        ((patch.active === false && u.role === "president") ||
          (patch.role !== undefined && patch.role !== "president" && u.role === "president"))
      ) {
        throw new DomainError(
          "last_president",
          "At least one active President must remain so the dashboard cannot be locked out.",
        );
      }
      Object.assign(u, patch);
    });
  }

  /** Clears local-mode data. Only reachable from Settings in local mode. */
  async resetLocalData(): Promise<void> {
    if (typeof window === "undefined") return;
    const users = this.read().users;
    const fresh = emptyStore(this.orgId);
    fresh.users = users;
    this.write(fresh);
  }
}
