"use client";

/**
 * Authentication for both modes.
 *
 * Firebase mode  — Firebase Authentication (email + password). Being signed in
 *                  is not enough: the email must also appear in the
 *                  organization's `users` access list with `active: true`. A
 *                  signed-in user who is not on that list is signed straight
 *                  back out, which is the same rule the Firestore security
 *                  rules enforce on the server side.
 *
 * Local mode     — the session lives in this browser only. It grants access to
 *                  local-mode data and nothing else; there is no cloud account
 *                  behind it.
 */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  type User,
} from "firebase/auth";

import { firebaseAuth, firebaseConfigured } from "../firebase";
import { asFirestore, asLocal, getRepository } from "../data";
import { DomainError } from "../data/types";
import type { AdminRole, AdminUser, Capability } from "../types";
import { can } from "../types";

// Storage key kept under the original name on purpose: renaming it would orphan
// the session of anyone already signed in on this browser. It is never shown to
// a user, so the MMS Sabha rename does not touch it.
const SESSION_KEY = "palli-kuri:local-session:v1";

export interface AuthState {
  mode: "firebase" | "local";
  loading: boolean;
  user: AdminUser | null;
  /** True when the organization has no administrator yet. */
  needsBootstrap: boolean;
  error: string | null;
  signIn: (email: string, password: string) => Promise<void>;
  bootstrap: (input: { name: string; email: string; password: string }) => Promise<void>;
  logout: () => Promise<void>;
  can: (capability: Capability) => boolean;
  role: AdminRole | null;
}

const AuthContext = createContext<AuthState | null>(null);

function message(err: unknown): string {
  if (err instanceof DomainError) return err.message;
  if (err && typeof err === "object" && "code" in err) {
    const code = String((err as { code: unknown }).code);
    if (code.includes("invalid-credential") || code.includes("wrong-password") || code.includes("user-not-found")) {
      return "Incorrect email or password.";
    }
    if (code.includes("too-many-requests")) {
      return "Too many attempts. Wait a few minutes and try again.";
    }
    if (code.includes("network")) return "Network error. Check your connection and try again.";
    if (code.includes("permission-denied")) {
      return "This account is not allowed to open the dashboard.";
    }
  }
  if (err instanceof Error) return err.message;
  return "Something went wrong. Please try again.";
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const mode = firebaseConfigured ? "firebase" : "local";
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<AdminUser | null>(null);
  const [needsBootstrap, setNeedsBootstrap] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // ----------------------------------------------------------- firebase mode

  useEffect(() => {
    if (mode !== "firebase") return;
    const repo = asFirestore(getRepository());
    if (!repo) return;

    const unsub = onAuthStateChanged(firebaseAuth(), async (fbUser: User | null) => {
      if (!fbUser) {
        setUser(null);
        try {
          setNeedsBootstrap(!(await repo.isOrgInitialized()));
        } catch {
          // Rules may deny reads before sign-in; the login screen still works.
          setNeedsBootstrap(false);
        }
        setLoading(false);
        return;
      }
      try {
        const email = (fbUser.email ?? "").toLowerCase();
        const admin = await repo.findAdminByEmail(email);
        if (admin && admin.active) {
          setUser(admin);
          setNeedsBootstrap(false);
          void repo.claimUid(email, fbUser.uid).catch(() => undefined);
        } else if (admin && !admin.active) {
          await signOut(firebaseAuth());
          setUser(null);
          setError("This administrator account has been disabled.");
        } else if (!(await repo.isOrgInitialized())) {
          // Signed in, organization not yet set up: offer the first-run claim.
          const claimed = await repo.bootstrapFirstAdmin({
            uid: fbUser.uid,
            name: fbUser.displayName ?? email,
            email,
          });
          setUser(claimed);
          setNeedsBootstrap(false);
        } else {
          await signOut(firebaseAuth());
          setUser(null);
          setError(
            "This email is not on the administrator list for this organization. Ask the President to add it under Admin Management.",
          );
        }
      } catch (err) {
        setError(message(err));
        setUser(null);
      } finally {
        setLoading(false);
      }
    });
    return unsub;
  }, [mode]);

  // -------------------------------------------------------------- local mode

  useEffect(() => {
    if (mode !== "local") return;
    const repo = asLocal(getRepository());
    if (!repo) return;
    void (async () => {
      const any = await repo.hasAnyAdmin();
      setNeedsBootstrap(!any);
      if (any && typeof window !== "undefined") {
        const raw = window.sessionStorage.getItem(SESSION_KEY);
        if (raw) {
          try {
            setUser(JSON.parse(raw) as AdminUser);
          } catch {
            window.sessionStorage.removeItem(SESSION_KEY);
          }
        }
      }
      setLoading(false);
    })();
  }, [mode]);

  const signIn = useCallback(
    async (email: string, password: string) => {
      setError(null);
      try {
        if (mode === "firebase") {
          await signInWithEmailAndPassword(firebaseAuth(), email.trim(), password);
          return;
        }
        const repo = asLocal(getRepository());
        if (!repo) throw new Error("Local mode is unavailable.");
        const signed = await repo.localSignIn(email, password);
        window.sessionStorage.setItem(SESSION_KEY, JSON.stringify(signed));
        setUser(signed);
      } catch (err) {
        const msg = message(err);
        setError(msg);
        throw new Error(msg);
      }
    },
    [mode],
  );

  const bootstrap = useCallback(
    async (input: { name: string; email: string; password: string }) => {
      setError(null);
      try {
        if (mode === "local") {
          const repo = asLocal(getRepository());
          if (!repo) throw new Error("Local mode is unavailable.");
          const created = await repo.bootstrapFirstAdmin(input);
          window.sessionStorage.setItem(SESSION_KEY, JSON.stringify(created));
          setUser(created);
          setNeedsBootstrap(false);
          return;
        }
        // Firebase mode: the Auth account is created once in the Firebase
        // console, then the first sign-in claims the President record.
        await signInWithEmailAndPassword(firebaseAuth(), input.email.trim(), input.password);
      } catch (err) {
        const msg = message(err);
        setError(msg);
        throw new Error(msg);
      }
    },
    [mode],
  );

  const logout = useCallback(async () => {
    if (mode === "firebase") {
      await signOut(firebaseAuth());
    } else if (typeof window !== "undefined") {
      window.sessionStorage.removeItem(SESSION_KEY);
    }
    setUser(null);
    setError(null);
  }, [mode]);

  const value = useMemo<AuthState>(
    () => ({
      mode,
      loading,
      user,
      needsBootstrap,
      error,
      signIn,
      bootstrap,
      logout,
      can: (capability: Capability) => can(user?.role, capability),
      role: user?.role ?? null,
    }),
    [mode, loading, user, needsBootstrap, error, signIn, bootstrap, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>.");
  return ctx;
}
