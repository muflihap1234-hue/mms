/**
 * Single place where Firebase environment variables are read.
 *
 * No other module touches `process.env`. If any required key is missing the
 * app reports `configured: false` and the application falls back to local
 * development mode instead of silently failing at the first query.
 *
 * Only NEXT_PUBLIC_* values appear here. These are published to the browser by
 * design — a Firebase web config is an identifier, not a secret, which is why
 * all real access control lives in the Firestore security rules shipped in
 * `firestore.rules`. Never put a service account key or admin credential in
 * this file.
 */

import { initializeApp, getApps, getApp, type FirebaseApp } from "firebase/app";
import { getAuth, type Auth } from "firebase/auth";
import { getFirestore, type Firestore } from "firebase/firestore";

interface FirebaseEnv {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
}

const raw: FirebaseEnv = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY ?? "",
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN ?? "",
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID ?? "",
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET ?? "",
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID ?? "",
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID ?? "",
};

export const ORG_ID: string = process.env.NEXT_PUBLIC_ORG_ID || "default";

/** Which keys are missing, for the setup screen. Values are never reported. */
export const missingFirebaseKeys: string[] = (
  Object.entries(raw) as Array<[keyof FirebaseEnv, string]>
)
  .filter(([, value]) => value.trim() === "")
  .map(([key]) => key);

export const firebaseConfigured: boolean = missingFirebaseKeys.length === 0;

let app: FirebaseApp | null = null;

function ensureApp(): FirebaseApp {
  if (!firebaseConfigured) {
    throw new Error(
      "Firebase is not configured. Set the NEXT_PUBLIC_FIREBASE_* variables in .env.local.",
    );
  }
  if (!app) app = getApps().length ? getApp() : initializeApp(raw);
  return app;
}

export function firebaseAuth(): Auth {
  return getAuth(ensureApp());
}

export function firestore(): Firestore {
  return getFirestore(ensureApp());
}
