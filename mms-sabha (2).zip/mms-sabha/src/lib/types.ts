/**
 * Domain model for the MMS Sabha Contribution Management System.
 *
 * All monetary amounts are stored as integer paise? No — they are stored as
 * whole rupees (number), because Kuri contributions in practice are always
 * whole-rupee amounts (₹4,000 / ₹5,000 / ₹6,000). Validation rejects
 * fractional input so no rounding drift can enter the ledger.
 */

export type AdminRole = "president" | "treasurer" | "admin";

export const ADMIN_ROLES: readonly AdminRole[] = ["president", "treasurer", "admin"];

export const ROLE_LABEL: Record<AdminRole, string> = {
  president: "President",
  treasurer: "Treasurer",
  admin: "Additional Admin",
};

/** Capabilities are derived from role — never stored on the client. */
export type Capability =
  | "payment:create"
  | "payment:edit"
  | "member:write"
  | "scheme:write"
  | "admin:manage"
  | "settings:write"
  | "report:view"
  | "reminder:send";

const CAPABILITIES: Record<AdminRole, readonly Capability[]> = {
  president: [
    "payment:create",
    "payment:edit",
    "member:write",
    "scheme:write",
    "admin:manage",
    "settings:write",
    "report:view",
    "reminder:send",
  ],
  treasurer: [
    "payment:create",
    "payment:edit",
    "member:write",
    "scheme:write",
    "settings:write",
    "report:view",
    "reminder:send",
  ],
  admin: ["payment:create", "member:write", "report:view", "reminder:send"],
};

export function can(role: AdminRole | undefined, capability: Capability): boolean {
  if (!role) return false;
  return CAPABILITIES[role].includes(capability);
}

export interface AdminUser {
  id: string;
  orgId: string;
  name: string;
  email: string;
  role: AdminRole;
  active: boolean;
  createdAt: string;
  /** Present only for accounts created inside local development mode. */
  localPassword?: string;
}

export type SchemeStatus = "active" | "completed" | "archived";

export interface Scheme {
  id: string;
  orgId: string;
  name: string;
  /** Monthly contribution per member, in rupees. */
  monthlyAmount: number;
  /** Number of monthly contribution periods. */
  durationMonths: number;
  /** First contribution period, "YYYY-MM". */
  startMonth: string;
  /** Day of month contributions fall due (1-28). */
  dueDay: number;
  /** Maximum members allowed in the scheme. */
  memberLimit: number;
  status: SchemeStatus;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export type MemberStatus = "active" | "inactive" | "archived";

export interface Member {
  id: string;
  orgId: string;
  /** Human-facing unique id, e.g. "PK-0042". */
  memberCode: string;
  fullName: string;
  phone: string;
  address: string;
  joiningDate: string;
  status: MemberStatus;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

/** Join record: which member belongs to which scheme. */
export interface SchemeMembership {
  id: string;
  orgId: string;
  schemeId: string;
  memberId: string;
  joinedAt: string;
  active: boolean;
}

export type PaymentMethod = "cash" | "bank_transfer" | "upi" | "cheque" | "other";

export const PAYMENT_METHODS: readonly PaymentMethod[] = [
  "cash",
  "bank_transfer",
  "upi",
  "cheque",
  "other",
];

export const PAYMENT_METHOD_LABEL: Record<PaymentMethod, string> = {
  cash: "Cash",
  bank_transfer: "Bank Transfer",
  upi: "UPI",
  cheque: "Cheque",
  other: "Other",
};

export interface Payment {
  id: string;
  orgId: string;
  memberId: string;
  schemeId: string;
  /** Contribution period this payment settles, "YYYY-MM". */
  period: string;
  /** Amount received, in rupees. */
  amount: number;
  /** Calendar date the money was received, "YYYY-MM-DD". */
  paidOn: string;
  method: PaymentMethod;
  /** Name of the admin who physically received the cash. */
  receivedBy: string;
  referenceNo: string;
  notes: string;
  receiptNo: string;
  createdAt: string;
  createdByUid: string;
  createdByName: string;
  updatedAt: string | null;
  updatedByUid: string | null;
  updatedByName: string | null;
  /** True when a correction has been applied; originals live in the audit log. */
  corrected: boolean;
}

export type AuditAction = "create" | "update" | "void";

export interface PaymentAuditLog {
  id: string;
  orgId: string;
  paymentId: string;
  action: AuditAction;
  /** Field-level snapshot before the change (null for creates). */
  before: Partial<Payment> | null;
  after: Partial<Payment>;
  reason: string;
  actorUid: string;
  actorName: string;
  at: string;
}

export type ReminderChannel = "whatsapp";

export interface ReminderLog {
  id: string;
  orgId: string;
  memberId: string;
  schemeId: string;
  period: string;
  amount: number;
  channel: ReminderChannel;
  message: string;
  /**
   * Reminders are opened in WhatsApp by the administrator. We only ever record
   * that the message was PREPARED and the WhatsApp window opened — never that
   * it was delivered, which this app cannot know.
   */
  openedAt: string;
  actorUid: string;
  actorName: string;
}

export interface OrgSettings {
  id: string;
  orgId: string;
  organizationName: string;
  logoDataUrl: string;
  contactPhone: string;
  contactEmail: string;
  address: string;
  currencySymbol: string;
  currencyCode: string;
  defaultDueDay: number;
  defaultMonthlyAmount: number;
  defaultDurationMonths: number;
  defaultMemberLimit: number;
  reminderDay: number;
  reminderTemplate: string;
  receiptPrefix: string;
  updatedAt: string;
}

export const DEFAULT_REMINDER_TEMPLATE =
  "Dear {{memberName}}, this is a friendly reminder that your Kuri contribution of {{amount}} for {{month}} is pending. Kindly contact the Treasurer for payment. Thank you.";

export function defaultSettings(orgId: string): OrgSettings {
  return {
    id: "settings",
    orgId,
    organizationName: "MMS Sabha",
    logoDataUrl: "",
    contactPhone: "",
    contactEmail: "",
    address: "",
    currencySymbol: "₹",
    currencyCode: "INR",
    defaultDueDay: 10,
    defaultMonthlyAmount: 5000,
    defaultDurationMonths: 12,
    defaultMemberLimit: 60,
    reminderDay: 10,
    reminderTemplate: DEFAULT_REMINDER_TEMPLATE,
    receiptPrefix: "RCPT",
    updatedAt: new Date().toISOString(),
  };
}

/**
 * Per-period ledger entry. One document per (scheme, member, period) holding
 * the total collected so far. Written inside the same transaction as the
 * payment, which is what makes duplicate and over-collection impossible.
 */
export interface PeriodLedger {
  id: string;
  orgId: string;
  schemeId: string;
  memberId: string;
  period: string;
  dueAmount: number;
  paidAmount: number;
  paymentIds: string[];
  updatedAt: string;
}

export function ledgerId(schemeId: string, memberId: string, period: string): string {
  return `${schemeId}__${memberId}__${period}`;
}

export type CollectionName =
  | "users"
  | "members"
  | "schemes"
  | "schemeMemberships"
  | "payments"
  | "paymentAuditLogs"
  | "periodLedger"
  | "reminders"
  | "settings";
