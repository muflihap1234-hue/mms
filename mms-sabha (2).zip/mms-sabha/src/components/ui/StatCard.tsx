"use client";

import clsx from "clsx";
import Link from "next/link";
import type { ReactNode } from "react";

/** A single dashboard figure. Every value shown is computed from real records. */
export function StatCard({
  label,
  value,
  sub,
  icon,
  tone = "navy",
  href,
}: {
  label: string;
  value: string;
  sub?: string;
  icon?: ReactNode;
  tone?: "navy" | "forest" | "amber" | "red" | "slate";
  href?: string;
}) {
  const tones = {
    navy: "bg-navy-50 text-navy-700",
    forest: "bg-forest-50 text-forest-700",
    amber: "bg-amber-50 text-amber-700",
    red: "bg-red-50 text-red-600",
    slate: "bg-slate-100 text-slate-600",
  } as const;

  const body = (
    <div className="flex items-start justify-between gap-3">
      <div className="min-w-0">
        <p className="truncate text-sm font-medium text-slate-500">{label}</p>
        <p className="mt-1.5 text-2xl font-semibold tracking-tight text-navy-900">{value}</p>
        {sub ? <p className="mt-1 truncate text-xs text-slate-500">{sub}</p> : null}
      </div>
      {icon ? (
        <span className={clsx("grid h-10 w-10 shrink-0 place-items-center rounded-lg", tones[tone])}>
          {icon}
        </span>
      ) : null}
    </div>
  );

  const shell =
    "rounded-xl border border-slate-200 bg-white p-5 shadow-card transition-shadow";

  if (href) {
    return (
      <Link href={href} className={clsx(shell, "block hover:shadow-pop")}>
        {body}
      </Link>
    );
  }
  return <div className={shell}>{body}</div>;
}
