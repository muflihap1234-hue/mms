import clsx from "clsx";

/**
 * The organisation's logo, in two forms.
 *
 * The artwork is light-on-dark, so both forms sit on their own dark tile — that
 * keeps them legible on the white topbar and on printed receipts as well as on
 * the dark navy sidebar.
 *
 * - `BrandMark` is the small square tile (sidebar, topbar, receipt header). It
 *   uses a cropped mark, because the fine "SABHA / MEDIA WING" lettering in the
 *   full lockup is unreadable below roughly 120px.
 * - `BrandLockup` is the full logo, for places with room to show it properly.
 *
 * A logo uploaded in Settings always wins over the bundled artwork.
 */

export const BRAND_NAME = "MMS Sabha";
export const BRAND_TAGLINE = "Media Wing";
export const BRAND_LOGO_SRC = "/mms-sabha-logo.png";
export const BRAND_MARK_SRC = "/mms-sabha-mark.png";

const SIZES = {
  sm: "h-10 w-10 rounded-lg",
  md: "h-11 w-11 rounded-xl",
  lg: "h-12 w-12 rounded-lg",
} as const;

export function BrandMark({
  logoDataUrl,
  size = "sm",
  className,
}: {
  /** Logo uploaded through Settings, if any. */
  logoDataUrl?: string | null;
  size?: keyof typeof SIZES;
  className?: string;
}) {
  const src = logoDataUrl || BRAND_MARK_SRC;

  return (
    <span
      className={clsx(
        "grid shrink-0 place-items-center overflow-hidden bg-navy-950",
        SIZES[size],
        className,
      )}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={src} alt="" aria-hidden className="h-full w-full object-contain" />
    </span>
  );
}

/**
 * Sized by width only — the image keeps its own aspect ratio, so the lockup can
 * never be cropped or squashed whatever box it is dropped into.
 */
export function BrandLockup({
  logoDataUrl,
  className,
}: {
  logoDataUrl?: string | null;
  /** Width utility, e.g. "w-44". */
  className?: string;
}) {
  const src = logoDataUrl || BRAND_LOGO_SRC;

  return (
    <span className={clsx("block rounded-xl bg-navy-950 p-3", className)}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={src} alt={BRAND_NAME} className="block h-auto w-full" />
    </span>
  );
}
