"use client";

import { Download, FileSpreadsheet, FileText, Printer } from "lucide-react";
import { Button } from "@/components/ui";
import { useToast } from "@/components/ui/Toast";
import { exportCSV, exportPDF, exportXLSX, type Column } from "@/lib/export";

/** CSV / Excel / PDF / Print for any table in the app. */
export function ExportBar<T>({
  rows,
  columns,
  filename,
  title,
  subtitle,
  organization,
  disabled,
}: {
  rows: T[];
  columns: Column<T>[];
  filename: string;
  title: string;
  subtitle?: string;
  organization: string;
  disabled?: boolean;
}) {
  const toast = useToast();
  const empty = rows.length === 0;

  function guard(): boolean {
    if (empty) {
      toast.warning("There is nothing to export for the current filters.");
      return false;
    }
    return true;
  }

  return (
    <div className="flex flex-wrap gap-2 print:hidden">
      <Button
        variant="secondary"
        size="sm"
        disabled={disabled}
        icon={<Download className="h-4 w-4" aria-hidden />}
        onClick={() => {
          if (!guard()) return;
          exportCSV(rows, columns, filename);
          toast.success("CSV downloaded.");
        }}
      >
        CSV
      </Button>
      <Button
        variant="secondary"
        size="sm"
        disabled={disabled}
        icon={<FileSpreadsheet className="h-4 w-4" aria-hidden />}
        onClick={() => {
          if (!guard()) return;
          void exportXLSX(rows, columns, filename, title)
            .then(() => toast.success("Excel file downloaded."))
            .catch(() => toast.error("Could not build the Excel file."));
        }}
      >
        Excel
      </Button>
      <Button
        variant="secondary"
        size="sm"
        disabled={disabled}
        icon={<FileText className="h-4 w-4" aria-hidden />}
        onClick={() => {
          if (!guard()) return;
          void exportPDF(rows, columns, filename, { title, subtitle, organization })
            .then(() => toast.success("PDF downloaded."))
            .catch(() => toast.error("Could not build the PDF."));
        }}
      >
        PDF
      </Button>
      <Button
        variant="secondary"
        size="sm"
        icon={<Printer className="h-4 w-4" aria-hidden />}
        onClick={() => window.print()}
      >
        Print
      </Button>
    </div>
  );
}
