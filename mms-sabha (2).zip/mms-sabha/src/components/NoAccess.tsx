"use client";

import { ShieldAlert } from "lucide-react";
import { Card, EmptyState, LinkButton } from "@/components/ui";
import { useAuth } from "@/lib/auth/AuthProvider";
import { ROLE_LABEL } from "@/lib/types";

/** Shown when a signed-in administrator's role does not allow an action. */
export function NoAccess({ what }: { what: string }) {
  const { user } = useAuth();
  return (
    <Card>
      <EmptyState
        icon={<ShieldAlert className="h-8 w-8" aria-hidden />}
        title="Not available for your role"
        message={`Your account is a ${
          user ? ROLE_LABEL[user.role] : "member"
        }, which cannot ${what}. Ask the President if you need this access.`}
        action={
          <LinkButton href="/dashboard" variant="secondary" size="sm">
            Back to dashboard
          </LinkButton>
        }
      />
    </Card>
  );
}

/** Shown when a record id in the URL does not match any record. */
export function NotFoundCard({
  title,
  message,
  backHref,
  backLabel,
}: {
  title: string;
  message: string;
  backHref: string;
  backLabel: string;
}) {
  return (
    <Card>
      <EmptyState
        title={title}
        message={message}
        action={
          <LinkButton href={backHref} variant="secondary" size="sm">
            {backLabel}
          </LinkButton>
        }
      />
    </Card>
  );
}
