"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

import { Button, Card, CardHeader, Field, Input, Select, Textarea } from "@/components/ui";
import { useToast } from "@/components/ui/Toast";
import { useData } from "@/lib/DataProvider";
import { addMonths } from "@/lib/kuri";
import { money, monthLabel } from "@/lib/format";
import type { Scheme, SchemeStatus } from "@/lib/types";
import type { SchemeInput } from "@/lib/data/types";

const SUGGESTED_AMOUNTS = [4000, 5000, 6000];

export function SchemeForm({ scheme }: { scheme?: Scheme }) {
  const router = useRouter();
  const toast = useToast();
  const { snapshot, run } = useData();
  const s = snapshot.settings;
  const editing = Boolean(scheme);

  const [name, setName] = useState(scheme?.name ?? "");
  const [monthlyAmount, setMonthlyAmount] = useState(
    String(scheme?.monthlyAmount ?? s.defaultMonthlyAmount),
  );
  const [durationMonths, setDurationMonths] = useState(
    String(scheme?.durationMonths ?? s.defaultDurationMonths),
  );
  const [startMonth, setStartMonth] = useState(
    scheme?.startMonth ?? new Date().toISOString().slice(0, 7),
  );
  const [dueDay, setDueDay] = useState(String(scheme?.dueDay ?? s.defaultDueDay));
  const [memberLimit, setMemberLimit] = useState(
    String(scheme?.memberLimit ?? s.defaultMemberLimit),
  );
  const [status, setStatus] = useState<SchemeStatus>(scheme?.status ?? "active");
  const [notes, setNotes] = useState(scheme?.notes ?? "");
  const [busy, setBusy] = useState(false);

  const paymentsRecorded = scheme
    ? snapshot.payments.filter((p) => p.schemeId === scheme.id).length
    : 0;
  const amountLocked = editing && paymentsRecorded > 0;

  const duration = Number(durationMonths) || 0;
  const amount = Number(monthlyAmount) || 0;
  const limit = Number(memberLimit) || 0;
  const endMonth = duration > 0 ? addMonths(startMonth, duration - 1) : startMonth;

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const input: SchemeInput = {
        name: name.trim(),
        monthlyAmount: amount,
        durationMonths: duration,
        startMonth,
        dueDay: Number(dueDay),
        memberLimit: limit,
        status,
        notes: notes.trim(),
      };
      if (scheme) {
        await run((repo, actor) => repo.updateScheme(scheme.id, input, actor));
        toast.success("Scheme updated.");
        router.push(`/schemes/${scheme.id}`);
      } else {
        const created = await run((repo, actor) => repo.createScheme(input, actor));
        toast.success(`"${created.name}" created. Assign members to start collecting.`);
        router.push(`/schemes/${created.id}`);
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save the scheme.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-5 lg:grid-cols-3">
      <Card className="lg:col-span-2">
        <CardHeader title="Scheme details" />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Scheme name" required className="sm:col-span-2">
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              placeholder="e.g. MMS Sabha Kuri 2026 — ₹5,000"
            />
          </Field>

          <Field
            label="Monthly contribution (₹)"
            required
            hint={
              amountLocked
                ? `Locked: ${paymentsRecorded} payment(s) already recorded against this scheme.`
                : "Common amounts: ₹4,000 · ₹5,000 · ₹6,000"
            }
          >
            <Input
              type="number"
              min={1}
              step={1}
              value={monthlyAmount}
              onChange={(e) => setMonthlyAmount(e.target.value)}
              required
              disabled={amountLocked}
            />
          </Field>

          <Field label="Members allowed" required hint="Default is 60. Change it to suit the scheme.">
            <Input
              type="number"
              min={1}
              max={1000}
              step={1}
              value={memberLimit}
              onChange={(e) => setMemberLimit(e.target.value)}
              required
            />
          </Field>

          {!amountLocked ? (
            <div className="flex flex-wrap gap-2 sm:col-span-2">
              {SUGGESTED_AMOUNTS.map((a) => (
                <Button
                  key={a}
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => setMonthlyAmount(String(a))}
                >
                  {money(a)}
                </Button>
              ))}
            </div>
          ) : null}

          <Field label="Duration (months)" required hint="6 and 12 are typical; any value is allowed.">
            <Input
              type="number"
              min={1}
              max={120}
              step={1}
              value={durationMonths}
              onChange={(e) => setDurationMonths(e.target.value)}
              required
            />
          </Field>

          <Field label="Start month" required>
            <Input
              type="month"
              value={startMonth}
              onChange={(e) => setStartMonth(e.target.value)}
              required
            />
          </Field>

          <Field label="Monthly due date" required hint="Day of the month, 1 to 28.">
            <Input
              type="number"
              min={1}
              max={28}
              step={1}
              value={dueDay}
              onChange={(e) => setDueDay(e.target.value)}
              required
            />
          </Field>

          <Field label="Status" required>
            <Select value={status} onChange={(e) => setStatus(e.target.value as SchemeStatus)}>
              <option value="active">Active</option>
              <option value="completed">Completed</option>
              <option value="archived">Archived</option>
            </Select>
          </Field>

          <Field label="Notes" className="sm:col-span-2">
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Anything the committee should know about this scheme."
            />
          </Field>
        </div>

        <div className="mt-6 flex flex-wrap gap-2">
          <Button type="submit" loading={busy}>
            {editing ? "Save changes" : "Create scheme"}
          </Button>
          <Button type="button" variant="secondary" onClick={() => router.back()}>
            Cancel
          </Button>
        </div>
      </Card>

      <Card>
        <CardHeader title="Summary" subtitle="Calculated from the values on the left" />
        <dl className="space-y-3 text-sm">
          <div className="flex justify-between gap-3">
            <dt className="text-slate-500">Contribution period</dt>
            <dd className="text-right font-medium">
              {monthLabel(startMonth)} — {monthLabel(endMonth)}
            </dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-slate-500">Per member, total</dt>
            <dd className="tabular font-medium">{money(amount * duration)}</dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-slate-500">At full strength</dt>
            <dd className="tabular font-medium">{money(amount * duration * limit)}</dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-slate-500">Expected each month</dt>
            <dd className="tabular font-medium">{money(amount * limit)}</dd>
          </div>
        </dl>
        <p className="mt-4 border-t border-slate-100 pt-4 text-xs leading-relaxed text-slate-500">
          These are projections from the scheme settings and the member limit. Actual collection
          figures on the dashboard come only from payments that have been recorded.
        </p>
      </Card>
    </form>
  );
}
