"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

import { Button, Card, CardHeader, Field, Input, Select, Textarea } from "@/components/ui";
import { useToast } from "@/components/ui/Toast";
import { useData } from "@/lib/DataProvider";
import { nextMemberCode } from "@/lib/kuri";
import { todayISO } from "@/lib/format";
import type { Member, MemberStatus } from "@/lib/types";
import type { MemberInput } from "@/lib/data/types";

export function MemberForm({ member }: { member?: Member }) {
  const router = useRouter();
  const toast = useToast();
  const { snapshot, run } = useData();
  const editing = Boolean(member);

  const [memberCode, setMemberCode] = useState(
    member?.memberCode ?? nextMemberCode(snapshot.members),
  );
  const [fullName, setFullName] = useState(member?.fullName ?? "");
  const [phone, setPhone] = useState(member?.phone ?? "");
  const [address, setAddress] = useState(member?.address ?? "");
  const [joiningDate, setJoiningDate] = useState(member?.joiningDate ?? todayISO());
  const [status, setStatus] = useState<MemberStatus>(member?.status ?? "active");
  const [notes, setNotes] = useState(member?.notes ?? "");

  // Only offered when creating: assign straight into a scheme.
  const [schemeId, setSchemeId] = useState("");
  const [busy, setBusy] = useState(false);

  const openSchemes = snapshot.schemes.filter((s) => s.status === "active");

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const input: MemberInput = {
        memberCode: memberCode.trim(),
        fullName: fullName.trim(),
        phone: phone.trim(),
        address: address.trim(),
        joiningDate,
        status,
        notes: notes.trim(),
      };

      if (member) {
        await run((repo, actor) => repo.updateMember(member.id, input, actor));
        toast.success("Member updated.");
        router.push(`/members/${member.id}`);
        return;
      }

      const created = await run((repo, actor) => repo.createMember(input, actor));
      if (schemeId) {
        try {
          await run((repo) => repo.assignMember(schemeId, created.id, joiningDate));
          toast.success(`${created.fullName} added and assigned to the scheme.`);
        } catch (err) {
          toast.warning(
            `${created.fullName} was added, but could not be assigned: ${
              err instanceof Error ? err.message : "unknown error"
            }`,
          );
        }
      } else {
        toast.success(`${created.fullName} added.`);
      }
      router.push(`/members/${created.id}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save the member.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-5 lg:grid-cols-3">
      <Card className="lg:col-span-2">
        <CardHeader title="Member details" />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Member ID" required hint="Must be unique. Suggested automatically.">
            <Input
              value={memberCode}
              onChange={(e) => setMemberCode(e.target.value)}
              required
            />
          </Field>

          <Field label="Full name" required>
            <Input
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              required
              placeholder="e.g. Fathima Beevi"
            />
          </Field>

          <Field label="Phone number" required hint="Used for WhatsApp reminders.">
            <Input
              type="tel"
              inputMode="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
              placeholder="e.g. 98470 12345"
            />
          </Field>

          <Field label="Joining date" required>
            <Input
              type="date"
              value={joiningDate}
              onChange={(e) => setJoiningDate(e.target.value)}
              required
            />
          </Field>

          <Field label="Address" className="sm:col-span-2">
            <Textarea
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="House name, place, post office"
            />
          </Field>

          <Field label="Status" required>
            <Select value={status} onChange={(e) => setStatus(e.target.value as MemberStatus)}>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="archived">Archived</option>
            </Select>
          </Field>

          {!editing ? (
            <Field
              label="Assign to scheme"
              hint={
                openSchemes.length === 0
                  ? "No active scheme yet. You can assign the member later."
                  : "Optional. You can also assign from the scheme page."
              }
            >
              <Select
                value={schemeId}
                onChange={(e) => setSchemeId(e.target.value)}
                disabled={openSchemes.length === 0}
              >
                <option value="">Do not assign now</option>
                {openSchemes.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </Select>
            </Field>
          ) : null}

          <Field label="Notes" className="sm:col-span-2">
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Anything worth recording about this member."
            />
          </Field>
        </div>

        <div className="mt-6 flex flex-wrap gap-2">
          <Button type="submit" loading={busy}>
            {editing ? "Save changes" : "Add member"}
          </Button>
          <Button type="button" variant="secondary" onClick={() => router.back()}>
            Cancel
          </Button>
        </div>
      </Card>

      <Card>
        <CardHeader title="Duplicate protection" />
        <p className="text-sm leading-relaxed text-slate-600">
          A member cannot be saved if the Member ID is already in use, or if another active member
          has the same name and phone number. This keeps one person from being counted twice in a
          scheme.
        </p>
        <p className="mt-4 border-t border-slate-100 pt-4 text-xs leading-relaxed text-slate-500">
          Archiving a member keeps every payment they have made. Payment records are never deleted.
        </p>
      </Card>
    </form>
  );
}
