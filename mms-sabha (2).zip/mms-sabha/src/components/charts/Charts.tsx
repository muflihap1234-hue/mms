"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { money, monthLabel } from "@/lib/format";
import type { MonthlySeriesPoint } from "@/lib/kuri";

const AXIS = { fontSize: 11, fill: "#64748b" };

function compact(value: number): string {
  if (value >= 10_000_000) return `${(value / 10_000_000).toFixed(1)}Cr`;
  if (value >= 100_000) return `${(value / 100_000).toFixed(1)}L`;
  if (value >= 1_000) return `${Math.round(value / 1_000)}k`;
  return String(value);
}

export function MonthlyCollectionChart({
  data,
  currency,
}: {
  data: MonthlySeriesPoint[];
  currency: string;
}) {
  return (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
          <XAxis
            dataKey="period"
            tickFormatter={(v: string) => monthLabel(v).replace(" ", "\n")}
            tick={AXIS}
            tickLine={false}
            axisLine={{ stroke: "#e2e8f0" }}
            interval={0}
            height={40}
          />
          <YAxis
            tick={AXIS}
            tickLine={false}
            axisLine={false}
            tickFormatter={(v: number) => compact(v)}
            width={48}
          />
          <Tooltip
            formatter={(v) => money(Number(v), currency)}
            labelFormatter={(l) => monthLabel(String(l))}
            contentStyle={{
              borderRadius: 8,
              border: "1px solid #e2e8f0",
              fontSize: 12,
              boxShadow: "0 8px 24px -4px rgb(16 24 40 / 0.12)",
            }}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Bar dataKey="expected" name="Expected" fill="#c0cde1" radius={[4, 4, 0, 0]} />
          <Bar dataKey="collected" name="Collected" fill="#2d6952" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function PaidPendingChart({
  paid,
  pending,
}: {
  paid: number;
  pending: number;
}) {
  const data = [
    { name: "Paid", value: paid, fill: "#2d6952" },
    { name: "Pending", value: pending, fill: "#f59e0b" },
  ];
  const total = paid + pending;

  if (total === 0) {
    return (
      <div className="grid h-72 place-items-center text-sm text-slate-500">
        No contributions are due yet this month.
      </div>
    );
  }

  return (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            innerRadius={62}
            outerRadius={92}
            paddingAngle={2}
            label={(entry: { name?: string; value?: number }) =>
              `${entry.name}: ${entry.value}`
            }
          >
            {data.map((d) => (
              <Cell key={d.name} fill={d.fill} />
            ))}
          </Pie>
          <Tooltip
            formatter={(v, n) => [`${v} member${Number(v) === 1 ? "" : "s"}`, String(n)]}
            contentStyle={{
              borderRadius: 8,
              border: "1px solid #e2e8f0",
              fontSize: 12,
            }}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

export function SchemeCollectionChart({
  data,
  currency,
}: {
  data: Array<{ name: string; collected: number; pending: number }>;
  currency: string;
}) {
  return (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ top: 8, right: 16, left: 8, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
          <XAxis
            type="number"
            tick={AXIS}
            tickLine={false}
            axisLine={false}
            tickFormatter={(v: number) => compact(v)}
          />
          <YAxis
            type="category"
            dataKey="name"
            tick={AXIS}
            tickLine={false}
            axisLine={false}
            width={120}
          />
          <Tooltip
            formatter={(v) => money(Number(v), currency)}
            contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0", fontSize: 12 }}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} />
          <Bar dataKey="collected" name="Collected" fill="#2d6952" radius={[0, 4, 4, 0]} />
          <Bar dataKey="pending" name="Pending" fill="#f59e0b" radius={[0, 4, 4, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
