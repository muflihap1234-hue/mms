"use client";

import clsx from "clsx";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { X } from "lucide-react";

import { NAV_ITEMS } from "./nav";
import { useAuth } from "@/lib/auth/AuthProvider";
import { useData } from "@/lib/DataProvider";
import { BRAND_NAME, BRAND_TAGLINE, BrandMark } from "@/components/ui/BrandMark";

export function Sidebar({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const pathname = usePathname();
  const { can } = useAuth();
  const { snapshot } = useData();
  const orgName = snapshot.settings.organizationName || BRAND_NAME;

  const items = NAV_ITEMS.filter((item) => !item.requires || can(item.requires));

  return (
    <>
      {open ? (
        <button
          type="button"
          aria-label="Close menu"
          onClick={onClose}
          className="fixed inset-0 z-30 bg-navy-950/40 lg:hidden"
        />
      ) : null}

      <aside
        className={clsx(
          "fixed inset-y-0 left-0 z-40 flex w-72 flex-col border-r border-navy-800/60 bg-navy-900 transition-transform lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center justify-between gap-2 px-5 py-5">
          <Link href="/dashboard" className="flex min-w-0 items-center gap-3">
            <BrandMark logoDataUrl={snapshot.settings.logoDataUrl} size="sm" />
            <span className="min-w-0">
              <span className="block truncate text-sm font-semibold text-white">{orgName}</span>
              <span className="block text-xs text-navy-300">{BRAND_TAGLINE}</span>
            </span>
          </Link>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close menu"
            className="rounded p-1 text-navy-300 hover:bg-navy-800 hover:text-white lg:hidden"
          >
            <X className="h-5 w-5" aria-hidden />
          </button>
        </div>

        <nav className="scrollbar-thin flex-1 overflow-y-auto px-3 pb-6">
          <ul className="space-y-1">
            {items.map((item) => {
              const active =
                pathname === item.href || pathname.startsWith(`${item.href}/`);
              const Icon = item.icon;
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    onClick={onClose}
                    aria-current={active ? "page" : undefined}
                    className={clsx(
                      "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                      active
                        ? "bg-navy-800 text-white"
                        : "text-navy-200 hover:bg-navy-800/70 hover:text-white",
                    )}
                  >
                    <Icon className="h-[18px] w-[18px] shrink-0" aria-hidden />
                    <span className="truncate">{item.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <p className="border-t border-navy-800 px-5 py-4 text-[11px] leading-relaxed text-navy-400">
          All figures are calculated from recorded payments. Payments are never
          created or marked paid automatically.
        </p>
      </aside>
    </>
  );
}
