"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import clsx from "clsx";
import { Bell, LogOut, Menu, Search, UserRound } from "lucide-react";

import { useAuth } from "@/lib/auth/AuthProvider";
import { useData } from "@/lib/DataProvider";
import { BRAND_NAME, BrandMark } from "@/components/ui/BrandMark";
import { currentPeriod, initials, money, monthLabelLong } from "@/lib/format";
import { pendingRows } from "@/lib/kuri";
import { ROLE_LABEL } from "@/lib/types";

export function Topbar({ onMenu }: { onMenu: () => void }) {
  const router = useRouter();
  const { user, logout } = useAuth();
  const { snapshot } = useData();
  const [term, setTerm] = useState("");
  const [openPanel, setOpenPanel] = useState<"none" | "bell" | "profile">("none");
  const wrapRef = useRef<HTMLDivElement>(null);

  const period = currentPeriod();

  const pending = useMemo(
    () =>
      pendingRows({
        members: snapshot.members,
        schemes: snapshot.schemes,
        memberships: snapshot.memberships,
        ledgers: snapshot.ledgers,
        asOfPeriod: period,
      }),
    [snapshot, period],
  );

  const thisMonth = pending.filter((r) => r.period === period);

  const matches = useMemo(() => {
    const q = term.trim().toLowerCase();
    if (q.length < 2) return [];
    return snapshot.members
      .filter(
        (m) =>
          m.fullName.toLowerCase().includes(q) ||
          m.memberCode.toLowerCase().includes(q) ||
          m.phone.replace(/\D/g, "").includes(q.replace(/\D/g, "")),
      )
      .slice(0, 6);
  }, [term, snapshot.members]);

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) {
        setOpenPanel("none");
      }
    }
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);

  return (
    <header className="app-topbar sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur print:hidden">
      <div className="flex items-center gap-3 px-4 py-3 lg:px-6">
        <button
          type="button"
          onClick={onMenu}
          aria-label="Open menu"
          className="rounded-lg p-2 text-navy-700 hover:bg-slate-100 lg:hidden"
        >
          <Menu className="h-5 w-5" aria-hidden />
        </button>

        {/* On large screens the sidebar header carries the mark at the top left,
            so it is only repeated here once the sidebar is off-canvas. */}
        <BrandMark logoDataUrl={snapshot.settings.logoDataUrl} size="sm" className="lg:hidden" />

        <p className="hidden min-w-0 truncate text-sm font-semibold text-navy-900 sm:block lg:text-base">
          {snapshot.settings.organizationName || BRAND_NAME}
        </p>

        {/* Global member search */}
        <div className="relative ml-auto w-full max-w-sm">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
            aria-hidden
          />
          <input
            type="search"
            value={term}
            onChange={(e) => setTerm(e.target.value)}
            placeholder="Search members by name, ID or phone"
            aria-label="Search members"
            className="w-full rounded-lg border border-slate-300 bg-white py-2 pl-9 pr-3 text-sm placeholder:text-slate-400 focus:border-navy-500 focus:outline-none focus:ring-2 focus:ring-navy-500/20"
          />
          {matches.length > 0 ? (
            <ul className="absolute left-0 right-0 top-full z-30 mt-1 overflow-hidden rounded-lg border border-slate-200 bg-white shadow-pop">
              {matches.map((m) => (
                <li key={m.id}>
                  <button
                    type="button"
                    onClick={() => {
                      setTerm("");
                      router.push(`/members/${m.id}`);
                    }}
                    className="flex w-full items-center justify-between gap-3 px-3 py-2.5 text-left text-sm hover:bg-slate-50"
                  >
                    <span className="min-w-0">
                      <span className="block truncate font-medium text-navy-900">{m.fullName}</span>
                      <span className="block text-xs text-slate-500">
                        {m.memberCode} · {m.phone}
                      </span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          ) : null}
        </div>

        <div className="relative flex items-center gap-1" ref={wrapRef}>
          {/* Notifications */}
          <button
            type="button"
            onClick={() => setOpenPanel((p) => (p === "bell" ? "none" : "bell"))}
            aria-label="Notifications"
            className="relative rounded-lg p-2 text-navy-700 hover:bg-slate-100"
          >
            <Bell className="h-5 w-5" aria-hidden />
            {thisMonth.length > 0 ? (
              <span className="absolute right-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-red-600 px-1 text-[10px] font-semibold text-white">
                {thisMonth.length > 99 ? "99+" : thisMonth.length}
              </span>
            ) : null}
          </button>

          {openPanel === "bell" ? (
            <div className="absolute right-0 top-full z-30 mt-2 w-80 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-pop">
              <div className="border-b border-slate-100 px-4 py-3">
                <p className="text-sm font-semibold text-navy-900">
                  {monthLabelLong(period)} collection
                </p>
                <p className="mt-0.5 text-xs text-slate-500">
                  {thisMonth.length === 0
                    ? "Nothing outstanding for this month."
                    : `${thisMonth.length} contribution${thisMonth.length === 1 ? "" : "s"} pending · ${money(
                        thisMonth.reduce((s, r) => s + r.pendingAmount, 0),
                        snapshot.settings.currencySymbol,
                      )}`}
                </p>
              </div>
              <ul className="max-h-64 overflow-y-auto">
                {thisMonth.slice(0, 6).map((r) => (
                  <li key={`${r.memberId}-${r.schemeId}-${r.period}`}>
                    <Link
                      href={`/members/${r.memberId}`}
                      onClick={() => setOpenPanel("none")}
                      className="flex items-center justify-between gap-2 px-4 py-2.5 text-sm hover:bg-slate-50"
                    >
                      <span className="min-w-0 truncate text-navy-900">{r.memberName}</span>
                      <span className="tabular shrink-0 text-xs font-medium text-red-600">
                        {money(r.pendingAmount, snapshot.settings.currencySymbol)}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
              <div className="border-t border-slate-100 p-2">
                <Link
                  href="/reminders"
                  onClick={() => setOpenPanel("none")}
                  className="block rounded-lg px-3 py-2 text-center text-sm font-medium text-navy-800 hover:bg-slate-50"
                >
                  Open WhatsApp reminders
                </Link>
              </div>
            </div>
          ) : null}

          {/* Profile */}
          <button
            type="button"
            onClick={() => setOpenPanel((p) => (p === "profile" ? "none" : "profile"))}
            className="flex items-center gap-2 rounded-lg p-1.5 hover:bg-slate-100"
            aria-label="Profile menu"
          >
            <span className="grid h-8 w-8 place-items-center rounded-full bg-navy-800 text-xs font-semibold text-white">
              {user ? initials(user.name) : <UserRound className="h-4 w-4" aria-hidden />}
            </span>
          </button>

          {openPanel === "profile" ? (
            <div className="absolute right-0 top-full z-30 mt-2 w-60 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-pop">
              <div className="border-b border-slate-100 px-4 py-3">
                <p className="truncate text-sm font-semibold text-navy-900">{user?.name}</p>
                <p className="truncate text-xs text-slate-500">{user?.email}</p>
                <p className="mt-1 text-xs font-medium text-forest-700">
                  {user ? ROLE_LABEL[user.role] : ""}
                </p>
              </div>
              <div className="p-2">
                <Link
                  href="/settings"
                  onClick={() => setOpenPanel("none")}
                  className="block rounded-lg px-3 py-2 text-sm text-navy-800 hover:bg-slate-50"
                >
                  Settings
                </Link>
                <button
                  type="button"
                  onClick={() => {
                    setOpenPanel("none");
                    void logout();
                  }}
                  className={clsx(
                    "flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm",
                    "text-red-700 hover:bg-red-50",
                  )}
                >
                  <LogOut className="h-4 w-4" aria-hidden />
                  Sign out
                </button>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </header>
  );
}
