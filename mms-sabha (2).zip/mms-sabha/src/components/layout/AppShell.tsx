"use client";

import { useEffect, useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import { TriangleAlert } from "lucide-react";

import { Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";
import { useAuth } from "@/lib/auth/AuthProvider";
import { useData } from "@/lib/DataProvider";
import { Alert, Spinner } from "@/components/ui";

/**
 * Protects every dashboard route. An unauthenticated visitor is sent to the
 * login screen; no page content is rendered before the session is known.
 */
export function AppShell({ children }: { children: ReactNode }) {
  const { user, loading, mode } = useAuth();
  const { loading: dataLoading, error } = useData();
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  if (loading || !user) {
    return (
      <div className="grid min-h-screen place-items-center bg-slate-50">
        <Spinner label="Checking your session" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar open={menuOpen} onClose={() => setMenuOpen(false)} />
      <div className="lg:pl-72">
        <Topbar onMenu={() => setMenuOpen(true)} />

        {mode === "local" ? (
          <div className="flex items-start gap-2 border-b border-amber-200 bg-amber-50 px-4 py-2.5 text-xs text-amber-900 lg:px-6 print:hidden">
            <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
            <p>
              <strong className="font-semibold">Local development mode.</strong> Firebase is not
              configured, so every record you create is saved in this browser only. It is not
              stored in any cloud database, not shared with other devices or administrators, and
              not backed up. Add your Firebase keys to <code>.env.local</code> to switch to the
              cloud.
            </p>
          </div>
        ) : null}

        <main className="px-4 py-6 lg:px-6 lg:py-8">
          {error ? (
            <div className="mb-5">
              <Alert tone="danger" title="Could not load records">
                {error}
              </Alert>
            </div>
          ) : null}
          {dataLoading ? <Spinner label="Loading records" /> : children}
        </main>
      </div>
    </div>
  );
}
