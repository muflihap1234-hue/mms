import {
  BadgeIndianRupee,
  Bell,
  CircleUser,
  Clock,
  FileBarChart,
  LayoutDashboard,
  Layers,
  Settings,
  ShieldCheck,
  Users,
} from "lucide-react";
import type { Capability } from "@/lib/types";

export interface NavItem {
  href: string;
  label: string;
  icon: typeof LayoutDashboard;
  /** Hidden when the signed-in role lacks this capability. */
  requires?: Capability;
}

export const NAV_ITEMS: readonly NavItem[] = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/schemes", label: "Kuri Schemes", icon: Layers },
  { href: "/members", label: "Members", icon: Users },
  { href: "/payments", label: "Payments", icon: BadgeIndianRupee },
  { href: "/history", label: "Payment History", icon: Clock },
  { href: "/pending", label: "Pending Payments", icon: CircleUser },
  { href: "/reminders", label: "WhatsApp Reminders", icon: Bell },
  { href: "/reports", label: "Reports", icon: FileBarChart },
  { href: "/admins", label: "Admin Management", icon: ShieldCheck, requires: "admin:manage" },
  { href: "/settings", label: "Settings", icon: Settings },
];
