"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { KeyRound, Landmark, ShieldCheck, TriangleAlert } from "lucide-react";

import { useAuth } from "@/lib/auth/AuthProvider";
import { Alert, Button, Field, Input } from "@/components/ui";
import { BRAND_NAME, BrandLockup, BrandMark } from "@/components/ui/BrandMark";
import { missingFirebaseKeys } from "@/lib/firebase";

export default function LoginPage() {
  const router = useRouter();
  const { mode, user, loading, needsBootstrap, signIn, bootstrap, error } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && user) router.replace("/dashboard");
  }, [loading, user, router]);

  const setupMode = mode === "local" && needsBootstrap;

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setFormError(null);
    try {
      if (setupMode) {
        await bootstrap({ name, email, password });
      } else {
        await signIn(email, password);
      }
      router.replace("/dashboard");
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Could not sign in.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="grid min-h-screen lg:grid-cols-2">
      {/* Brand panel */}
      <section className="relative hidden flex-col justify-between bg-navy-900 p-12 lg:flex">
        <div>
          <BrandLockup className="w-40" />
          <p className="mt-3 text-sm text-navy-300">Contribution Management</p>
        </div>

        <div className="max-w-md">
          <h1 className="text-3xl font-semibold leading-tight text-white">
            Every rupee accounted for, every month.
          </h1>
          <p className="mt-4 text-sm leading-relaxed text-navy-200">
            Schemes, members, monthly cash contributions, pending balances,
            WhatsApp reminders and financial reports — in one place, for the
            committee that runs them.
          </p>
          <ul className="mt-8 space-y-3 text-sm text-navy-200">
            <li className="flex gap-3">
              <ShieldCheck className="h-5 w-5 shrink-0 text-forest-400" aria-hidden />
              Only authorized administrators can record a payment.
            </li>
            <li className="flex gap-3">
              <Landmark className="h-5 w-5 shrink-0 text-forest-400" aria-hidden />
              Every correction keeps the original figures in the audit history.
            </li>
            <li className="flex gap-3">
              <KeyRound className="h-5 w-5 shrink-0 text-forest-400" aria-hidden />
              No payment is ever created or marked paid automatically.
            </li>
          </ul>
        </div>

        <p className="text-xs text-navy-400">Amounts in Indian Rupees (₹)</p>
      </section>

      {/* Form panel */}
      <section className="flex items-center justify-center bg-slate-50 px-6 py-12">
        <div className="w-full max-w-sm">
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <BrandMark size="md" />
            <div>
              <p className="font-semibold text-navy-900">{BRAND_NAME}</p>
              <p className="text-xs text-slate-500">Contribution Management</p>
            </div>
          </div>

          <h2 className="text-2xl font-semibold text-navy-900">
            {setupMode ? "Create the first administrator" : "Administrator sign in"}
          </h2>
          <p className="mt-1.5 text-sm text-slate-500">
            {setupMode
              ? "This account becomes the President and can add the Treasurer and other administrators afterwards."
              : "Sign in with the account your committee gave you."}
          </p>

          {mode === "local" ? (
            <div className="mt-5">
              <Alert tone="warning" title="Local development mode">
                Firebase is not configured
                {missingFirebaseKeys.length > 0
                  ? ` (missing: ${missingFirebaseKeys.join(", ")})`
                  : ""}
                , so records are kept in this browser only and are not stored in any cloud
                database. Copy <code>.env.local.example</code> to <code>.env.local</code> and fill
                in your Firebase keys to run against the cloud.
              </Alert>
            </div>
          ) : null}

          <form onSubmit={onSubmit} className="mt-6 space-y-4">
            {setupMode ? (
              <Field label="Full name" required>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="name"
                  required
                  placeholder="e.g. Abdul Rahman"
                />
              </Field>
            ) : null}

            <Field label="Email" required>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                required
                placeholder="you@example.com"
              />
            </Field>

            <Field
              label="Password"
              required
              hint={setupMode ? "At least 6 characters." : undefined}
            >
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete={setupMode ? "new-password" : "current-password"}
                required
                minLength={setupMode ? 6 : undefined}
              />
            </Field>

            {formError || error ? (
              <div className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2.5 text-sm text-red-700">
                <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
                <p>{formError ?? error}</p>
              </div>
            ) : null}

            <Button type="submit" loading={busy} className="w-full">
              {setupMode ? "Create account and continue" : "Sign in"}
            </Button>
          </form>

          {mode === "firebase" ? (
            <p className="mt-6 text-xs leading-relaxed text-slate-500">
              Accounts are created by your President under Admin Management. If you cannot sign
              in, ask them to confirm your email is on the administrator list.
            </p>
          ) : null}
        </div>
      </section>
    </main>
  );
}
