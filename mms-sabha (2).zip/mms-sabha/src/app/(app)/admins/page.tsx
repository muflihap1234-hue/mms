"use client";

import { useState } from "react";
import { Plus, ShieldCheck } from "lucide-react";

import {
  Alert,
  Badge,
  Button,
  Card,
  CardHeader,
  Dialog,
  Field,
  Input,
  PageHeader,
  Select,
  Table,
  Td,
  Th,
  Tr,
} from "@/components/ui";
import { useToast } from "@/components/ui/Toast";
import { NoAccess } from "@/components/NoAccess";
import { useData } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import { dateLabel } from "@/lib/format";
import { ADMIN_ROLES, ROLE_LABEL, type AdminRole } from "@/lib/types";

export default function AdminManagementPage() {
  const { snapshot, run } = useData();
  const { can, user, mode } = useAuth();
  const toast = useToast();

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<AdminRole>("treasurer");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  if (!can("admin:manage")) return <NoAccess what="manage administrator accounts" />;

  const admins = [...snapshot.users].sort((a, b) => a.name.localeCompare(b.name));

  async function onCreate(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await run((repo, actor) => repo.createAdmin({ name, email, role, password }, actor));
      toast.success(
        mode === "local"
          ? `${name} can now sign in with that email and password.`
          : `${email} added to the administrator list.`,
      );
      setOpen(false);
      setName("");
      setEmail("");
      setPassword("");
      setRole("treasurer");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not add the administrator.");
    } finally {
      setBusy(false);
    }
  }

  async function changeRole(id: string, next: AdminRole) {
    try {
      await run((repo, actor) => repo.updateAdmin(id, { role: next }, actor));
      toast.success("Role updated.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not update the role.");
    }
  }

  async function toggleActive(id: string, active: boolean) {
    try {
      await run((repo, actor) => repo.updateAdmin(id, { active }, actor));
      toast.success(active ? "Account enabled." : "Account disabled.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not update the account.");
    }
  }

  return (
    <>
      <PageHeader
        title="Admin Management"
        subtitle="Only the people listed here can open the dashboard. Ordinary members have no access."
        actions={
          <Button onClick={() => setOpen(true)} icon={<Plus className="h-4 w-4" aria-hidden />}>
            Add administrator
          </Button>
        }
      />

      <div className="mb-5 space-y-4">
        <Alert tone="info" title="What each role can do">
          <ul className="mt-1 space-y-1 text-sm">
            <li>
              <strong>President</strong> — everything, including adding and removing
              administrators.
            </li>
            <li>
              <strong>Treasurer</strong> — schemes, members, payments, corrections, reports and
              settings.
            </li>
            <li>
              <strong>Additional Admin</strong> — record payments, manage members, view reports and
              send reminders. Cannot correct payments, change schemes or change settings.
            </li>
          </ul>
        </Alert>

        {mode === "firebase" ? (
          <Alert tone="warning" title="How accounts work in cloud mode">
            Adding someone here puts their email on the access list and sets their role. They also
            need a Firebase Authentication account with the same email, created once in the
            Firebase console (Authentication → Users → Add user). Creating sign-in credentials
            from inside the app would require Cloud Functions, which are only on Firebase&apos;s
            paid plan. Until an Auth account exists, the record on this page grants nothing.
          </Alert>
        ) : null}
      </div>

      <Card padded={false}>
        <div className="p-5 pb-0">
          <CardHeader
            title={`${admins.length} administrator${admins.length === 1 ? "" : "s"}`}
            subtitle="Two or three is typical for a Palli committee."
          />
        </div>
        <Table>
          <thead>
            <tr>
              <Th>Name</Th>
              <Th>Email</Th>
              <Th>Role</Th>
              <Th>Added</Th>
              <Th>Status</Th>
              <Th />
            </tr>
          </thead>
          <tbody>
            {admins.map((a) => {
              const isSelf = a.id === user?.id;
              return (
                <Tr key={a.id}>
                  <Td>
                    <span className="font-medium text-navy-900">{a.name}</span>
                    {isSelf ? (
                      <Badge tone="info" className="ml-2">
                        You
                      </Badge>
                    ) : null}
                  </Td>
                  <Td className="text-slate-600">{a.email}</Td>
                  <Td>
                    {isSelf ? (
                      <Badge tone="success">{ROLE_LABEL[a.role]}</Badge>
                    ) : (
                      <Select
                        value={a.role}
                        onChange={(e) => void changeRole(a.id, e.target.value as AdminRole)}
                        aria-label={`Role for ${a.name}`}
                        className="max-w-[12rem] py-1.5 text-sm"
                      >
                        {ADMIN_ROLES.map((r) => (
                          <option key={r} value={r}>
                            {ROLE_LABEL[r]}
                          </option>
                        ))}
                      </Select>
                    )}
                  </Td>
                  <Td className="whitespace-nowrap text-slate-600">{dateLabel(a.createdAt)}</Td>
                  <Td>
                    {a.active ? (
                      <Badge tone="success">Active</Badge>
                    ) : (
                      <Badge tone="danger">Disabled</Badge>
                    )}
                  </Td>
                  <Td align="right">
                    {isSelf ? null : (
                      <Button
                        size="sm"
                        variant={a.active ? "secondary" : "success"}
                        onClick={() => void toggleActive(a.id, !a.active)}
                      >
                        {a.active ? "Disable" : "Enable"}
                      </Button>
                    )}
                  </Td>
                </Tr>
              );
            })}
          </tbody>
        </Table>
      </Card>

      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title="Add administrator"
        footer={
          <>
            <Button variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={onCreate}
              loading={busy}
              disabled={!name.trim() || !email.trim() || (mode === "local" && password.length < 6)}
              icon={<ShieldCheck className="h-4 w-4" aria-hidden />}
            >
              Add
            </Button>
          </>
        }
      >
        <form onSubmit={onCreate} className="space-y-4">
          <Field label="Full name" required>
            <Input value={name} onChange={(e) => setName(e.target.value)} required />
          </Field>
          <Field label="Email" required>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </Field>
          <Field label="Role" required>
            <Select value={role} onChange={(e) => setRole(e.target.value as AdminRole)}>
              {ADMIN_ROLES.map((r) => (
                <option key={r} value={r}>
                  {ROLE_LABEL[r]}
                </option>
              ))}
            </Select>
          </Field>
          {mode === "local" ? (
            <Field
              label="Password"
              required
              hint="Local mode only. This password is stored in this browser, not in any cloud service."
            >
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                minLength={6}
                required
              />
            </Field>
          ) : (
            <Alert tone="info">
              Create a Firebase Authentication user with this same email in the Firebase console so
              they can sign in.
            </Alert>
          )}
        </form>
      </Dialog>
    </>
  );
}
