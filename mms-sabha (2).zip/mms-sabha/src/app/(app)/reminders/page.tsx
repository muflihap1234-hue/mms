"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { CalendarClock, CheckCircle2, MessageCircle } from "lucide-react";

import {
  Alert,
  Badge,
  Button,
  Card,
  CardHeader,
  Dialog,
  EmptyState,
  Field,
  PageHeader,
  Select,
  Table,
  Td,
  Textarea,
  Th,
  Tr,
} from "@/components/ui";
import { useToast } from "@/components/ui/Toast";
import { ExportBar } from "@/components/ExportBar";
import { useData } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import {
  currentPeriod,
  dateLabel,
  dateTimeLabel,
  money,
  monthLabel,
  waNumber,
} from "@/lib/format";
import { pendingRows, renderReminder, type PendingRow } from "@/lib/kuri";
import { stamp } from "@/lib/export";

export default function RemindersPage() {
  const { snapshot, run } = useData();
  const { can, user } = useAuth();
  const toast = useToast();
  const period = currentPeriod();
  const currency = snapshot.settings.currencySymbol;
  const s = snapshot.settings;

  const [schemeId, setSchemeId] = useState("all");
  const [monthFilter, setMonthFilter] = useState("all");
  const [review, setReview] = useState<{ row: PendingRow; message: string } | null>(null);

  const all = useMemo(
    () =>
      pendingRows({
        members: snapshot.members,
        schemes: snapshot.schemes,
        memberships: snapshot.memberships,
        ledgers: snapshot.ledgers,
        asOfPeriod: period,
      }),
    [snapshot, period],
  );

  const months = useMemo(() => [...new Set(all.map((r) => r.period))].sort().reverse(), [all]);

  const rows = useMemo(
    () =>
      all
        .filter((r) => (schemeId === "all" ? true : r.schemeId === schemeId))
        .filter((r) => (monthFilter === "all" ? true : r.period === monthFilter)),
    [all, schemeId, monthFilter],
  );

  const sentLog = useMemo(
    () => [...snapshot.reminders].sort((a, b) => b.openedAt.localeCompare(a.openedAt)).slice(0, 25),
    [snapshot.reminders],
  );

  function buildMessage(row: PendingRow): string {
    return renderReminder(s.reminderTemplate, {
      memberName: row.memberName,
      amount: money(row.pendingAmount, currency),
      month: monthLabel(row.period),
      organizationName: s.organizationName,
      schemeName: row.schemeName,
    });
  }

  function openReview(row: PendingRow) {
    setReview({ row, message: buildMessage(row) });
  }

  function openWhatsApp() {
    if (!review) return;
    const { row, message } = review;
    const number = waNumber(row.phone);
    if (number.length < 10) {
      toast.error(`${row.memberName} has no usable phone number. Update the member record first.`);
      return;
    }

    window.open(
      `https://wa.me/${number}?text=${encodeURIComponent(message)}`,
      "_blank",
      "noopener,noreferrer",
    );

    void run((repo) =>
      repo.logReminder({
        memberId: row.memberId,
        schemeId: row.schemeId,
        period: row.period,
        amount: row.pendingAmount,
        channel: "whatsapp",
        message,
        openedAt: new Date().toISOString(),
        actorUid: user?.id ?? "",
        actorName: user?.name ?? "",
      }),
    ).catch(() => undefined);

    setReview(null);
    toast.info("WhatsApp opened with the message ready. Press send there to deliver it.");
  }

  const today = new Date();
  const reminderThisMonth = `${period}-${String(s.reminderDay).padStart(2, "0")}`;
  const isReminderDay = today.getDate() === s.reminderDay;

  return (
    <>
      <PageHeader
        title="WhatsApp Reminders"
        subtitle="Review each message, then open WhatsApp to send it yourself."
        actions={
          <ExportBar
            rows={rows}
            columns={[
              { header: "Member", value: (r) => r.memberName },
              { header: "Phone", value: (r) => r.phone },
              { header: "Scheme", value: (r) => r.schemeName },
              { header: "Month", value: (r) => r.period },
              { header: "Pending (₹)", value: (r) => r.pendingAmount, align: "right" },
              { header: "Message", value: (r) => buildMessage(r) },
            ]}
            filename={stamp("reminder-list")}
            title="Reminder list"
            organization={s.organizationName}
          />
        }
      />

      <div className="mb-5">
        <Alert tone="info" title="How sending works">
          This module prepares a personalised message and opens WhatsApp with it filled in. You
          press send in WhatsApp — the app cannot deliver messages by itself. Automatic sending
          would need the official WhatsApp Business API, which is a paid service and is not
          configured here.
        </Alert>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <p className="text-sm text-slate-500">Members to remind</p>
          <p className="mt-1 text-2xl font-semibold text-navy-900">
            {new Set(rows.map((r) => r.memberId)).size}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            {rows.length} pending contribution{rows.length === 1 ? "" : "s"}
          </p>
        </Card>
        <Card>
          <p className="text-sm text-slate-500">Amount being chased</p>
          <p className="tabular mt-1 text-2xl font-semibold text-red-600">
            {money(
              rows.reduce((sum, r) => sum + r.pendingAmount, 0),
              currency,
            )}
          </p>
        </Card>
        <Card>
          <div className="flex items-start gap-3">
            <CalendarClock className="mt-0.5 h-5 w-5 shrink-0 text-navy-500" aria-hidden />
            <div>
              <p className="text-sm text-slate-500">Monthly reminder schedule</p>
              <p className="mt-1 font-semibold text-navy-900">
                Day {s.reminderDay} of each month
              </p>
              <p className="mt-1 text-xs text-slate-500">
                {isReminderDay
                  ? "Today is reminder day."
                  : `Next: ${dateLabel(reminderThisMonth)}`}
              </p>
            </div>
          </div>
        </Card>
      </div>

      <Card className="mt-5" padded={false}>
        <div className="p-5 pb-0">
          <CardHeader
            title="Pending members"
            subtitle="Each row shows the amount and month the message will mention."
          />
        </div>

        <div className="grid gap-3 border-y border-slate-200 p-4 sm:grid-cols-2 print:hidden">
          <Field label="Scheme">
            <Select value={schemeId} onChange={(e) => setSchemeId(e.target.value)}>
              <option value="all">All schemes</option>
              {snapshot.schemes.map((sc) => (
                <option key={sc.id} value={sc.id}>
                  {sc.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Month">
            <Select value={monthFilter} onChange={(e) => setMonthFilter(e.target.value)}>
              <option value="all">All months due</option>
              {months.map((m) => (
                <option key={m} value={m}>
                  {monthLabel(m)}
                </option>
              ))}
            </Select>
          </Field>
        </div>

        {rows.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={<CheckCircle2 className="h-8 w-8 text-forest-500" aria-hidden />}
              title="No reminders needed"
              message="Every contribution that has fallen due is collected in full."
            />
          </div>
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Member</Th>
                <Th>Scheme</Th>
                <Th>Due month</Th>
                <Th align="right">Pending amount</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <Tr key={`${r.schemeId}-${r.memberId}-${r.period}`}>
                  <Td>
                    <Link href={`/members/${r.memberId}`} className="font-medium hover:underline">
                      {r.memberName}
                    </Link>
                    <span className="block text-xs text-slate-500">
                      {r.memberCode} · {r.phone || "no phone on record"}
                    </span>
                  </Td>
                  <Td className="text-slate-600">{r.schemeName}</Td>
                  <Td className="whitespace-nowrap text-slate-600">{monthLabel(r.period)}</Td>
                  <Td align="right" className="tabular font-semibold text-red-600">
                    {money(r.pendingAmount, currency)}
                  </Td>
                  <Td align="right">
                    {can("reminder:send") ? (
                      <Button
                        size="sm"
                        variant="success"
                        onClick={() => openReview(r)}
                        icon={<MessageCircle className="h-4 w-4" aria-hidden />}
                      >
                        Review message
                      </Button>
                    ) : null}
                  </Td>
                </Tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>

      <Card className="mt-5" padded={false}>
        <div className="p-5 pb-0">
          <CardHeader
            title="Reminder log"
            subtitle="Messages prepared and opened in WhatsApp by administrators. Delivery is not tracked."
          />
        </div>
        {sentLog.length === 0 ? (
          <div className="p-5 pt-0">
            <EmptyState title="No reminders prepared yet" message="Reviewed messages appear here." />
          </div>
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>When</Th>
                <Th>Member</Th>
                <Th>Month</Th>
                <Th align="right">Amount</Th>
                <Th>Opened by</Th>
                <Th>Channel</Th>
              </tr>
            </thead>
            <tbody>
              {sentLog.map((log) => (
                <Tr key={log.id}>
                  <Td className="whitespace-nowrap text-slate-600">
                    {dateTimeLabel(log.openedAt)}
                  </Td>
                  <Td>
                    <Link href={`/members/${log.memberId}`} className="hover:underline">
                      {snapshot.members.find((m) => m.id === log.memberId)?.fullName ??
                        "Unknown member"}
                    </Link>
                  </Td>
                  <Td className="whitespace-nowrap text-slate-600">{monthLabel(log.period)}</Td>
                  <Td align="right" className="tabular">
                    {money(log.amount, currency)}
                  </Td>
                  <Td className="text-slate-600">{log.actorName}</Td>
                  <Td>
                    <Badge tone="success">WhatsApp</Badge>
                  </Td>
                </Tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>

      <Dialog
        open={review !== null}
        onClose={() => setReview(null)}
        title="Review the message"
        width="lg"
        footer={
          <>
            <Button variant="secondary" onClick={() => setReview(null)}>
              Cancel
            </Button>
            <Button
              variant="success"
              onClick={openWhatsApp}
              icon={<MessageCircle className="h-4 w-4" aria-hidden />}
            >
              Open WhatsApp
            </Button>
          </>
        }
      >
        {review ? (
          <div className="space-y-4">
            <div className="rounded-lg bg-slate-50 px-4 py-3 text-sm">
              <p className="font-medium text-navy-900">{review.row.memberName}</p>
              <p className="text-slate-500">
                {review.row.phone} · {review.row.schemeName} · {monthLabel(review.row.period)} ·{" "}
                {money(review.row.pendingAmount, currency)} pending
              </p>
            </div>
            <Field
              label="Message"
              hint="Edit it if you want. Nothing is sent until you press send inside WhatsApp."
            >
              <Textarea
                value={review.message}
                onChange={(e) => setReview({ ...review, message: e.target.value })}
                className="min-h-[140px]"
              />
            </Field>
            <p className="text-xs text-slate-500">
              The default wording comes from Settings, where you can change the template for
              everyone.
            </p>
          </div>
        ) : null}
      </Dialog>
    </>
  );
}
