"use client";

import { useRef, useState } from "react";
import { CloudOff, Database, Save, Trash2, Upload } from "lucide-react";

import {
  Alert,
  Badge,
  Button,
  Card,
  CardHeader,
  Dialog,
  Field,
  Input,
  PageHeader,
  Textarea,
} from "@/components/ui";
import { BRAND_NAME, BrandMark } from "@/components/ui/BrandMark";
import { useToast } from "@/components/ui/Toast";
import { NoAccess } from "@/components/NoAccess";
import { useData } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import { asLocal, getRepository } from "@/lib/data";
import { ORG_ID, missingFirebaseKeys } from "@/lib/firebase";
import { money, monthLabel, currentPeriod } from "@/lib/format";
import { renderReminder } from "@/lib/kuri";
import { DEFAULT_REMINDER_TEMPLATE } from "@/lib/types";

export default function SettingsPage() {
  const { snapshot, run, refresh } = useData();
  const { can, mode } = useAuth();
  const toast = useToast();
  const fileRef = useRef<HTMLInputElement>(null);

  const s = snapshot.settings;
  const [organizationName, setOrganizationName] = useState(s.organizationName);
  const [logoDataUrl, setLogoDataUrl] = useState(s.logoDataUrl);
  const [contactPhone, setContactPhone] = useState(s.contactPhone);
  const [contactEmail, setContactEmail] = useState(s.contactEmail);
  const [address, setAddress] = useState(s.address);
  const [currencySymbol, setCurrencySymbol] = useState(s.currencySymbol);
  const [defaultDueDay, setDefaultDueDay] = useState(String(s.defaultDueDay));
  const [defaultMonthlyAmount, setDefaultMonthlyAmount] = useState(
    String(s.defaultMonthlyAmount),
  );
  const [defaultDurationMonths, setDefaultDurationMonths] = useState(
    String(s.defaultDurationMonths),
  );
  const [defaultMemberLimit, setDefaultMemberLimit] = useState(String(s.defaultMemberLimit));
  const [reminderDay, setReminderDay] = useState(String(s.reminderDay));
  const [reminderTemplate, setReminderTemplate] = useState(s.reminderTemplate);
  const [receiptPrefix, setReceiptPrefix] = useState(s.receiptPrefix);
  const [busy, setBusy] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);

  if (!can("settings:write")) return <NoAccess what="change organization settings" />;

  function onLogoPick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 400_000) {
      toast.error("Choose a logo under 400 KB so it stays inside the free Firestore limits.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setLogoDataUrl(String(reader.result));
    reader.onerror = () => toast.error("Could not read that image.");
    reader.readAsDataURL(file);
  }

  async function onSave(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await run((repo, actor) =>
        repo.saveSettings(
          {
            organizationName: organizationName.trim() || BRAND_NAME,
            logoDataUrl,
            contactPhone: contactPhone.trim(),
            contactEmail: contactEmail.trim(),
            address: address.trim(),
            currencySymbol: currencySymbol.trim() || "₹",
            defaultDueDay: Math.min(28, Math.max(1, Number(defaultDueDay) || 10)),
            defaultMonthlyAmount: Math.max(1, Number(defaultMonthlyAmount) || 5000),
            defaultDurationMonths: Math.min(
              120,
              Math.max(1, Number(defaultDurationMonths) || 12),
            ),
            defaultMemberLimit: Math.min(1000, Math.max(1, Number(defaultMemberLimit) || 60)),
            reminderDay: Math.min(28, Math.max(1, Number(reminderDay) || 10)),
            reminderTemplate: reminderTemplate.trim() || DEFAULT_REMINDER_TEMPLATE,
            receiptPrefix: receiptPrefix.trim().toUpperCase() || "RCPT",
          },
          actor,
        ),
      );
      toast.success("Settings saved.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save the settings.");
    } finally {
      setBusy(false);
    }
  }

  async function onResetLocal() {
    const repo = asLocal(getRepository());
    if (!repo) return;
    await repo.resetLocalData();
    await refresh();
    setResetOpen(false);
    toast.success("Local records cleared. Administrator accounts were kept.");
  }

  const preview = renderReminder(reminderTemplate, {
    memberName: "Fathima Beevi",
    amount: money(5000, currencySymbol || "₹"),
    month: monthLabel(currentPeriod()),
    organizationName: organizationName || BRAND_NAME,
    schemeName: "MMS Sabha Kuri 2026",
  });

  return (
    <>
      <PageHeader
        title="Settings"
        subtitle="Organization details, scheme defaults and the reminder message."
        actions={
          <Button onClick={onSave} loading={busy} icon={<Save className="h-4 w-4" aria-hidden />}>
            Save changes
          </Button>
        }
      />

      <form onSubmit={onSave} className="grid gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <Card>
            <CardHeader title="Organization" />
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Organization name" required className="sm:col-span-2">
                <Input
                  value={organizationName}
                  onChange={(e) => setOrganizationName(e.target.value)}
                  required
                />
              </Field>

              <Field label="Logo" hint="Shown in the sidebar and on receipts. Under 400 KB.">
                <div className="flex items-center gap-3">
                  {/* With no upload, this previews the bundled MMS Sabha mark —
                      exactly what the sidebar and receipts fall back to. */}
                  <BrandMark logoDataUrl={logoDataUrl} size="lg" />
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/svg+xml"
                    onChange={onLogoPick}
                    className="hidden"
                  />
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    onClick={() => fileRef.current?.click()}
                    icon={<Upload className="h-4 w-4" aria-hidden />}
                  >
                    Choose image
                  </Button>
                  {logoDataUrl ? (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => setLogoDataUrl("")}
                    >
                      Remove
                    </Button>
                  ) : null}
                </div>
              </Field>

              <Field label="Currency symbol" required hint="₹ by default.">
                <Input
                  value={currencySymbol}
                  onChange={(e) => setCurrencySymbol(e.target.value)}
                  maxLength={3}
                  required
                />
              </Field>

              <Field label="Contact phone">
                <Input value={contactPhone} onChange={(e) => setContactPhone(e.target.value)} />
              </Field>

              <Field label="Contact email">
                <Input
                  type="email"
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                />
              </Field>

              <Field label="Address" className="sm:col-span-2">
                <Textarea value={address} onChange={(e) => setAddress(e.target.value)} />
              </Field>
            </div>
          </Card>

          <Card>
            <CardHeader
              title="Scheme defaults"
              subtitle="Used to pre-fill the new scheme form. Every scheme can differ."
            />
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label={`Default monthly contribution (${currencySymbol || "₹"})`}>
                <Input
                  type="number"
                  min={1}
                  step={1}
                  value={defaultMonthlyAmount}
                  onChange={(e) => setDefaultMonthlyAmount(e.target.value)}
                />
              </Field>
              <Field label="Default duration (months)">
                <Input
                  type="number"
                  min={1}
                  max={120}
                  step={1}
                  value={defaultDurationMonths}
                  onChange={(e) => setDefaultDurationMonths(e.target.value)}
                />
              </Field>
              <Field label="Default members per scheme">
                <Input
                  type="number"
                  min={1}
                  max={1000}
                  step={1}
                  value={defaultMemberLimit}
                  onChange={(e) => setDefaultMemberLimit(e.target.value)}
                />
              </Field>
              <Field label="Default monthly due date" hint="Day of the month, 1 to 28.">
                <Input
                  type="number"
                  min={1}
                  max={28}
                  step={1}
                  value={defaultDueDay}
                  onChange={(e) => setDefaultDueDay(e.target.value)}
                />
              </Field>
              <Field label="Receipt number prefix" hint="Receipts read PREFIX-YEAR-0001.">
                <Input
                  value={receiptPrefix}
                  onChange={(e) => setReceiptPrefix(e.target.value)}
                  maxLength={8}
                />
              </Field>
            </div>
          </Card>

          <Card>
            <CardHeader
              title="Reminder message"
              subtitle="Placeholders are filled in per member when a reminder is prepared."
            />
            <div className="grid gap-4">
              <Field label="Reminder day of month" hint="The schedule shown on the dashboard.">
                <Input
                  type="number"
                  min={1}
                  max={28}
                  step={1}
                  value={reminderDay}
                  onChange={(e) => setReminderDay(e.target.value)}
                  className="sm:max-w-[10rem]"
                />
              </Field>

              <Field
                label="Message template"
                hint="Available placeholders: {{memberName}}, {{amount}}, {{month}}, {{schemeName}}, {{organizationName}}"
              >
                <Textarea
                  value={reminderTemplate}
                  onChange={(e) => setReminderTemplate(e.target.value)}
                  className="min-h-[120px]"
                />
              </Field>

              <div>
                <p className="mb-1.5 text-sm font-medium text-navy-900">Preview</p>
                <p className="rounded-lg bg-forest-50 px-4 py-3 text-sm leading-relaxed text-forest-900">
                  {preview}
                </p>
              </div>

              <Button
                type="button"
                variant="secondary"
                size="sm"
                onClick={() => setReminderTemplate(DEFAULT_REMINDER_TEMPLATE)}
                className="self-start"
              >
                Reset to the default wording
              </Button>
            </div>
          </Card>

          <div className="flex flex-wrap gap-2">
            <Button type="submit" loading={busy} icon={<Save className="h-4 w-4" aria-hidden />}>
              Save changes
            </Button>
          </div>
        </div>

        <div className="space-y-5">
          <Card>
            <CardHeader title="Where data is stored" />
            {mode === "firebase" ? (
              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-2">
                  <Database className="h-5 w-5 text-forest-600" aria-hidden />
                  <Badge tone="success">Cloud Firestore</Badge>
                </div>
                <p className="text-slate-600">
                  Records are stored in Cloud Firestore under the organization{" "}
                  <code className="rounded bg-slate-100 px-1">{ORG_ID}</code> and are shared by
                  every administrator.
                </p>
                <p className="text-xs text-slate-500">
                  Access is enforced by the Firestore security rules in{" "}
                  <code>firestore.rules</code>, not by this interface alone.
                </p>
              </div>
            ) : (
              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-2">
                  <CloudOff className="h-5 w-5 text-amber-600" aria-hidden />
                  <Badge tone="warning">Local development mode</Badge>
                </div>
                <p className="text-slate-600">
                  Records are kept in this browser only. They are not stored in any cloud database,
                  not shared with other administrators or devices, and not backed up. Clearing your
                  browser data deletes them.
                </p>
                {missingFirebaseKeys.length > 0 ? (
                  <p className="text-xs text-slate-500">
                    Missing configuration: {missingFirebaseKeys.join(", ")}.
                  </p>
                ) : null}
                <Button
                  type="button"
                  variant="danger"
                  size="sm"
                  onClick={() => setResetOpen(true)}
                  icon={<Trash2 className="h-4 w-4" aria-hidden />}
                >
                  Clear local records
                </Button>
              </div>
            )}
          </Card>

          <Card>
            <CardHeader title="Counts" subtitle="What this organization holds" />
            <dl className="space-y-2.5 text-sm">
              {[
                ["Members", snapshot.members.length],
                ["Schemes", snapshot.schemes.length],
                ["Scheme assignments", snapshot.memberships.filter((m) => m.active).length],
                ["Payments", snapshot.payments.length],
                ["Audit entries", snapshot.auditLogs.length],
                ["Reminders prepared", snapshot.reminders.length],
                ["Administrators", snapshot.users.length],
              ].map(([label, value]) => (
                <div key={String(label)} className="flex justify-between gap-3">
                  <dt className="text-slate-500">{label}</dt>
                  <dd className="tabular font-medium">{value}</dd>
                </div>
              ))}
            </dl>
          </Card>

          <Alert tone="info" title="Payments are never deleted">
            There is no delete action for a payment anywhere in this application. A wrong figure is
            corrected, and the original values stay in the audit history.
          </Alert>
        </div>
      </form>

      <Dialog
        open={resetOpen}
        onClose={() => setResetOpen(false)}
        title="Clear all local records?"
        footer={
          <>
            <Button variant="secondary" onClick={() => setResetOpen(false)}>
              Cancel
            </Button>
            <Button variant="danger" onClick={onResetLocal}>
              Clear records
            </Button>
          </>
        }
      >
        <p>
          This removes every member, scheme, payment and reminder stored in this browser. Your
          administrator accounts are kept so you can sign in again. This cannot be undone.
        </p>
        <p className="mt-3 text-sm text-slate-500">
          Local mode is for trying the application out before Firebase is configured. It is
          available because no cloud database is connected.
        </p>
      </Dialog>
    </>
  );
}
