"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Clock } from "lucide-react";

import {
  Badge,
  Card,
  EmptyState,
  Field,
  Input,
  LinkButton,
  PageHeader,
  Select,
  Table,
  Td,
  Th,
  Tr,
} from "@/components/ui";
import { ExportBar } from "@/components/ExportBar";
import { useData, useLookups } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import { dateLabel, money, monthLabel } from "@/lib/format";
import { PAYMENT_METHODS, PAYMENT_METHOD_LABEL, type PaymentMethod } from "@/lib/types";
import { stamp } from "@/lib/export";

export default function PaymentHistoryPage() {
  const { snapshot } = useData();
  const { memberName, memberCode, schemeName } = useLookups();
  const { can } = useAuth();
  const currency = snapshot.settings.currencySymbol;

  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [schemeId, setSchemeId] = useState("all");
  const [memberId, setMemberId] = useState("all");
  const [method, setMethod] = useState<"all" | PaymentMethod>("all");
  const [term, setTerm] = useState("");

  const rows = useMemo(() => {
    const q = term.trim().toLowerCase();
    return snapshot.payments
      .filter((p) => (from ? p.paidOn >= from : true))
      .filter((p) => (to ? p.paidOn <= to : true))
      .filter((p) => (schemeId === "all" ? true : p.schemeId === schemeId))
      .filter((p) => (memberId === "all" ? true : p.memberId === memberId))
      .filter((p) => (method === "all" ? true : p.method === method))
      .filter((p) =>
        q
          ? memberName(p.memberId).toLowerCase().includes(q) ||
            memberCode(p.memberId).toLowerCase().includes(q) ||
            p.receiptNo.toLowerCase().includes(q) ||
            p.referenceNo.toLowerCase().includes(q) ||
            p.receivedBy.toLowerCase().includes(q)
          : true,
      )
      .sort((a, b) => b.paidOn.localeCompare(a.paidOn) || b.createdAt.localeCompare(a.createdAt));
  }, [snapshot.payments, from, to, schemeId, memberId, method, term, memberName, memberCode]);

  const total = rows.reduce((s, p) => s + p.amount, 0);

  const filterLabel = [
    from || to ? `${from || "start"} to ${to || "today"}` : "All dates",
    schemeId === "all" ? null : schemeName(schemeId),
    memberId === "all" ? null : memberName(memberId),
    method === "all" ? null : PAYMENT_METHOD_LABEL[method],
  ]
    .filter(Boolean)
    .join(" · ");

  return (
    <>
      <PageHeader
        title="Payment History"
        subtitle="Every contribution recorded, with who received it and who entered it."
        actions={
          <ExportBar
            rows={rows}
            columns={[
              { header: "Receipt", value: (p) => p.receiptNo },
              { header: "Paid on", value: (p) => p.paidOn },
              { header: "Member ID", value: (p) => memberCode(p.memberId) },
              { header: "Member", value: (p) => memberName(p.memberId) },
              { header: "Scheme", value: (p) => schemeName(p.schemeId) },
              { header: "Month", value: (p) => p.period },
              { header: "Amount (₹)", value: (p) => p.amount, align: "right" },
              { header: "Method", value: (p) => PAYMENT_METHOD_LABEL[p.method] },
              { header: "Received by", value: (p) => p.receivedBy },
              { header: "Reference", value: (p) => p.referenceNo },
              { header: "Recorded by", value: (p) => p.createdByName },
              { header: "Corrected", value: (p) => (p.corrected ? "Yes" : "No") },
            ]}
            filename={stamp("payment-history")}
            title="Payment history"
            subtitle={filterLabel}
            organization={snapshot.settings.organizationName}
          />
        }
      />

      <Card padded={false}>
        <div className="grid gap-3 border-b border-slate-200 p-4 sm:grid-cols-2 lg:grid-cols-6 print:hidden">
          <Field label="From">
            <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </Field>
          <Field label="To">
            <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </Field>
          <Field label="Scheme">
            <Select value={schemeId} onChange={(e) => setSchemeId(e.target.value)}>
              <option value="all">All schemes</option>
              {snapshot.schemes.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Member">
            <Select value={memberId} onChange={(e) => setMemberId(e.target.value)}>
              <option value="all">All members</option>
              {[...snapshot.members]
                .sort((a, b) => a.fullName.localeCompare(b.fullName))
                .map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.fullName} ({m.memberCode})
                  </option>
                ))}
            </Select>
          </Field>
          <Field label="Method">
            <Select
              value={method}
              onChange={(e) => setMethod(e.target.value as "all" | PaymentMethod)}
            >
              <option value="all">All methods</option>
              {PAYMENT_METHODS.map((m) => (
                <option key={m} value={m}>
                  {PAYMENT_METHOD_LABEL[m]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Search">
            <Input
              type="search"
              value={term}
              onChange={(e) => setTerm(e.target.value)}
              placeholder="Receipt, name, reference"
            />
          </Field>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 bg-slate-50/70 px-4 py-3">
          <p className="text-sm text-slate-600">
            {rows.length} payment{rows.length === 1 ? "" : "s"}
            <span className="text-slate-400"> · {filterLabel}</span>
          </p>
          <p className="text-sm font-semibold text-navy-900">
            Total <span className="tabular">{money(total, currency)}</span>
          </p>
        </div>

        {rows.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={<Clock className="h-8 w-8" aria-hidden />}
              title={
                snapshot.payments.length === 0 ? "No payments recorded yet" : "No matching payments"
              }
              message={
                snapshot.payments.length === 0
                  ? "Once an administrator records a cash contribution it appears here."
                  : "Adjust the filters above to widen the search."
              }
              action={
                snapshot.payments.length === 0 && can("payment:create") ? (
                  <LinkButton href="/payments/new" size="sm">
                    Record a payment
                  </LinkButton>
                ) : null
              }
            />
          </div>
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Receipt</Th>
                <Th>Paid on</Th>
                <Th>Member</Th>
                <Th>Scheme</Th>
                <Th>Month</Th>
                <Th align="right">Amount</Th>
                <Th>Method</Th>
                <Th>Received by</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {rows.map((p) => (
                <Tr key={p.id}>
                  <Td>
                    <Link
                      href={`/payments/${p.id}/receipt`}
                      className="font-medium text-navy-900 hover:underline"
                    >
                      {p.receiptNo}
                    </Link>
                    {p.corrected ? (
                      <Badge tone="warning" className="ml-1.5">
                        Corrected
                      </Badge>
                    ) : null}
                  </Td>
                  <Td className="whitespace-nowrap text-slate-600">{dateLabel(p.paidOn)}</Td>
                  <Td>
                    <Link href={`/members/${p.memberId}`} className="hover:underline">
                      {memberName(p.memberId)}
                    </Link>
                    <span className="block text-xs text-slate-500">{memberCode(p.memberId)}</span>
                  </Td>
                  <Td className="text-slate-600">{schemeName(p.schemeId)}</Td>
                  <Td className="whitespace-nowrap text-slate-600">{monthLabel(p.period)}</Td>
                  <Td align="right" className="tabular font-medium">
                    {money(p.amount, currency)}
                  </Td>
                  <Td className="text-slate-600">{PAYMENT_METHOD_LABEL[p.method]}</Td>
                  <Td className="text-slate-600">
                    {p.receivedBy}
                    <span className="block text-xs text-slate-400">
                      entered by {p.createdByName}
                    </span>
                  </Td>
                  <Td align="right">
                    {can("payment:edit") ? (
                      <Link
                        href={`/payments/${p.id}/edit`}
                        className="text-sm font-medium text-navy-700 hover:underline"
                      >
                        Correct
                      </Link>
                    ) : null}
                  </Td>
                </Tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </>
  );
}
