"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { CheckCircle2, MessageCircle } from "lucide-react";

import {
  Card,
  EmptyState,
  Field,
  Input,
  LinkButton,
  PageHeader,
  Select,
  Table,
  Td,
  Th,
  Tr,
} from "@/components/ui";
import { ExportBar } from "@/components/ExportBar";
import { useData } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import { currentPeriod, dateLabel, money, monthLabel, waNumber } from "@/lib/format";
import { pendingRows, renderReminder } from "@/lib/kuri";
import { stamp } from "@/lib/export";

export default function PendingPaymentsPage() {
  const { snapshot, run } = useData();
  const { can, user } = useAuth();
  const period = currentPeriod();
  const currency = snapshot.settings.currencySymbol;

  const [schemeId, setSchemeId] = useState("all");
  const [monthFilter, setMonthFilter] = useState("all");
  const [term, setTerm] = useState("");

  const all = useMemo(
    () =>
      pendingRows({
        members: snapshot.members,
        schemes: snapshot.schemes,
        memberships: snapshot.memberships,
        ledgers: snapshot.ledgers,
        asOfPeriod: period,
      }),
    [snapshot, period],
  );

  const months = useMemo(
    () => [...new Set(all.map((r) => r.period))].sort().reverse(),
    [all],
  );

  const rows = useMemo(() => {
    const q = term.trim().toLowerCase();
    return all
      .filter((r) => (schemeId === "all" ? true : r.schemeId === schemeId))
      .filter((r) => (monthFilter === "all" ? true : r.period === monthFilter))
      .filter((r) =>
        q
          ? r.memberName.toLowerCase().includes(q) || r.memberCode.toLowerCase().includes(q)
          : true,
      );
  }, [all, schemeId, monthFilter, term]);

  const total = rows.reduce((s, r) => s + r.pendingAmount, 0);
  const membersAffected = new Set(rows.map((r) => r.memberId)).size;

  function remind(row: (typeof rows)[number]) {
    const message = renderReminder(snapshot.settings.reminderTemplate, {
      memberName: row.memberName,
      amount: money(row.pendingAmount, currency),
      month: monthLabel(row.period),
      organizationName: snapshot.settings.organizationName,
      schemeName: row.schemeName,
    });
    window.open(
      `https://wa.me/${waNumber(row.phone)}?text=${encodeURIComponent(message)}`,
      "_blank",
      "noopener,noreferrer",
    );
    void run((repo) =>
      repo.logReminder({
        memberId: row.memberId,
        schemeId: row.schemeId,
        period: row.period,
        amount: row.pendingAmount,
        channel: "whatsapp",
        message,
        openedAt: new Date().toISOString(),
        actorUid: user?.id ?? "",
        actorName: user?.name ?? "",
      }),
    ).catch(() => undefined);
  }

  return (
    <>
      <PageHeader
        title="Pending Payments"
        subtitle="Contributions for months that are already due and not yet settled in full."
        actions={
          <ExportBar
            rows={rows}
            columns={[
              { header: "Member ID", value: (r) => r.memberCode },
              { header: "Member", value: (r) => r.memberName },
              { header: "Phone", value: (r) => r.phone },
              { header: "Scheme", value: (r) => r.schemeName },
              { header: "Month", value: (r) => r.period },
              { header: "Due date", value: (r) => r.dueDate },
              { header: "Due (₹)", value: (r) => r.dueAmount, align: "right" },
              { header: "Paid (₹)", value: (r) => r.paidAmount, align: "right" },
              { header: "Pending (₹)", value: (r) => r.pendingAmount, align: "right" },
            ]}
            filename={stamp("pending-payments")}
            title="Pending payment report"
            subtitle={`As of ${dateLabel(new Date().toISOString().slice(0, 10))}`}
            organization={snapshot.settings.organizationName}
          />
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <p className="text-sm text-slate-500">Total pending</p>
          <p className="tabular mt-1 text-2xl font-semibold text-red-600">
            {money(total, currency)}
          </p>
        </Card>
        <Card>
          <p className="text-sm text-slate-500">Open contributions</p>
          <p className="mt-1 text-2xl font-semibold text-navy-900">{rows.length}</p>
        </Card>
        <Card>
          <p className="text-sm text-slate-500">Members affected</p>
          <p className="mt-1 text-2xl font-semibold text-navy-900">{membersAffected}</p>
        </Card>
      </div>

      <Card className="mt-5" padded={false}>
        <div className="grid gap-3 border-b border-slate-200 p-4 sm:grid-cols-3 print:hidden">
          <Field label="Scheme">
            <Select value={schemeId} onChange={(e) => setSchemeId(e.target.value)}>
              <option value="all">All schemes</option>
              {snapshot.schemes.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Month">
            <Select value={monthFilter} onChange={(e) => setMonthFilter(e.target.value)}>
              <option value="all">All months due</option>
              {months.map((m) => (
                <option key={m} value={m}>
                  {monthLabel(m)}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Search">
            <Input
              type="search"
              value={term}
              onChange={(e) => setTerm(e.target.value)}
              placeholder="Member name or ID"
            />
          </Field>
        </div>

        {rows.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={<CheckCircle2 className="h-8 w-8 text-forest-500" aria-hidden />}
              title={all.length === 0 ? "Nothing is pending" : "No matching rows"}
              message={
                all.length === 0
                  ? "Every contribution that has fallen due has been collected in full. Nothing to chase."
                  : "Adjust the filters to see other pending contributions."
              }
            />
          </div>
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Member</Th>
                <Th>Scheme</Th>
                <Th>Month</Th>
                <Th>Due date</Th>
                <Th align="right">Due</Th>
                <Th align="right">Paid</Th>
                <Th align="right">Pending</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <Tr key={`${r.schemeId}-${r.memberId}-${r.period}`}>
                  <Td>
                    <Link href={`/members/${r.memberId}`} className="font-medium hover:underline">
                      {r.memberName}
                    </Link>
                    <span className="block text-xs text-slate-500">
                      {r.memberCode} · {r.phone}
                    </span>
                  </Td>
                  <Td className="text-slate-600">{r.schemeName}</Td>
                  <Td className="whitespace-nowrap text-slate-600">{monthLabel(r.period)}</Td>
                  <Td className="whitespace-nowrap text-slate-600">{dateLabel(r.dueDate)}</Td>
                  <Td align="right" className="tabular text-slate-600">
                    {money(r.dueAmount, currency)}
                  </Td>
                  <Td align="right" className="tabular text-forest-700">
                    {r.paidAmount > 0 ? (
                      money(r.paidAmount, currency)
                    ) : (
                      <span className="text-slate-400">—</span>
                    )}
                  </Td>
                  <Td align="right" className="tabular font-semibold text-red-600">
                    {money(r.pendingAmount, currency)}
                  </Td>
                  <Td align="right">
                    <div className="flex justify-end gap-2 print:hidden">
                      {can("reminder:send") ? (
                        <button
                          type="button"
                          onClick={() => remind(r)}
                          className="inline-flex items-center gap-1.5 rounded-lg border border-forest-200 bg-forest-50 px-2.5 py-1.5 text-xs font-medium text-forest-800 hover:bg-forest-100"
                        >
                          <MessageCircle className="h-3.5 w-3.5" aria-hidden />
                          Remind
                        </button>
                      ) : null}
                      {can("payment:create") ? (
                        <LinkButton
                          href={`/payments/new?member=${r.memberId}&scheme=${r.schemeId}`}
                          size="sm"
                          variant="secondary"
                        >
                          Record
                        </LinkButton>
                      ) : null}
                    </div>
                  </Td>
                </Tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </>
  );
}
