"use client";

import { useParams } from "next/navigation";

import { PageHeader } from "@/components/ui";
import { SchemeForm } from "@/components/forms/SchemeForm";
import { NoAccess, NotFoundCard } from "@/components/NoAccess";
import { useAuth } from "@/lib/auth/AuthProvider";
import { useData } from "@/lib/DataProvider";

export default function EditSchemePage() {
  const params = useParams<{ id: string }>();
  const { can } = useAuth();
  const { snapshot } = useData();
  const scheme = snapshot.schemes.find((s) => s.id === params.id);

  if (!can("scheme:write")) return <NoAccess what="create or change Kuri schemes" />;
  if (!scheme) {
    return (
      <NotFoundCard
        title="Scheme not found"
        message="This scheme may have been removed, or the link is out of date."
        backHref="/schemes"
        backLabel="Back to schemes"
      />
    );
  }

  return (
    <>
      <PageHeader title={`Edit — ${scheme.name}`} subtitle="Changes apply to future calculations immediately." />
      <SchemeForm scheme={scheme} />
    </>
  );
}
