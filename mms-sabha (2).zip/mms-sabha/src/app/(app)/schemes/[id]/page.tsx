"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { Archive, BadgeIndianRupee, Pencil, Plus, Users } from "lucide-react";

import {
  Alert,
  Badge,
  Button,
  Card,
  CardHeader,
  Dialog,
  EmptyState,
  Field,
  Input,
  LinkButton,
  PageHeader,
  Select,
  Table,
  Td,
  Th,
  Tr,
} from "@/components/ui";
import { useToast } from "@/components/ui/Toast";
import { NotFoundCard } from "@/components/NoAccess";
import { ExportBar } from "@/components/ExportBar";
import { useData } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import { currentPeriod, dateLabel, money, monthLabel, todayISO } from "@/lib/format";
import {
  buildLedgerIndex,
  duePeriods,
  schemeDueDate,
  schemeEndMonth,
  schemePeriods,
} from "@/lib/kuri";
import { stamp } from "@/lib/export";

export default function SchemeDetailPage() {
  const params = useParams<{ id: string }>();
  const schemeId = params.id;
  const { snapshot, run } = useData();
  const { can } = useAuth();
  const toast = useToast();
  const period = currentPeriod();
  const currency = snapshot.settings.currencySymbol;

  const [assignOpen, setAssignOpen] = useState(false);
  const [assignMemberId, setAssignMemberId] = useState("");
  const [assignJoined, setAssignJoined] = useState(todayISO());
  const [busy, setBusy] = useState(false);

  const scheme = snapshot.schemes.find((s) => s.id === schemeId);

  const index = useMemo(() => buildLedgerIndex(snapshot.ledgers), [snapshot.ledgers]);

  const roster = useMemo(() => {
    if (!scheme) return [];
    const periodsDue = duePeriods(scheme, period);
    return snapshot.memberships
      .filter((ms) => ms.schemeId === scheme.id && ms.active)
      .map((ms) => {
        const member = snapshot.members.find((m) => m.id === ms.memberId);
        const liable = periodsDue.filter((p) => p >= ms.joinedAt.slice(0, 7));
        let paid = 0;
        let unpaidPeriods = 0;
        for (const p of liable) {
          const amount = index.get(scheme.id, ms.memberId, p)?.paidAmount ?? 0;
          paid += amount;
          if (amount < scheme.monthlyAmount) unpaidPeriods += 1;
        }
        const due = liable.length * scheme.monthlyAmount;
        return {
          membershipId: ms.id,
          memberId: ms.memberId,
          name: member?.fullName ?? "Unknown member",
          code: member?.memberCode ?? "—",
          phone: member?.phone ?? "",
          joinedAt: ms.joinedAt,
          due,
          paid,
          outstanding: Math.max(0, due - paid),
          unpaidPeriods,
        };
      })
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [scheme, snapshot.memberships, snapshot.members, index, period]);

  const periodRows = useMemo(() => {
    if (!scheme) return [];
    return schemePeriods(scheme).map((p) => {
      const liableCount = snapshot.memberships.filter(
        (ms) => ms.schemeId === scheme.id && ms.active && ms.joinedAt.slice(0, 7) <= p,
      ).length;
      const collected = snapshot.payments
        .filter((pay) => pay.schemeId === scheme.id && pay.period === p)
        .reduce((s, pay) => s + pay.amount, 0);
      const expected = liableCount * scheme.monthlyAmount;
      const isDue = p <= period;
      return {
        period: p,
        dueDate: schemeDueDate(scheme, p),
        expected,
        collected,
        pending: isDue ? Math.max(0, expected - collected) : 0,
        isDue,
      };
    });
  }, [scheme, snapshot.memberships, snapshot.payments, period]);

  const assignable = useMemo(() => {
    if (!scheme) return [];
    const inScheme = new Set(
      snapshot.memberships.filter((ms) => ms.schemeId === scheme.id && ms.active).map((ms) => ms.memberId),
    );
    return snapshot.members
      .filter((m) => m.status === "active" && !inScheme.has(m.id))
      .sort((a, b) => a.fullName.localeCompare(b.fullName));
  }, [scheme, snapshot.members, snapshot.memberships]);

  if (!scheme) {
    return (
      <NotFoundCard
        title="Scheme not found"
        message="This scheme may have been removed, or the link is out of date."
        backHref="/schemes"
        backLabel="Back to schemes"
      />
    );
  }

  const totalCollected = snapshot.payments
    .filter((p) => p.schemeId === scheme.id)
    .reduce((s, p) => s + p.amount, 0);
  const totalOutstanding = roster.reduce((s, r) => s + r.outstanding, 0);
  const slotsLeft = scheme.memberLimit - roster.length;

  // Captured after the not-found guard so the handlers below have a definite
  // value (a hoisted function declaration does not inherit the narrowing).
  const thisScheme = scheme;

  async function onAssign(e: React.FormEvent) {
    e.preventDefault();
    if (!assignMemberId) return;
    setBusy(true);
    try {
      await run((repo) => repo.assignMember(thisScheme.id, assignMemberId, assignJoined));
      toast.success("Member assigned to the scheme.");
      setAssignOpen(false);
      setAssignMemberId("");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not assign the member.");
    } finally {
      setBusy(false);
    }
  }

  async function onRemove(memberId: string, name: string) {
    setBusy(true);
    try {
      await run((repo) => repo.unassignMember(thisScheme.id, memberId));
      toast.success(`${name} removed from the scheme.`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not remove the member.");
    } finally {
      setBusy(false);
    }
  }

  async function onArchive() {
    setBusy(true);
    try {
      await run((repo, actor) => repo.setSchemeStatus(thisScheme.id, "archived", actor));
      toast.success("Scheme archived. Its payment records are kept.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not archive the scheme.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <PageHeader
        title={scheme.name}
        subtitle={`${money(scheme.monthlyAmount, currency)} a month · ${
          scheme.durationMonths
        } months · ${monthLabel(scheme.startMonth)} to ${monthLabel(schemeEndMonth(scheme))} · due day ${
          scheme.dueDay
        }`}
        actions={
          <>
            {can("payment:create") ? (
              <LinkButton
                href={`/payments/new?scheme=${scheme.id}`}
                icon={<BadgeIndianRupee className="h-4 w-4" aria-hidden />}
              >
                Record payment
              </LinkButton>
            ) : null}
            {can("scheme:write") ? (
              <>
                <LinkButton
                  href={`/schemes/${scheme.id}/edit`}
                  variant="secondary"
                  icon={<Pencil className="h-4 w-4" aria-hidden />}
                >
                  Edit
                </LinkButton>
                {scheme.status !== "archived" ? (
                  <Button
                    variant="secondary"
                    onClick={onArchive}
                    loading={busy}
                    icon={<Archive className="h-4 w-4" aria-hidden />}
                  >
                    Archive
                  </Button>
                ) : null}
              </>
            ) : null}
          </>
        }
      />

      {scheme.status === "archived" ? (
        <div className="mb-5">
          <Alert tone="warning" title="This scheme is archived">
            No new payments can be recorded against it. Existing payment records are untouched and
            still appear in reports.
          </Alert>
        </div>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card>
          <p className="text-sm text-slate-500">Members</p>
          <p className="mt-1 text-2xl font-semibold text-navy-900">
            {roster.length}
            <span className="text-base font-normal text-slate-400"> / {scheme.memberLimit}</span>
          </p>
          <p className="mt-1 text-xs text-slate-500">
            {slotsLeft > 0 ? `${slotsLeft} place(s) free` : "Scheme is full"}
          </p>
        </Card>
        <Card>
          <p className="text-sm text-slate-500">Collected</p>
          <p className="tabular mt-1 text-2xl font-semibold text-forest-700">
            {money(totalCollected, currency)}
          </p>
          <p className="mt-1 text-xs text-slate-500">From recorded payments only</p>
        </Card>
        <Card>
          <p className="text-sm text-slate-500">Outstanding to date</p>
          <p className="tabular mt-1 text-2xl font-semibold text-red-600">
            {money(totalOutstanding, currency)}
          </p>
          <p className="mt-1 text-xs text-slate-500">For months already due</p>
        </Card>
        <Card>
          <p className="text-sm text-slate-500">Scheme value at full strength</p>
          <p className="tabular mt-1 text-2xl font-semibold text-navy-900">
            {money(scheme.monthlyAmount * scheme.durationMonths * scheme.memberLimit, currency)}
          </p>
          <p className="mt-1 text-xs text-slate-500">Projection, not collected</p>
        </Card>
      </div>

      {scheme.notes ? (
        <Card className="mt-5">
          <CardHeader title="Notes" />
          <p className="whitespace-pre-line text-sm text-slate-700">{scheme.notes}</p>
        </Card>
      ) : null}

      <Card className="mt-5" padded={false}>
        <div className="p-5 pb-0">
          <CardHeader
            title="Members in this scheme"
            subtitle="Paid and outstanding for the months already due"
            action={
              <div className="flex flex-wrap gap-2">
                <ExportBar
                  rows={roster}
                  columns={[
                    { header: "Member ID", value: (r) => r.code },
                    { header: "Name", value: (r) => r.name },
                    { header: "Phone", value: (r) => r.phone },
                    { header: "Joined", value: (r) => r.joinedAt },
                    { header: "Due to date (₹)", value: (r) => r.due, align: "right" },
                    { header: "Paid (₹)", value: (r) => r.paid, align: "right" },
                    { header: "Outstanding (₹)", value: (r) => r.outstanding, align: "right" },
                  ]}
                  filename={stamp(`scheme-${scheme.name.replace(/\s+/g, "-").toLowerCase()}-members`)}
                  title={`${scheme.name} — members`}
                  organization={snapshot.settings.organizationName}
                />
                {can("scheme:write") && scheme.status === "active" ? (
                  <Button
                    size="sm"
                    onClick={() => setAssignOpen(true)}
                    icon={<Plus className="h-4 w-4" aria-hidden />}
                  >
                    Assign member
                  </Button>
                ) : null}
              </div>
            }
          />
        </div>

        {roster.length === 0 ? (
          <div className="p-5 pt-0">
            <EmptyState
              icon={<Users className="h-8 w-8" aria-hidden />}
              title="No members assigned yet"
              message="Assign members to this scheme to start recording their monthly contributions."
              action={
                can("scheme:write") ? (
                  <Button size="sm" onClick={() => setAssignOpen(true)}>
                    Assign a member
                  </Button>
                ) : null
              }
            />
          </div>
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Member</Th>
                <Th>Joined</Th>
                <Th align="right">Due to date</Th>
                <Th align="right">Paid</Th>
                <Th align="right">Outstanding</Th>
                <Th>Standing</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {roster.map((r) => (
                <Tr key={r.membershipId}>
                  <Td>
                    <Link href={`/members/${r.memberId}`} className="font-medium hover:underline">
                      {r.name}
                    </Link>
                    <span className="block text-xs text-slate-500">
                      {r.code} · {r.phone}
                    </span>
                  </Td>
                  <Td className="whitespace-nowrap text-slate-600">{dateLabel(r.joinedAt)}</Td>
                  <Td align="right" className="tabular text-slate-600">
                    {money(r.due, currency)}
                  </Td>
                  <Td align="right" className="tabular font-medium text-forest-700">
                    {money(r.paid, currency)}
                  </Td>
                  <Td align="right" className="tabular font-medium">
                    {r.outstanding > 0 ? (
                      <span className="text-red-600">{money(r.outstanding, currency)}</span>
                    ) : (
                      <span className="text-slate-400">—</span>
                    )}
                  </Td>
                  <Td>
                    {r.outstanding === 0 ? (
                      <Badge tone="success">Up to date</Badge>
                    ) : (
                      <Badge tone="warning">
                        {r.unpaidPeriods} month{r.unpaidPeriods === 1 ? "" : "s"} pending
                      </Badge>
                    )}
                  </Td>
                  <Td align="right">
                    {can("scheme:write") && scheme.status === "active" ? (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => void onRemove(r.memberId, r.name)}
                      >
                        Remove
                      </Button>
                    ) : null}
                  </Td>
                </Tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>

      <Card className="mt-5" padded={false}>
        <div className="p-5 pb-0">
          <CardHeader
            title="Month by month"
            subtitle="Expected is the contribution of every assigned member; collected is what has actually been recorded."
            action={
              <ExportBar
                rows={periodRows}
                columns={[
                  { header: "Month", value: (r) => r.period },
                  { header: "Due date", value: (r) => r.dueDate },
                  { header: "Expected (₹)", value: (r) => r.expected, align: "right" },
                  { header: "Collected (₹)", value: (r) => r.collected, align: "right" },
                  { header: "Pending (₹)", value: (r) => r.pending, align: "right" },
                ]}
                filename={stamp(`scheme-${scheme.name.replace(/\s+/g, "-").toLowerCase()}-months`)}
                title={`${scheme.name} — month by month`}
                organization={snapshot.settings.organizationName}
              />
            }
          />
        </div>
        <Table>
          <thead>
            <tr>
              <Th>Month</Th>
              <Th>Due date</Th>
              <Th align="right">Expected</Th>
              <Th align="right">Collected</Th>
              <Th align="right">Pending</Th>
              <Th>State</Th>
            </tr>
          </thead>
          <tbody>
            {periodRows.map((r) => (
              <Tr key={r.period}>
                <Td className="font-medium">{monthLabel(r.period)}</Td>
                <Td className="whitespace-nowrap text-slate-600">{dateLabel(r.dueDate)}</Td>
                <Td align="right" className="tabular text-slate-600">
                  {money(r.expected, currency)}
                </Td>
                <Td align="right" className="tabular font-medium text-forest-700">
                  {money(r.collected, currency)}
                </Td>
                <Td align="right" className="tabular">
                  {r.pending > 0 ? (
                    <span className="font-medium text-red-600">{money(r.pending, currency)}</span>
                  ) : (
                    <span className="text-slate-400">—</span>
                  )}
                </Td>
                <Td>
                  {!r.isDue ? (
                    <Badge>Not yet due</Badge>
                  ) : r.pending === 0 && r.expected > 0 ? (
                    <Badge tone="success">Fully collected</Badge>
                  ) : (
                    <Badge tone="warning">Open</Badge>
                  )}
                </Td>
              </Tr>
            ))}
          </tbody>
        </Table>
      </Card>

      <Dialog
        open={assignOpen}
        onClose={() => setAssignOpen(false)}
        title="Assign a member to this scheme"
        footer={
          <>
            <Button variant="secondary" onClick={() => setAssignOpen(false)}>
              Cancel
            </Button>
            <Button onClick={onAssign} loading={busy} disabled={!assignMemberId}>
              Assign
            </Button>
          </>
        }
      >
        <form onSubmit={onAssign} className="space-y-4">
          {assignable.length === 0 ? (
            <Alert tone="info">
              Every active member is already in this scheme. Add a new member first.
            </Alert>
          ) : (
            <>
              <Field label="Member" required>
                <Select
                  value={assignMemberId}
                  onChange={(e) => setAssignMemberId(e.target.value)}
                  required
                >
                  <option value="">Select a member</option>
                  {assignable.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.fullName} ({m.memberCode})
                    </option>
                  ))}
                </Select>
              </Field>
              <Field
                label="Joined this scheme on"
                required
                hint="Contributions before this date are not counted as due for this member."
              >
                <Input
                  type="date"
                  value={assignJoined}
                  onChange={(e) => setAssignJoined(e.target.value)}
                  required
                />
              </Field>
            </>
          )}
        </form>
      </Dialog>
    </>
  );
}
