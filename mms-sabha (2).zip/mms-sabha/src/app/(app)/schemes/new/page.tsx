"use client";

import { PageHeader } from "@/components/ui";
import { SchemeForm } from "@/components/forms/SchemeForm";
import { useAuth } from "@/lib/auth/AuthProvider";
import { NoAccess } from "@/components/NoAccess";

export default function NewSchemePage() {
  const { can } = useAuth();
  if (!can("scheme:write")) {
    return <NoAccess what="create or change Kuri schemes" />;
  }
  return (
    <>
      <PageHeader
        title="New Kuri Scheme"
        subtitle="Set the monthly contribution, duration and member limit. Everything here can be changed later, except the contribution amount once payments exist."
      />
      <SchemeForm />
    </>
  );
}
