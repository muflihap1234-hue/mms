"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Layers, Plus } from "lucide-react";

import {
  Badge,
  Card,
  EmptyState,
  Input,
  LinkButton,
  PageHeader,
  Select,
  Table,
  Td,
  Th,
  Tr,
} from "@/components/ui";
import { ExportBar } from "@/components/ExportBar";
import { useData } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import { currentPeriod, money, monthLabel } from "@/lib/format";
import { pendingRows, schemeEndMonth, schemePeriods } from "@/lib/kuri";
import type { SchemeStatus } from "@/lib/types";
import { stamp } from "@/lib/export";

export default function SchemesPage() {
  const { snapshot } = useData();
  const { can } = useAuth();
  const [term, setTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | SchemeStatus>("all");
  const period = currentPeriod();
  const currency = snapshot.settings.currencySymbol;

  const pending = useMemo(
    () =>
      pendingRows({
        members: snapshot.members,
        schemes: snapshot.schemes,
        memberships: snapshot.memberships,
        ledgers: snapshot.ledgers,
        asOfPeriod: period,
      }),
    [snapshot, period],
  );

  const rows = useMemo(() => {
    const q = term.trim().toLowerCase();
    return snapshot.schemes
      .filter((s) => (statusFilter === "all" ? true : s.status === statusFilter))
      .filter((s) => (q ? s.name.toLowerCase().includes(q) : true))
      .map((s) => {
        const memberCount = snapshot.memberships.filter(
          (ms) => ms.schemeId === s.id && ms.active,
        ).length;
        const collected = snapshot.payments
          .filter((p) => p.schemeId === s.id)
          .reduce((sum, p) => sum + p.amount, 0);
        const outstanding = pending
          .filter((r) => r.schemeId === s.id)
          .reduce((sum, r) => sum + r.pendingAmount, 0);
        const elapsed = schemePeriods(s).filter((p) => p <= period).length;
        return { scheme: s, memberCount, collected, outstanding, elapsed };
      })
      .sort((a, b) => a.scheme.name.localeCompare(b.scheme.name));
  }, [snapshot, term, statusFilter, pending, period]);

  const tones: Record<SchemeStatus, "success" | "info" | "neutral"> = {
    active: "success",
    completed: "info",
    archived: "neutral",
  };

  return (
    <>
      <PageHeader
        title="Kuri Schemes"
        subtitle="Contribution amount, duration and member limit for each scheme."
        actions={
          <>
            <ExportBar
              rows={rows}
              columns={[
                { header: "Scheme", value: (r) => r.scheme.name },
                { header: "Monthly (₹)", value: (r) => r.scheme.monthlyAmount, align: "right" },
                { header: "Duration", value: (r) => `${r.scheme.durationMonths} months` },
                { header: "Start", value: (r) => r.scheme.startMonth },
                { header: "End", value: (r) => schemeEndMonth(r.scheme) },
                { header: "Members", value: (r) => `${r.memberCount}/${r.scheme.memberLimit}` },
                { header: "Collected (₹)", value: (r) => r.collected, align: "right" },
                { header: "Pending (₹)", value: (r) => r.outstanding, align: "right" },
                { header: "Status", value: (r) => r.scheme.status },
              ]}
              filename={stamp("kuri-schemes")}
              title="Kuri Schemes"
              organization={snapshot.settings.organizationName}
            />
            {can("scheme:write") ? (
              <LinkButton href="/schemes/new" icon={<Plus className="h-4 w-4" aria-hidden />}>
                New scheme
              </LinkButton>
            ) : null}
          </>
        }
      />

      <Card padded={false}>
        <div className="flex flex-wrap items-center gap-3 border-b border-slate-200 p-4 print:hidden">
          <Input
            type="search"
            value={term}
            onChange={(e) => setTerm(e.target.value)}
            placeholder="Search schemes"
            aria-label="Search schemes"
            className="sm:max-w-xs"
          />
          <Select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as "all" | SchemeStatus)}
            aria-label="Filter by status"
            className="sm:max-w-[12rem]"
          >
            <option value="all">All statuses</option>
            <option value="active">Active</option>
            <option value="completed">Completed</option>
            <option value="archived">Archived</option>
          </Select>
          <p className="ml-auto text-sm text-slate-500">
            {rows.length} scheme{rows.length === 1 ? "" : "s"}
          </p>
        </div>

        {rows.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={<Layers className="h-8 w-8" aria-hidden />}
              title={snapshot.schemes.length === 0 ? "No schemes yet" : "No matching schemes"}
              message={
                snapshot.schemes.length === 0
                  ? "Create your first Kuri scheme with its monthly contribution, duration and member limit."
                  : "Try a different search term or status filter."
              }
              action={
                snapshot.schemes.length === 0 && can("scheme:write") ? (
                  <LinkButton href="/schemes/new" size="sm">
                    Create a scheme
                  </LinkButton>
                ) : null
              }
            />
          </div>
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Scheme</Th>
                <Th align="right">Monthly</Th>
                <Th>Period</Th>
                <Th align="center">Members</Th>
                <Th align="right">Collected</Th>
                <Th align="right">Pending</Th>
                <Th>Status</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ scheme, memberCount, collected, outstanding, elapsed }) => (
                <Tr key={scheme.id}>
                  <Td>
                    <Link
                      href={`/schemes/${scheme.id}`}
                      className="font-medium text-navy-900 hover:underline"
                    >
                      {scheme.name}
                    </Link>
                    <span className="block text-xs text-slate-500">
                      Month {Math.min(elapsed, scheme.durationMonths)} of {scheme.durationMonths} ·
                      due day {scheme.dueDay}
                    </span>
                  </Td>
                  <Td align="right" className="tabular">
                    {money(scheme.monthlyAmount, currency)}
                  </Td>
                  <Td className="whitespace-nowrap text-slate-600">
                    {monthLabel(scheme.startMonth)} — {monthLabel(schemeEndMonth(scheme))}
                  </Td>
                  <Td align="center" className="tabular text-slate-600">
                    {memberCount}/{scheme.memberLimit}
                  </Td>
                  <Td align="right" className="tabular font-medium text-forest-700">
                    {money(collected, currency)}
                  </Td>
                  <Td align="right" className="tabular font-medium">
                    {outstanding > 0 ? (
                      <span className="text-red-600">{money(outstanding, currency)}</span>
                    ) : (
                      <span className="text-slate-400">—</span>
                    )}
                  </Td>
                  <Td>
                    <Badge tone={tones[scheme.status]}>
                      {scheme.status.charAt(0).toUpperCase() + scheme.status.slice(1)}
                    </Badge>
                  </Td>
                </Tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </>
  );
}
