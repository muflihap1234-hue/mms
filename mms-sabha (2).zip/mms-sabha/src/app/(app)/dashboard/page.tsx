"use client";

import { useMemo } from "react";
import Link from "next/link";
import {
  BadgeIndianRupee,
  Bell,
  CalendarClock,
  CheckCircle2,
  Clock,
  Layers,
  TrendingUp,
  TriangleAlert,
  Users,
} from "lucide-react";

import { Card, CardHeader, EmptyState, LinkButton, Table, Td, Th, Tr } from "@/components/ui";
import { BRAND_NAME } from "@/components/ui/BrandMark";
import { StatCard } from "@/components/ui/StatCard";
import { MonthlyCollectionChart, PaidPendingChart } from "@/components/charts/Charts";
import { useData, useLookups } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import {
  dashboardStats,
  monthlyCollectionSeries,
  pendingRows,
  schemeDueDate,
} from "@/lib/kuri";
import { currentPeriod, dateLabel, money, monthLabel, monthLabelLong } from "@/lib/format";

export default function DashboardPage() {
  const { snapshot } = useData();
  const { memberName, memberCode, schemeName, currency } = useLookups();
  const { user } = useAuth();
  const period = currentPeriod();

  const { members, schemes, memberships, payments, ledgers, settings } = snapshot;

  const stats = useMemo(
    () => dashboardStats(members, schemes, memberships, payments, ledgers, period),
    [members, schemes, memberships, payments, ledgers, period],
  );

  const series = useMemo(
    () => monthlyCollectionSeries(payments, schemes, memberships, period, 12),
    [payments, schemes, memberships, period],
  );

  const pending = useMemo(
    () => pendingRows({ members, schemes, memberships, ledgers, asOfPeriod: period }),
    [members, schemes, memberships, ledgers, period],
  );

  const recent = useMemo(
    () => [...payments].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 8),
    [payments],
  );

  const upcoming = useMemo(() => {
    const rows = schemes
      .filter((s) => s.status === "active")
      .map((s) => ({ scheme: s, due: schemeDueDate(s, period) }))
      .filter((r) => r.due >= new Date().toISOString().slice(0, 10));
    return rows.sort((a, b) => a.due.localeCompare(b.due));
  }, [schemes, period]);

  const activity = useMemo(
    () => [...snapshot.auditLogs].sort((a, b) => b.at.localeCompare(a.at)).slice(0, 6),
    [snapshot.auditLogs],
  );

  const nothingYet = members.length === 0 && schemes.length === 0;

  if (nothingYet) {
    return (
      <>
        <header className="mb-6">
          <h1 className="text-2xl font-semibold tracking-tight text-navy-900">
            Welcome{user ? `, ${user.name.split(" ")[0]}` : ""}
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            {settings.organizationName || BRAND_NAME} · {monthLabelLong(period)}
          </p>
        </header>
        <Card>
          <EmptyState
            icon={<Layers className="h-8 w-8" aria-hidden />}
            title="Set up your first Kuri scheme"
            message="Create a scheme with its monthly contribution and duration, add your members, assign them to the scheme, and you can start recording cash contributions. The dashboard fills in from the records you enter — nothing is pre-filled."
            action={
              <div className="flex flex-wrap justify-center gap-2">
                <LinkButton href="/schemes/new">Create a scheme</LinkButton>
                <LinkButton href="/members/new" variant="secondary">
                  Add a member
                </LinkButton>
              </div>
            }
          />
        </Card>
      </>
    );
  }

  return (
    <>
      <header className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight text-navy-900">
          Welcome{user ? `, ${user.name.split(" ")[0]}` : ""}
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          {settings.organizationName || BRAND_NAME} · {monthLabelLong(period)}
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Total Members"
          value={String(stats.totalMembers)}
          sub={`${members.length} record${members.length === 1 ? "" : "s"} in total`}
          icon={<Users className="h-5 w-5" aria-hidden />}
          href="/members"
        />
        <StatCard
          label="Active Kuri Schemes"
          value={String(stats.activeSchemes)}
          sub={`${schemes.length} scheme${schemes.length === 1 ? "" : "s"} in total`}
          icon={<Layers className="h-5 w-5" aria-hidden />}
          tone="forest"
          href="/schemes"
        />
        <StatCard
          label="Total Collection"
          value={money(stats.totalCollection, currency)}
          sub={`${payments.length} payment${payments.length === 1 ? "" : "s"} recorded`}
          icon={<BadgeIndianRupee className="h-5 w-5" aria-hidden />}
          tone="forest"
          href="/history"
        />
        <StatCard
          label={`${monthLabel(period)} Collection`}
          value={money(stats.currentMonthCollection, currency)}
          sub="Received this calendar month"
          icon={<TrendingUp className="h-5 w-5" aria-hidden />}
          href="/history"
        />
        <StatCard
          label="Total Pending"
          value={money(stats.totalPending, currency)}
          sub={`${pending.length} contribution${pending.length === 1 ? "" : "s"} outstanding`}
          icon={<TriangleAlert className="h-5 w-5" aria-hidden />}
          tone="red"
          href="/pending"
        />
        <StatCard
          label="Paid Members"
          value={String(stats.paidMembersThisMonth)}
          sub={`Settled ${monthLabel(period)} in full`}
          icon={<CheckCircle2 className="h-5 w-5" aria-hidden />}
          tone="forest"
        />
        <StatCard
          label="Pending Members"
          value={String(stats.pendingMembersThisMonth)}
          sub={`Still owe for ${monthLabel(period)}`}
          icon={<Clock className="h-5 w-5" aria-hidden />}
          tone="amber"
          href="/pending"
        />
        <StatCard
          label="Reminders Prepared"
          value={String(snapshot.reminders.length)}
          sub="WhatsApp messages opened by admins"
          icon={<Bell className="h-5 w-5" aria-hidden />}
          tone="slate"
          href="/reminders"
        />
      </div>

      <div className="mt-6 grid gap-5 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader
            title="Monthly collection"
            subtitle="Collected against expected, last 12 months"
          />
          <MonthlyCollectionChart data={series} currency={currency} />
        </Card>

        <Card>
          <CardHeader title="Paid vs pending" subtitle={`Members liable for ${monthLabel(period)}`} />
          <PaidPendingChart
            paid={stats.paidMembersThisMonth}
            pending={stats.pendingMembersThisMonth}
          />
        </Card>
      </div>

      <div className="mt-6 grid gap-5 xl:grid-cols-3">
        <Card className="xl:col-span-2" padded={false}>
          <div className="p-5 pb-0">
            <CardHeader
              title="Recent transactions"
              subtitle="Latest payments recorded by administrators"
              action={
                <Link href="/history" className="text-sm font-medium text-navy-700 hover:underline">
                  View all
                </Link>
              }
            />
          </div>
          {recent.length === 0 ? (
            <div className="p-5 pt-0">
              <EmptyState
                title="No payments recorded yet"
                message="When an administrator records a cash contribution it appears here."
                action={<LinkButton href="/payments/new" size="sm">Record a payment</LinkButton>}
              />
            </div>
          ) : (
            <Table>
              <thead>
                <tr>
                  <Th>Member</Th>
                  <Th>Scheme</Th>
                  <Th>Month</Th>
                  <Th align="right">Amount</Th>
                  <Th>Received</Th>
                </tr>
              </thead>
              <tbody>
                {recent.map((p) => (
                  <Tr key={p.id}>
                    <Td>
                      <Link href={`/members/${p.memberId}`} className="font-medium hover:underline">
                        {memberName(p.memberId)}
                      </Link>
                      <span className="block text-xs text-slate-500">{memberCode(p.memberId)}</span>
                    </Td>
                    <Td className="text-slate-600">{schemeName(p.schemeId)}</Td>
                    <Td className="text-slate-600">{monthLabel(p.period)}</Td>
                    <Td align="right" className="tabular font-medium">
                      {money(p.amount, currency)}
                    </Td>
                    <Td className="text-slate-600">
                      {dateLabel(p.paidOn)}
                      <span className="block text-xs text-slate-500">by {p.receivedBy}</span>
                    </Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card>

        <div className="space-y-5">
          <Card>
            <CardHeader title="Upcoming due dates" subtitle={monthLabelLong(period)} />
            {upcoming.length === 0 ? (
              <p className="text-sm text-slate-500">
                Every due date for {monthLabel(period)} has passed. Check pending payments for what
                is still outstanding.
              </p>
            ) : (
              <ul className="space-y-3">
                {upcoming.map(({ scheme, due }) => (
                  <li key={scheme.id} className="flex items-start gap-3">
                    <CalendarClock className="mt-0.5 h-4 w-4 shrink-0 text-navy-500" aria-hidden />
                    <div className="min-w-0">
                      <Link
                        href={`/schemes/${scheme.id}`}
                        className="block truncate text-sm font-medium text-navy-900 hover:underline"
                      >
                        {scheme.name}
                      </Link>
                      <p className="text-xs text-slate-500">
                        {money(scheme.monthlyAmount, currency)} due {dateLabel(due)}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
            <div className="mt-4 border-t border-slate-100 pt-4">
              <p className="text-xs text-slate-500">
                Reminder schedule: day {settings.reminderDay} of each month.
              </p>
            </div>
          </Card>

          <Card>
            <CardHeader title="Recent activity" subtitle="Payment audit trail" />
            {activity.length === 0 ? (
              <p className="text-sm text-slate-500">No payment activity yet.</p>
            ) : (
              <ul className="space-y-3">
                {activity.map((log) => (
                  <li key={log.id} className="text-sm">
                    <p className="text-navy-900">
                      <span className="font-medium">{log.actorName}</span>{" "}
                      {log.action === "create" ? "recorded" : "corrected"} a payment of{" "}
                      <span className="tabular font-medium">
                        {money(Number(log.after.amount ?? 0), currency)}
                      </span>{" "}
                      for {memberName(String(log.after.memberId ?? ""))}
                    </p>
                    <p className="text-xs text-slate-500">{dateLabel(log.at)}</p>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
