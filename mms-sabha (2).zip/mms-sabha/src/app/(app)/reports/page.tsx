"use client";

import { useMemo, useState } from "react";
import { FileBarChart } from "lucide-react";

import {
  Card,
  CardHeader,
  EmptyState,
  Field,
  Input,
  PageHeader,
  Select,
  Table,
  Td,
  Th,
  Tr,
} from "@/components/ui";
import { ExportBar } from "@/components/ExportBar";
import { SchemeCollectionChart } from "@/components/charts/Charts";
import { useData, useLookups } from "@/lib/DataProvider";
import { currentPeriod, dateLabel, money, monthLabel } from "@/lib/format";
import { pendingRows } from "@/lib/kuri";
import { PAYMENT_METHOD_LABEL } from "@/lib/types";
import { stamp, type Column } from "@/lib/export";

type ReportType =
  | "daily"
  | "monthly"
  | "yearly"
  | "scheme"
  | "member"
  | "pending"
  | "transactions";

const REPORT_LABEL: Record<ReportType, string> = {
  daily: "Daily Collection",
  monthly: "Monthly Collection",
  yearly: "Yearly Collection",
  scheme: "Scheme-wise Collection",
  member: "Member-wise Collection",
  pending: "Pending Payment Report",
  transactions: "Payment History",
};

interface GenericRow {
  key: string;
  cells: Array<{ text: string; align?: "left" | "right"; strong?: boolean; tone?: "red" | "green" }>;
  raw: Record<string, string | number>;
}

export default function ReportsPage() {
  const { snapshot } = useData();
  const { memberName, memberCode, schemeName } = useLookups();
  const period = currentPeriod();
  const currency = snapshot.settings.currencySymbol;

  const [type, setType] = useState<ReportType>("monthly");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [schemeId, setSchemeId] = useState("all");
  const [memberId, setMemberId] = useState("all");

  const filteredPayments = useMemo(
    () =>
      snapshot.payments
        .filter((p) => (from ? p.paidOn >= from : true))
        .filter((p) => (to ? p.paidOn <= to : true))
        .filter((p) => (schemeId === "all" ? true : p.schemeId === schemeId))
        .filter((p) => (memberId === "all" ? true : p.memberId === memberId)),
    [snapshot.payments, from, to, schemeId, memberId],
  );

  const pending = useMemo(
    () =>
      pendingRows({
        members: snapshot.members,
        schemes: snapshot.schemes,
        memberships: snapshot.memberships,
        ledgers: snapshot.ledgers,
        asOfPeriod: period,
      })
        .filter((r) => (schemeId === "all" ? true : r.schemeId === schemeId))
        .filter((r) => (memberId === "all" ? true : r.memberId === memberId)),
    [snapshot, period, schemeId, memberId],
  );

  const report = useMemo(() => {
    switch (type) {
      case "daily": {
        const map = new Map<string, { amount: number; count: number }>();
        for (const p of filteredPayments) {
          const e = map.get(p.paidOn) ?? { amount: 0, count: 0 };
          e.amount += p.amount;
          e.count += 1;
          map.set(p.paidOn, e);
        }
        const rows: GenericRow[] = [...map.entries()]
          .sort((a, b) => b[0].localeCompare(a[0]))
          .map(([date, e]) => ({
            key: date,
            cells: [
              { text: dateLabel(date) },
              { text: String(e.count), align: "right" },
              { text: money(e.amount, currency), align: "right", strong: true, tone: "green" },
            ],
            raw: { Date: date, Payments: e.count, "Amount (₹)": e.amount },
          }));
        return {
          headers: ["Date", "Payments", "Collected"],
          aligns: ["left", "right", "right"] as const,
          rows,
          total: rows.reduce((s, r) => s + Number(r.raw["Amount (₹)"]), 0),
        };
      }

      case "monthly": {
        const map = new Map<string, { amount: number; count: number }>();
        for (const p of filteredPayments) {
          const key = p.paidOn.slice(0, 7);
          const e = map.get(key) ?? { amount: 0, count: 0 };
          e.amount += p.amount;
          e.count += 1;
          map.set(key, e);
        }
        const rows: GenericRow[] = [...map.entries()]
          .sort((a, b) => b[0].localeCompare(a[0]))
          .map(([m, e]) => ({
            key: m,
            cells: [
              { text: monthLabel(m) },
              { text: String(e.count), align: "right" },
              { text: money(e.amount, currency), align: "right", strong: true, tone: "green" },
            ],
            raw: { Month: m, Payments: e.count, "Amount (₹)": e.amount },
          }));
        return {
          headers: ["Month", "Payments", "Collected"],
          aligns: ["left", "right", "right"] as const,
          rows,
          total: rows.reduce((s, r) => s + Number(r.raw["Amount (₹)"]), 0),
        };
      }

      case "yearly": {
        const map = new Map<string, { amount: number; count: number }>();
        for (const p of filteredPayments) {
          const key = p.paidOn.slice(0, 4);
          const e = map.get(key) ?? { amount: 0, count: 0 };
          e.amount += p.amount;
          e.count += 1;
          map.set(key, e);
        }
        const rows: GenericRow[] = [...map.entries()]
          .sort((a, b) => b[0].localeCompare(a[0]))
          .map(([y, e]) => ({
            key: y,
            cells: [
              { text: y },
              { text: String(e.count), align: "right" },
              { text: money(e.amount, currency), align: "right", strong: true, tone: "green" },
            ],
            raw: { Year: y, Payments: e.count, "Amount (₹)": e.amount },
          }));
        return {
          headers: ["Year", "Payments", "Collected"],
          aligns: ["left", "right", "right"] as const,
          rows,
          total: rows.reduce((s, r) => s + Number(r.raw["Amount (₹)"]), 0),
        };
      }

      case "scheme": {
        const rows: GenericRow[] = snapshot.schemes
          .filter((s) => (schemeId === "all" ? true : s.id === schemeId))
          .map((s) => {
            const collected = filteredPayments
              .filter((p) => p.schemeId === s.id)
              .reduce((sum, p) => sum + p.amount, 0);
            const outstanding = pending
              .filter((r) => r.schemeId === s.id)
              .reduce((sum, r) => sum + r.pendingAmount, 0);
            const members = snapshot.memberships.filter(
              (ms) => ms.schemeId === s.id && ms.active,
            ).length;
            return {
              key: s.id,
              cells: [
                { text: s.name },
                { text: String(members), align: "right" as const },
                { text: money(s.monthlyAmount, currency), align: "right" as const },
                {
                  text: money(collected, currency),
                  align: "right" as const,
                  strong: true,
                  tone: "green" as const,
                },
                {
                  text: outstanding > 0 ? money(outstanding, currency) : "—",
                  align: "right" as const,
                  tone: outstanding > 0 ? ("red" as const) : undefined,
                },
              ],
              raw: {
                Scheme: s.name,
                Members: members,
                "Monthly (₹)": s.monthlyAmount,
                "Collected (₹)": collected,
                "Pending (₹)": outstanding,
              },
            };
          })
          .sort((a, b) => Number(b.raw["Collected (₹)"]) - Number(a.raw["Collected (₹)"]));
        return {
          headers: ["Scheme", "Members", "Monthly", "Collected", "Pending"],
          aligns: ["left", "right", "right", "right", "right"] as const,
          rows,
          total: rows.reduce((s, r) => s + Number(r.raw["Collected (₹)"]), 0),
        };
      }

      case "member": {
        const rows: GenericRow[] = snapshot.members
          .filter((m) => (memberId === "all" ? true : m.id === memberId))
          .map((m) => {
            const collected = filteredPayments
              .filter((p) => p.memberId === m.id)
              .reduce((sum, p) => sum + p.amount, 0);
            const outstanding = pending
              .filter((r) => r.memberId === m.id)
              .reduce((sum, r) => sum + r.pendingAmount, 0);
            const count = filteredPayments.filter((p) => p.memberId === m.id).length;
            return {
              key: m.id,
              cells: [
                { text: `${m.fullName} (${m.memberCode})` },
                { text: m.phone },
                { text: String(count), align: "right" as const },
                {
                  text: money(collected, currency),
                  align: "right" as const,
                  strong: true,
                  tone: "green" as const,
                },
                {
                  text: outstanding > 0 ? money(outstanding, currency) : "—",
                  align: "right" as const,
                  tone: outstanding > 0 ? ("red" as const) : undefined,
                },
              ],
              raw: {
                "Member ID": m.memberCode,
                Member: m.fullName,
                Phone: m.phone,
                Payments: count,
                "Collected (₹)": collected,
                "Pending (₹)": outstanding,
              },
            };
          })
          .filter((r) => Number(r.raw["Collected (₹)"]) > 0 || Number(r.raw["Pending (₹)"]) > 0)
          .sort((a, b) => Number(b.raw["Collected (₹)"]) - Number(a.raw["Collected (₹)"]));
        return {
          headers: ["Member", "Phone", "Payments", "Collected", "Pending"],
          aligns: ["left", "left", "right", "right", "right"] as const,
          rows,
          total: rows.reduce((s, r) => s + Number(r.raw["Collected (₹)"]), 0),
        };
      }

      case "pending": {
        const rows: GenericRow[] = pending.map((r) => ({
          key: `${r.schemeId}-${r.memberId}-${r.period}`,
          cells: [
            { text: `${r.memberName} (${r.memberCode})` },
            { text: r.schemeName },
            { text: monthLabel(r.period) },
            { text: dateLabel(r.dueDate) },
            { text: money(r.dueAmount, currency), align: "right" as const },
            {
              text: money(r.pendingAmount, currency),
              align: "right" as const,
              strong: true,
              tone: "red" as const,
            },
          ],
          raw: {
            "Member ID": r.memberCode,
            Member: r.memberName,
            Phone: r.phone,
            Scheme: r.schemeName,
            Month: r.period,
            "Due date": r.dueDate,
            "Due (₹)": r.dueAmount,
            "Paid (₹)": r.paidAmount,
            "Pending (₹)": r.pendingAmount,
          },
        }));
        return {
          headers: ["Member", "Scheme", "Month", "Due date", "Due", "Pending"],
          aligns: ["left", "left", "left", "left", "right", "right"] as const,
          rows,
          total: rows.reduce((s, r) => s + Number(r.raw["Pending (₹)"]), 0),
        };
      }

      case "transactions":
      default: {
        const rows: GenericRow[] = [...filteredPayments]
          .sort((a, b) => b.paidOn.localeCompare(a.paidOn))
          .map((p) => ({
            key: p.id,
            cells: [
              { text: p.receiptNo },
              { text: dateLabel(p.paidOn) },
              { text: `${memberName(p.memberId)} (${memberCode(p.memberId)})` },
              { text: schemeName(p.schemeId) },
              { text: monthLabel(p.period) },
              {
                text: money(p.amount, currency),
                align: "right" as const,
                strong: true,
                tone: "green" as const,
              },
              { text: PAYMENT_METHOD_LABEL[p.method] },
            ],
            raw: {
              Receipt: p.receiptNo,
              "Paid on": p.paidOn,
              "Member ID": memberCode(p.memberId),
              Member: memberName(p.memberId),
              Scheme: schemeName(p.schemeId),
              Month: p.period,
              "Amount (₹)": p.amount,
              Method: PAYMENT_METHOD_LABEL[p.method],
              "Received by": p.receivedBy,
              "Recorded by": p.createdByName,
            },
          }));
        return {
          headers: ["Receipt", "Paid on", "Member", "Scheme", "Month", "Amount", "Method"],
          aligns: ["left", "left", "left", "left", "left", "right", "left"] as const,
          rows,
          total: rows.reduce((s, r) => s + Number(r.raw["Amount (₹)"]), 0),
        };
      }
    }
  }, [
    type,
    filteredPayments,
    pending,
    snapshot.schemes,
    snapshot.members,
    snapshot.memberships,
    schemeId,
    memberId,
    currency,
    memberName,
    memberCode,
    schemeName,
  ]);

  /** Export columns are derived from the first row's raw keys. */
  const exportColumns: Column<GenericRow>[] = useMemo(() => {
    const first = report.rows[0];
    if (!first) return [];
    return Object.keys(first.raw).map((key) => ({
      header: key,
      value: (row: GenericRow) => row.raw[key] ?? "",
      align: typeof first.raw[key] === "number" ? ("right" as const) : ("left" as const),
    }));
  }, [report.rows]);

  const schemeChartData = useMemo(
    () =>
      snapshot.schemes
        .filter((s) => s.status !== "archived")
        .map((s) => ({
          name: s.name.length > 18 ? `${s.name.slice(0, 17)}…` : s.name,
          collected: snapshot.payments
            .filter((p) => p.schemeId === s.id)
            .reduce((sum, p) => sum + p.amount, 0),
          pending: pending
            .filter((r) => r.schemeId === s.id)
            .reduce((sum, r) => sum + r.pendingAmount, 0),
        })),
    [snapshot.schemes, snapshot.payments, pending],
  );

  const filterSummary = [
    from || to ? `${from || "start"} to ${to || "today"}` : "All dates",
    schemeId === "all" ? "All schemes" : schemeName(schemeId),
    memberId === "all" ? "All members" : memberName(memberId),
  ].join(" · ");

  const isPendingReport = type === "pending";

  return (
    <>
      <PageHeader
        title="Reports"
        subtitle="Built from recorded payments and the contribution schedule of each scheme."
        actions={
          <ExportBar
            rows={report.rows}
            columns={exportColumns}
            filename={stamp(`report-${type}`)}
            title={REPORT_LABEL[type]}
            subtitle={filterSummary}
            organization={snapshot.settings.organizationName}
          />
        }
      />

      <Card padded={false}>
        <div className="grid gap-3 border-b border-slate-200 p-4 sm:grid-cols-2 lg:grid-cols-5 print:hidden">
          <Field label="Report">
            <Select value={type} onChange={(e) => setType(e.target.value as ReportType)}>
              {(Object.keys(REPORT_LABEL) as ReportType[]).map((t) => (
                <option key={t} value={t}>
                  {REPORT_LABEL[t]}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="From" hint={isPendingReport ? "Not used for pending" : undefined}>
            <Input
              type="date"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              disabled={isPendingReport}
            />
          </Field>
          <Field label="To" hint={isPendingReport ? "Not used for pending" : undefined}>
            <Input
              type="date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              disabled={isPendingReport}
            />
          </Field>
          <Field label="Scheme">
            <Select value={schemeId} onChange={(e) => setSchemeId(e.target.value)}>
              <option value="all">All schemes</option>
              {snapshot.schemes.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Member">
            <Select value={memberId} onChange={(e) => setMemberId(e.target.value)}>
              <option value="all">All members</option>
              {[...snapshot.members]
                .sort((a, b) => a.fullName.localeCompare(b.fullName))
                .map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.fullName} ({m.memberCode})
                  </option>
                ))}
            </Select>
          </Field>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 bg-slate-50/70 px-4 py-3">
          <div>
            <p className="font-semibold text-navy-900">{REPORT_LABEL[type]}</p>
            <p className="text-xs text-slate-500">
              {snapshot.settings.organizationName} · {filterSummary}
            </p>
          </div>
          <p className="text-sm font-semibold text-navy-900">
            {isPendingReport ? "Total pending" : "Total collected"}{" "}
            <span className={isPendingReport ? "tabular text-red-600" : "tabular text-forest-700"}>
              {money(report.total, currency)}
            </span>
          </p>
        </div>

        {report.rows.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={<FileBarChart className="h-8 w-8" aria-hidden />}
              title="Nothing to report"
              message="No records match the filters you have chosen. Widen the date range, or record some payments first."
            />
          </div>
        ) : (
          <Table>
            <thead>
              <tr>
                {report.headers.map((h, i) => (
                  <Th key={h} align={report.aligns[i]}>
                    {h}
                  </Th>
                ))}
              </tr>
            </thead>
            <tbody>
              {report.rows.map((row) => (
                <Tr key={row.key}>
                  {row.cells.map((cell, i) => (
                    <Td
                      key={i}
                      align={cell.align}
                      className={[
                        cell.align === "right" ? "tabular" : "",
                        cell.strong ? "font-medium" : "",
                        cell.tone === "red" ? "text-red-600" : "",
                        cell.tone === "green" ? "text-forest-700" : "",
                      ]
                        .filter(Boolean)
                        .join(" ")}
                    >
                      {cell.text}
                    </Td>
                  ))}
                </Tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>

      {schemeChartData.length > 0 ? (
        <Card className="mt-5">
          <CardHeader
            title="Collected against pending, by scheme"
            subtitle="All time, across every month recorded"
          />
          <SchemeCollectionChart data={schemeChartData} currency={currency} />
        </Card>
      ) : null}
    </>
  );
}
