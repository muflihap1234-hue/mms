"use client";

import { PageHeader } from "@/components/ui";
import { MemberForm } from "@/components/forms/MemberForm";
import { NoAccess } from "@/components/NoAccess";
import { useAuth } from "@/lib/auth/AuthProvider";

export default function NewMemberPage() {
  const { can } = useAuth();
  if (!can("member:write")) return <NoAccess what="add or change members" />;
  return (
    <>
      <PageHeader
        title="Add Member"
        subtitle="The phone number is used for WhatsApp reminders, so enter it carefully."
      />
      <MemberForm />
    </>
  );
}
