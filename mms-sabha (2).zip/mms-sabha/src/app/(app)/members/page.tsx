"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Plus, Users } from "lucide-react";

import {
  Badge,
  Card,
  EmptyState,
  Input,
  LinkButton,
  PageHeader,
  Select,
  Table,
  Td,
  Th,
  Tr,
} from "@/components/ui";
import { ExportBar } from "@/components/ExportBar";
import { useData } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import { currentPeriod, dateLabel, money } from "@/lib/format";
import { memberStandings } from "@/lib/kuri";
import type { MemberStatus } from "@/lib/types";
import { stamp } from "@/lib/export";

export default function MembersPage() {
  const { snapshot } = useData();
  const { can } = useAuth();
  const [term, setTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | MemberStatus>("active");
  const [schemeFilter, setSchemeFilter] = useState("all");
  const period = currentPeriod();
  const currency = snapshot.settings.currencySymbol;

  const rows = useMemo(() => {
    const q = term.trim().toLowerCase();
    const digits = q.replace(/\D/g, "");

    return snapshot.members
      .filter((m) => (statusFilter === "all" ? true : m.status === statusFilter))
      .filter((m) =>
        schemeFilter === "all"
          ? true
          : snapshot.memberships.some(
              (ms) => ms.memberId === m.id && ms.schemeId === schemeFilter && ms.active,
            ),
      )
      .filter((m) =>
        q
          ? m.fullName.toLowerCase().includes(q) ||
            m.memberCode.toLowerCase().includes(q) ||
            (digits.length > 0 && m.phone.replace(/\D/g, "").includes(digits))
          : true,
      )
      .map((m) => {
        const standings = memberStandings(m.id, {
          members: snapshot.members,
          schemes: snapshot.schemes,
          memberships: snapshot.memberships,
          ledgers: snapshot.ledgers,
          asOfPeriod: period,
        });
        return {
          member: m,
          schemeCount: standings.length,
          schemeNames: standings.map((s) => s.schemeName).join(", "),
          paid: standings.reduce((s, x) => s + x.totalPaid, 0),
          outstanding: standings.reduce((s, x) => s + x.outstanding, 0),
        };
      })
      .sort((a, b) => a.member.fullName.localeCompare(b.member.fullName));
  }, [snapshot, term, statusFilter, schemeFilter, period]);

  const tones: Record<MemberStatus, "success" | "warning" | "neutral"> = {
    active: "success",
    inactive: "warning",
    archived: "neutral",
  };

  return (
    <>
      <PageHeader
        title="Members"
        subtitle="Everyone on the register, with what they have paid and what is outstanding."
        actions={
          <>
            <ExportBar
              rows={rows}
              columns={[
                { header: "Member ID", value: (r) => r.member.memberCode },
                { header: "Name", value: (r) => r.member.fullName },
                { header: "Phone", value: (r) => r.member.phone },
                { header: "Address", value: (r) => r.member.address },
                { header: "Joined", value: (r) => r.member.joiningDate },
                { header: "Schemes", value: (r) => r.schemeNames },
                { header: "Paid (₹)", value: (r) => r.paid, align: "right" },
                { header: "Outstanding (₹)", value: (r) => r.outstanding, align: "right" },
                { header: "Status", value: (r) => r.member.status },
              ]}
              filename={stamp("members")}
              title="Member register"
              organization={snapshot.settings.organizationName}
            />
            {can("member:write") ? (
              <LinkButton href="/members/new" icon={<Plus className="h-4 w-4" aria-hidden />}>
                Add member
              </LinkButton>
            ) : null}
          </>
        }
      />

      <Card padded={false}>
        <div className="flex flex-wrap items-center gap-3 border-b border-slate-200 p-4 print:hidden">
          <Input
            type="search"
            value={term}
            onChange={(e) => setTerm(e.target.value)}
            placeholder="Search by name, ID or phone"
            aria-label="Search members"
            className="sm:max-w-xs"
          />
          <Select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as "all" | MemberStatus)}
            aria-label="Filter by status"
            className="sm:max-w-[11rem]"
          >
            <option value="active">Active only</option>
            <option value="inactive">Inactive</option>
            <option value="archived">Archived</option>
            <option value="all">All statuses</option>
          </Select>
          <Select
            value={schemeFilter}
            onChange={(e) => setSchemeFilter(e.target.value)}
            aria-label="Filter by scheme"
            className="sm:max-w-[14rem]"
          >
            <option value="all">All schemes</option>
            {snapshot.schemes.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
          <p className="ml-auto text-sm text-slate-500">
            {rows.length} member{rows.length === 1 ? "" : "s"}
          </p>
        </div>

        {rows.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={<Users className="h-8 w-8" aria-hidden />}
              title={snapshot.members.length === 0 ? "No members yet" : "No matching members"}
              message={
                snapshot.members.length === 0
                  ? "Add the members of your Kuri to build the register."
                  : "Try a different search term or clear the filters."
              }
              action={
                snapshot.members.length === 0 && can("member:write") ? (
                  <LinkButton href="/members/new" size="sm">
                    Add the first member
                  </LinkButton>
                ) : null
              }
            />
          </div>
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Member</Th>
                <Th>Phone</Th>
                <Th>Joined</Th>
                <Th>Schemes</Th>
                <Th align="right">Paid</Th>
                <Th align="right">Outstanding</Th>
                <Th>Status</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ member, schemeCount, paid, outstanding }) => (
                <Tr key={member.id}>
                  <Td>
                    <Link
                      href={`/members/${member.id}`}
                      className="font-medium text-navy-900 hover:underline"
                    >
                      {member.fullName}
                    </Link>
                    <span className="block text-xs text-slate-500">{member.memberCode}</span>
                  </Td>
                  <Td className="whitespace-nowrap text-slate-600">{member.phone}</Td>
                  <Td className="whitespace-nowrap text-slate-600">
                    {dateLabel(member.joiningDate)}
                  </Td>
                  <Td className="text-slate-600">
                    {schemeCount === 0 ? (
                      <span className="text-amber-700">Not assigned</span>
                    ) : (
                      `${schemeCount} scheme${schemeCount === 1 ? "" : "s"}`
                    )}
                  </Td>
                  <Td align="right" className="tabular font-medium text-forest-700">
                    {money(paid, currency)}
                  </Td>
                  <Td align="right" className="tabular font-medium">
                    {outstanding > 0 ? (
                      <span className="text-red-600">{money(outstanding, currency)}</span>
                    ) : (
                      <span className="text-slate-400">—</span>
                    )}
                  </Td>
                  <Td>
                    <Badge tone={tones[member.status]}>
                      {member.status.charAt(0).toUpperCase() + member.status.slice(1)}
                    </Badge>
                  </Td>
                </Tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </>
  );
}
