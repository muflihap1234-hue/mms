"use client";

import { useParams } from "next/navigation";

import { PageHeader } from "@/components/ui";
import { MemberForm } from "@/components/forms/MemberForm";
import { NoAccess, NotFoundCard } from "@/components/NoAccess";
import { useAuth } from "@/lib/auth/AuthProvider";
import { useData } from "@/lib/DataProvider";

export default function EditMemberPage() {
  const params = useParams<{ id: string }>();
  const { can } = useAuth();
  const { snapshot } = useData();
  const member = snapshot.members.find((m) => m.id === params.id);

  if (!can("member:write")) return <NoAccess what="add or change members" />;
  if (!member) {
    return (
      <NotFoundCard
        title="Member not found"
        message="This member may have been removed, or the link is out of date."
        backHref="/members"
        backLabel="Back to members"
      />
    );
  }

  return (
    <>
      <PageHeader title={`Edit — ${member.fullName}`} subtitle={member.memberCode} />
      <MemberForm member={member} />
    </>
  );
}
