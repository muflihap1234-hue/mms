"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { Archive, BadgeIndianRupee, MessageCircle, Pencil, RotateCcw } from "lucide-react";

import {
  Alert,
  Badge,
  Button,
  Card,
  CardHeader,
  EmptyState,
  LinkButton,
  PageHeader,
  Table,
  Td,
  Th,
  Tr,
} from "@/components/ui";
import { useToast } from "@/components/ui/Toast";
import { NotFoundCard } from "@/components/NoAccess";
import { ExportBar } from "@/components/ExportBar";
import { useData } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import { currentPeriod, dateLabel, money, monthLabel, waNumber } from "@/lib/format";
import { memberStandings, renderReminder } from "@/lib/kuri";
import { PAYMENT_METHOD_LABEL } from "@/lib/types";
import { stamp } from "@/lib/export";

export default function MemberDetailPage() {
  const params = useParams<{ id: string }>();
  const { snapshot, run } = useData();
  const { can, user } = useAuth();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const period = currentPeriod();
  const currency = snapshot.settings.currencySymbol;

  const member = snapshot.members.find((m) => m.id === params.id);

  const standings = useMemo(() => {
    if (!member) return [];
    return memberStandings(member.id, {
      members: snapshot.members,
      schemes: snapshot.schemes,
      memberships: snapshot.memberships,
      ledgers: snapshot.ledgers,
      asOfPeriod: period,
    });
  }, [member, snapshot, period]);

  const payments = useMemo(() => {
    if (!member) return [];
    return snapshot.payments
      .filter((p) => p.memberId === member.id)
      .sort((a, b) => b.paidOn.localeCompare(a.paidOn) || b.createdAt.localeCompare(a.createdAt));
  }, [member, snapshot.payments]);

  if (!member) {
    return (
      <NotFoundCard
        title="Member not found"
        message="This member may have been removed, or the link is out of date."
        backHref="/members"
        backLabel="Back to members"
      />
    );
  }

  const totalPaid = standings.reduce((s, x) => s + x.totalPaid, 0);
  const outstanding = standings.reduce((s, x) => s + x.outstanding, 0);
  const schemeName = (id: string) =>
    snapshot.schemes.find((s) => s.id === id)?.name ?? "Unknown scheme";

  async function setStatus(status: "active" | "archived") {
    setBusy(true);
    try {
      await run((repo, actor) => repo.setMemberStatus(member!.id, status, actor));
      toast.success(status === "archived" ? "Member archived." : "Member restored.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not update the member.");
    } finally {
      setBusy(false);
    }
  }

  function openWhatsApp() {
    const pendingStanding = standings.find((s) => s.outstanding > 0);
    if (!pendingStanding) {
      toast.info(`${member!.fullName} has nothing outstanding.`);
      return;
    }
    const firstPending = pendingStanding.pendingPeriods[0] ?? period;
    const message = renderReminder(snapshot.settings.reminderTemplate, {
      memberName: member!.fullName,
      amount: money(pendingStanding.outstanding, currency),
      month: monthLabel(firstPending),
      organizationName: snapshot.settings.organizationName,
      schemeName: pendingStanding.schemeName,
    });

    window.open(
      `https://wa.me/${waNumber(member!.phone)}?text=${encodeURIComponent(message)}`,
      "_blank",
      "noopener,noreferrer",
    );

    void run((repo) =>
      repo.logReminder({
        memberId: member!.id,
        schemeId: pendingStanding.schemeId,
        period: firstPending,
        amount: pendingStanding.outstanding,
        channel: "whatsapp",
        message,
        openedAt: new Date().toISOString(),
        actorUid: user?.id ?? "",
        actorName: user?.name ?? "",
      }),
    ).catch(() => undefined);

    toast.info("WhatsApp opened with the message ready to send.");
  }

  return (
    <>
      <PageHeader
        title={member.fullName}
        subtitle={`${member.memberCode} · ${member.phone} · joined ${dateLabel(member.joiningDate)}`}
        actions={
          <>
            {can("payment:create") ? (
              <LinkButton
                href={`/payments/new?member=${member.id}`}
                icon={<BadgeIndianRupee className="h-4 w-4" aria-hidden />}
              >
                Record payment
              </LinkButton>
            ) : null}
            {outstanding > 0 && can("reminder:send") ? (
              <Button
                variant="success"
                onClick={openWhatsApp}
                icon={<MessageCircle className="h-4 w-4" aria-hidden />}
              >
                WhatsApp reminder
              </Button>
            ) : null}
            {can("member:write") ? (
              <>
                <LinkButton
                  href={`/members/${member.id}/edit`}
                  variant="secondary"
                  icon={<Pencil className="h-4 w-4" aria-hidden />}
                >
                  Edit
                </LinkButton>
                {member.status === "archived" ? (
                  <Button
                    variant="secondary"
                    loading={busy}
                    onClick={() => void setStatus("active")}
                    icon={<RotateCcw className="h-4 w-4" aria-hidden />}
                  >
                    Restore
                  </Button>
                ) : (
                  <Button
                    variant="secondary"
                    loading={busy}
                    onClick={() => void setStatus("archived")}
                    icon={<Archive className="h-4 w-4" aria-hidden />}
                  >
                    Archive
                  </Button>
                )}
              </>
            ) : null}
          </>
        }
      />

      {member.status === "archived" ? (
        <div className="mb-5">
          <Alert tone="warning" title="This member is archived">
            They are excluded from pending lists and reminders. Every payment they have made is
            kept and still appears in reports.
          </Alert>
        </div>
      ) : null}

      <div className="grid gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <div className="grid gap-4 sm:grid-cols-3">
            <Card>
              <p className="text-sm text-slate-500">Total paid</p>
              <p className="tabular mt-1 text-2xl font-semibold text-forest-700">
                {money(totalPaid, currency)}
              </p>
              <p className="mt-1 text-xs text-slate-500">
                {payments.length} payment{payments.length === 1 ? "" : "s"}
              </p>
            </Card>
            <Card>
              <p className="text-sm text-slate-500">Outstanding balance</p>
              <p className="tabular mt-1 text-2xl font-semibold text-red-600">
                {money(outstanding, currency)}
              </p>
              <p className="mt-1 text-xs text-slate-500">For months already due</p>
            </Card>
            <Card>
              <p className="text-sm text-slate-500">Schemes</p>
              <p className="mt-1 text-2xl font-semibold text-navy-900">{standings.length}</p>
              <p className="mt-1 text-xs text-slate-500">Active assignments</p>
            </Card>
          </div>

          <Card padded={false}>
            <div className="p-5 pb-0">
              <CardHeader title="Scheme standing" subtitle="Per scheme, as of this month" />
            </div>
            {standings.length === 0 ? (
              <div className="p-5 pt-0">
                <EmptyState
                  title="Not assigned to any scheme"
                  message="Assign this member to a Kuri scheme to start recording contributions."
                  action={
                    can("scheme:write") ? (
                      <LinkButton href="/schemes" size="sm" variant="secondary">
                        Go to schemes
                      </LinkButton>
                    ) : null
                  }
                />
              </div>
            ) : (
              <Table>
                <thead>
                  <tr>
                    <Th>Scheme</Th>
                    <Th align="right">Monthly</Th>
                    <Th align="center">Months due</Th>
                    <Th align="right">Paid</Th>
                    <Th align="right">Outstanding</Th>
                    <Th>Pending months</Th>
                  </tr>
                </thead>
                <tbody>
                  {standings.map((st) => (
                    <Tr key={st.schemeId}>
                      <Td>
                        <Link
                          href={`/schemes/${st.schemeId}`}
                          className="font-medium hover:underline"
                        >
                          {st.schemeName}
                        </Link>
                      </Td>
                      <Td align="right" className="tabular text-slate-600">
                        {money(st.monthlyAmount, currency)}
                      </Td>
                      <Td align="center" className="tabular text-slate-600">
                        {st.periodsDue}
                      </Td>
                      <Td align="right" className="tabular font-medium text-forest-700">
                        {money(st.totalPaid, currency)}
                      </Td>
                      <Td align="right" className="tabular font-medium">
                        {st.outstanding > 0 ? (
                          <span className="text-red-600">{money(st.outstanding, currency)}</span>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </Td>
                      <Td>
                        {st.pendingPeriods.length === 0 ? (
                          <Badge tone="success">Up to date</Badge>
                        ) : (
                          <span className="flex flex-wrap gap-1">
                            {st.pendingPeriods.slice(0, 4).map((p) => (
                              <Badge key={p} tone="warning">
                                {monthLabel(p)}
                              </Badge>
                            ))}
                            {st.pendingPeriods.length > 4 ? (
                              <Badge>+{st.pendingPeriods.length - 4} more</Badge>
                            ) : null}
                          </span>
                        )}
                      </Td>
                    </Tr>
                  ))}
                </tbody>
              </Table>
            )}
          </Card>

          <Card padded={false}>
            <div className="p-5 pb-0">
              <CardHeader
                title="Payment history"
                subtitle="Every contribution recorded for this member"
                action={
                  <ExportBar
                    rows={payments}
                    columns={[
                      { header: "Receipt", value: (p) => p.receiptNo },
                      { header: "Scheme", value: (p) => schemeName(p.schemeId) },
                      { header: "Month", value: (p) => p.period },
                      { header: "Amount (₹)", value: (p) => p.amount, align: "right" },
                      { header: "Paid on", value: (p) => p.paidOn },
                      { header: "Method", value: (p) => PAYMENT_METHOD_LABEL[p.method] },
                      { header: "Received by", value: (p) => p.receivedBy },
                      { header: "Reference", value: (p) => p.referenceNo },
                      { header: "Recorded by", value: (p) => p.createdByName },
                    ]}
                    filename={stamp(`member-${member.memberCode}-payments`)}
                    title={`${member.fullName} — payment history`}
                    organization={snapshot.settings.organizationName}
                  />
                }
              />
            </div>
            {payments.length === 0 ? (
              <div className="p-5 pt-0">
                <EmptyState
                  title="No payments recorded"
                  message="Nothing has been collected from this member yet."
                  action={
                    can("payment:create") ? (
                      <LinkButton href={`/payments/new?member=${member.id}`} size="sm">
                        Record a payment
                      </LinkButton>
                    ) : null
                  }
                />
              </div>
            ) : (
              <Table>
                <thead>
                  <tr>
                    <Th>Receipt</Th>
                    <Th>Scheme</Th>
                    <Th>Month</Th>
                    <Th align="right">Amount</Th>
                    <Th>Paid on</Th>
                    <Th>Method</Th>
                    <Th />
                  </tr>
                </thead>
                <tbody>
                  {payments.map((p) => (
                    <Tr key={p.id}>
                      <Td>
                        <Link
                          href={`/payments/${p.id}/receipt`}
                          className="font-medium hover:underline"
                        >
                          {p.receiptNo}
                        </Link>
                        {p.corrected ? (
                          <Badge tone="warning" className="ml-2">
                            Corrected
                          </Badge>
                        ) : null}
                      </Td>
                      <Td className="text-slate-600">{schemeName(p.schemeId)}</Td>
                      <Td className="whitespace-nowrap text-slate-600">{monthLabel(p.period)}</Td>
                      <Td align="right" className="tabular font-medium">
                        {money(p.amount, currency)}
                      </Td>
                      <Td className="whitespace-nowrap text-slate-600">{dateLabel(p.paidOn)}</Td>
                      <Td className="text-slate-600">{PAYMENT_METHOD_LABEL[p.method]}</Td>
                      <Td align="right">
                        <Link
                          href={`/payments/${p.id}/receipt`}
                          className="text-sm font-medium text-navy-700 hover:underline"
                        >
                          Receipt
                        </Link>
                      </Td>
                    </Tr>
                  ))}
                </tbody>
              </Table>
            )}
          </Card>
        </div>

        <div className="space-y-5">
          <Card>
            <CardHeader title="Member details" />
            <dl className="space-y-3 text-sm">
              <div>
                <dt className="text-slate-500">Member ID</dt>
                <dd className="font-medium">{member.memberCode}</dd>
              </div>
              <div>
                <dt className="text-slate-500">Phone</dt>
                <dd className="font-medium">{member.phone}</dd>
              </div>
              <div>
                <dt className="text-slate-500">Address</dt>
                <dd className="whitespace-pre-line font-medium">{member.address || "—"}</dd>
              </div>
              <div>
                <dt className="text-slate-500">Joining date</dt>
                <dd className="font-medium">{dateLabel(member.joiningDate)}</dd>
              </div>
              <div>
                <dt className="text-slate-500">Status</dt>
                <dd>
                  <Badge
                    tone={
                      member.status === "active"
                        ? "success"
                        : member.status === "inactive"
                          ? "warning"
                          : "neutral"
                    }
                  >
                    {member.status.charAt(0).toUpperCase() + member.status.slice(1)}
                  </Badge>
                </dd>
              </div>
              {member.notes ? (
                <div>
                  <dt className="text-slate-500">Notes</dt>
                  <dd className="whitespace-pre-line">{member.notes}</dd>
                </div>
              ) : null}
            </dl>
          </Card>
        </div>
      </div>
    </>
  );
}
