"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { BadgeIndianRupee, Info } from "lucide-react";

import {
  Alert,
  Button,
  Card,
  CardHeader,
  Field,
  Input,
  PageHeader,
  Select,
  Textarea,
} from "@/components/ui";
import { useToast } from "@/components/ui/Toast";
import { NoAccess } from "@/components/NoAccess";
import { useData } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import { currentPeriod, money, monthLabel, todayISO } from "@/lib/format";
import { buildLedgerIndex, duePeriods, schemeDueDate } from "@/lib/kuri";
import { PAYMENT_METHODS, PAYMENT_METHOD_LABEL, type PaymentMethod } from "@/lib/types";

export default function NewPaymentPage() {
  const router = useRouter();
  const search = useSearchParams();
  const toast = useToast();
  const { snapshot, run } = useData();
  const { can, user } = useAuth();

  const period = currentPeriod();
  const currency = snapshot.settings.currencySymbol;

  const [memberId, setMemberId] = useState(search.get("member") ?? "");
  const [schemeId, setSchemeId] = useState(search.get("scheme") ?? "");
  const [payPeriod, setPayPeriod] = useState("");
  const [amount, setAmount] = useState("");
  const [paidOn, setPaidOn] = useState(todayISO());
  const [method, setMethod] = useState<PaymentMethod>("cash");
  const [receivedBy, setReceivedBy] = useState(user?.name ?? "");
  const [referenceNo, setReferenceNo] = useState("");
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);

  const index = useMemo(() => buildLedgerIndex(snapshot.ledgers), [snapshot.ledgers]);

  const activeMembers = useMemo(
    () =>
      snapshot.members
        .filter((m) => m.status === "active")
        .sort((a, b) => a.fullName.localeCompare(b.fullName)),
    [snapshot.members],
  );

  /** Schemes the chosen member actually belongs to. */
  const memberSchemes = useMemo(() => {
    if (!memberId) return [];
    const ids = new Set(
      snapshot.memberships
        .filter((ms) => ms.memberId === memberId && ms.active)
        .map((ms) => ms.schemeId),
    );
    return snapshot.schemes.filter((s) => ids.has(s.id) && s.status !== "archived");
  }, [memberId, snapshot.memberships, snapshot.schemes]);

  const scheme = memberSchemes.find((s) => s.id === schemeId);
  const membership = snapshot.memberships.find(
    (ms) => ms.memberId === memberId && ms.schemeId === schemeId && ms.active,
  );

  /** Months already due for this member in this scheme, with what is left. */
  const openPeriods = useMemo(() => {
    if (!scheme || !membership) return [];
    return duePeriods(scheme, period)
      .filter((p) => p >= membership.joinedAt.slice(0, 7))
      .map((p) => {
        const paid = index.get(scheme.id, memberId, p)?.paidAmount ?? 0;
        return { period: p, paid, remaining: scheme.monthlyAmount - paid };
      })
      .filter((row) => row.remaining > 0);
  }, [scheme, membership, period, index, memberId]);

  // Keep the scheme valid for the chosen member.
  useEffect(() => {
    if (memberSchemes.length === 1 && !schemeId) setSchemeId(memberSchemes[0]!.id);
    if (schemeId && !memberSchemes.some((s) => s.id === schemeId)) setSchemeId("");
  }, [memberSchemes, schemeId]);

  // Default to the oldest unpaid month and its outstanding amount.
  useEffect(() => {
    if (openPeriods.length === 0) {
      setPayPeriod("");
      setAmount("");
      return;
    }
    const first = openPeriods[0]!;
    setPayPeriod((prev) =>
      prev && openPeriods.some((p) => p.period === prev) ? prev : first.period,
    );
  }, [openPeriods]);

  useEffect(() => {
    const row = openPeriods.find((p) => p.period === payPeriod);
    if (row) setAmount(String(row.remaining));
  }, [payPeriod, openPeriods]);

  if (!can("payment:create")) return <NoAccess what="record payments" />;

  const selectedRow = openPeriods.find((p) => p.period === payPeriod);
  const member = snapshot.members.find((m) => m.id === memberId);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const created = await run((repo, actor) =>
        repo.recordPayment(
          {
            memberId,
            schemeId,
            period: payPeriod,
            amount: Number(amount),
            paidOn,
            method,
            receivedBy,
            referenceNo,
            notes,
          },
          actor,
        ),
      );
      toast.success(
        `${money(created.amount, currency)} recorded for ${member?.fullName ?? "the member"} (${monthLabel(
          created.period,
        )}). Receipt ${created.receiptNo}.`,
      );
      router.push(`/payments/${created.id}/receipt`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not record the payment.");
    } finally {
      setBusy(false);
    }
  }

  const canSubmit =
    Boolean(memberId && schemeId && payPeriod && amount && paidOn && receivedBy.trim()) &&
    Number(amount) > 0;

  return (
    <>
      <PageHeader
        title="Record Payment"
        subtitle="Enter a contribution that has actually been received. Nothing is ever marked paid automatically."
      />

      <form onSubmit={onSubmit} className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Payment entry" />

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Member" required className="sm:col-span-2">
              <Select
                value={memberId}
                onChange={(e) => {
                  setMemberId(e.target.value);
                  setSchemeId("");
                }}
                required
              >
                <option value="">Select a member</option>
                {activeMembers.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.fullName} — {m.memberCode} ({m.phone})
                  </option>
                ))}
              </Select>
            </Field>

            <Field
              label="Kuri scheme"
              required
              hint={
                memberId && memberSchemes.length === 0
                  ? "This member is not assigned to any active scheme."
                  : undefined
              }
            >
              <Select
                value={schemeId}
                onChange={(e) => setSchemeId(e.target.value)}
                required
                disabled={!memberId || memberSchemes.length === 0}
              >
                <option value="">Select a scheme</option>
                {memberSchemes.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} — {money(s.monthlyAmount, currency)}/month
                  </option>
                ))}
              </Select>
            </Field>

            <Field
              label="Payment month"
              required
              hint={
                scheme && openPeriods.length === 0
                  ? "Every month due so far is fully paid."
                  : "Only months that are due and still open are listed."
              }
            >
              <Select
                value={payPeriod}
                onChange={(e) => setPayPeriod(e.target.value)}
                required
                disabled={!scheme || openPeriods.length === 0}
              >
                <option value="">Select a month</option>
                {openPeriods.map((row) => (
                  <option key={row.period} value={row.period}>
                    {monthLabel(row.period)} — {money(row.remaining, currency)} outstanding
                  </option>
                ))}
              </Select>
            </Field>

            <Field
              label={`Amount (${currency})`}
              required
              hint={
                selectedRow
                  ? selectedRow.paid > 0
                    ? `${money(selectedRow.paid, currency)} already collected for this month; ${money(
                        selectedRow.remaining,
                        currency,
                      )} is outstanding.`
                    : `Full contribution is ${money(selectedRow.remaining, currency)}.`
                  : undefined
              }
            >
              <Input
                type="number"
                min={1}
                step={1}
                max={selectedRow?.remaining}
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
                className="tabular"
              />
            </Field>

            <Field label="Payment date" required hint="The date the money was received.">
              <Input
                type="date"
                value={paidOn}
                onChange={(e) => setPaidOn(e.target.value)}
                max={todayISO()}
                required
              />
            </Field>

            <Field label="Payment method" required>
              <Select
                value={method}
                onChange={(e) => setMethod(e.target.value as PaymentMethod)}
                required
              >
                {PAYMENT_METHODS.map((m) => (
                  <option key={m} value={m}>
                    {PAYMENT_METHOD_LABEL[m]}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="Received by" required hint="Who physically took the money.">
              <Input
                value={receivedBy}
                onChange={(e) => setReceivedBy(e.target.value)}
                required
                placeholder="e.g. Treasurer name"
              />
            </Field>

            <Field
              label="Reference number"
              hint="Receipt book number, UPI reference, cheque number — optional."
            >
              <Input value={referenceNo} onChange={(e) => setReferenceNo(e.target.value)} />
            </Field>

            <Field label="Notes" className="sm:col-span-2">
              <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
            </Field>
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            <Button
              type="submit"
              loading={busy}
              disabled={!canSubmit}
              icon={<BadgeIndianRupee className="h-4 w-4" aria-hidden />}
            >
              Record payment
            </Button>
            <Button type="button" variant="secondary" onClick={() => router.back()}>
              Cancel
            </Button>
          </div>
        </Card>

        <div className="space-y-5">
          <Card>
            <CardHeader title="What will be recorded" />
            {!memberId || !scheme || !payPeriod ? (
              <p className="text-sm text-slate-500">
                Choose a member, scheme and month to see the entry summary.
              </p>
            ) : (
              <dl className="space-y-3 text-sm">
                <div className="flex justify-between gap-3">
                  <dt className="text-slate-500">Member</dt>
                  <dd className="text-right font-medium">{member?.fullName}</dd>
                </div>
                <div className="flex justify-between gap-3">
                  <dt className="text-slate-500">Scheme</dt>
                  <dd className="text-right font-medium">{scheme.name}</dd>
                </div>
                <div className="flex justify-between gap-3">
                  <dt className="text-slate-500">Contribution month</dt>
                  <dd className="text-right font-medium">{monthLabel(payPeriod)}</dd>
                </div>
                <div className="flex justify-between gap-3">
                  <dt className="text-slate-500">Due date</dt>
                  <dd className="text-right font-medium">{schemeDueDate(scheme, payPeriod)}</dd>
                </div>
                <div className="flex justify-between gap-3 border-t border-slate-100 pt-3">
                  <dt className="text-slate-500">Amount</dt>
                  <dd className="tabular text-right text-base font-semibold text-forest-700">
                    {money(Number(amount) || 0, currency)}
                  </dd>
                </div>
                {selectedRow && Number(amount) < selectedRow.remaining ? (
                  <div className="flex justify-between gap-3">
                    <dt className="text-slate-500">Still outstanding after this</dt>
                    <dd className="tabular text-right font-medium text-amber-700">
                      {money(selectedRow.remaining - (Number(amount) || 0), currency)}
                    </dd>
                  </div>
                ) : null}
              </dl>
            )}
          </Card>

          <Card>
            <div className="flex gap-3">
              <Info className="mt-0.5 h-5 w-5 shrink-0 text-navy-500" aria-hidden />
              <div className="text-sm leading-relaxed text-slate-600">
                <p className="font-medium text-navy-900">Safeguards on this form</p>
                <ul className="mt-2 space-y-1.5 list-disc pl-4">
                  <li>A month already paid in full cannot be paid again.</li>
                  <li>The amount cannot exceed what is outstanding for the month.</li>
                  <li>A month outside the scheme, or before the member joined, is rejected.</li>
                  <li>
                    Your name and the time are stored with the record, and any later correction
                    keeps the original figures in the audit history.
                  </li>
                </ul>
              </div>
            </div>
          </Card>

          {memberId && memberSchemes.length === 0 ? (
            <Alert tone="warning" title="No scheme to pay into">
              Assign this member to an active Kuri scheme before recording a payment.
            </Alert>
          ) : null}
        </div>
      </form>
    </>
  );
}
