"use client";

import { useMemo } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { ArrowLeft, Pencil, Printer } from "lucide-react";

import { Badge, Button, Card, LinkButton, Table, Td, Th, Tr } from "@/components/ui";
import { BRAND_NAME, BrandMark } from "@/components/ui/BrandMark";
import { NotFoundCard } from "@/components/NoAccess";
import { useData } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import { dateLabel, dateTimeLabel, money, monthLabelLong } from "@/lib/format";
import { PAYMENT_METHOD_LABEL } from "@/lib/types";

export default function ReceiptPage() {
  const params = useParams<{ id: string }>();
  const { snapshot } = useData();
  const { can } = useAuth();
  const currency = snapshot.settings.currencySymbol;

  const payment = snapshot.payments.find((p) => p.id === params.id);
  const member = snapshot.members.find((m) => m.id === payment?.memberId);
  const scheme = snapshot.schemes.find((s) => s.id === payment?.schemeId);

  const history = useMemo(
    () =>
      snapshot.auditLogs
        .filter((l) => l.paymentId === params.id)
        .sort((a, b) => b.at.localeCompare(a.at)),
    [snapshot.auditLogs, params.id],
  );

  if (!payment) {
    return (
      <NotFoundCard
        title="Payment not found"
        message="This payment record may have been removed, or the link is out of date."
        backHref="/history"
        backLabel="Back to payment history"
      />
    );
  }

  const s = snapshot.settings;

  return (
    <>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3 print:hidden">
        <Link
          href="/history"
          className="inline-flex items-center gap-2 text-sm font-medium text-navy-700 hover:underline"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden />
          Payment history
        </Link>
        <div className="flex flex-wrap gap-2">
          {can("payment:edit") ? (
            <LinkButton
              href={`/payments/${payment.id}/edit`}
              variant="secondary"
              icon={<Pencil className="h-4 w-4" aria-hidden />}
            >
              Correct this payment
            </LinkButton>
          ) : null}
          <Button onClick={() => window.print()} icon={<Printer className="h-4 w-4" aria-hidden />}>
            Print receipt
          </Button>
        </div>
      </div>

      <Card className="mx-auto max-w-2xl print-flat">
        <div className="flex items-start justify-between gap-4 border-b border-slate-200 pb-5">
          <div className="flex items-start gap-3">
            <BrandMark logoDataUrl={s.logoDataUrl} size="lg" />
            <div>
              <p className="text-lg font-semibold text-navy-900">
                {s.organizationName || BRAND_NAME}
              </p>
              {s.address ? (
                <p className="whitespace-pre-line text-xs text-slate-500">{s.address}</p>
              ) : null}
              {s.contactPhone || s.contactEmail ? (
                <p className="text-xs text-slate-500">
                  {[s.contactPhone, s.contactEmail].filter(Boolean).join(" · ")}
                </p>
              ) : null}
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
              Payment receipt
            </p>
            <p className="text-lg font-semibold text-navy-900">{payment.receiptNo}</p>
            <p className="text-xs text-slate-500">{dateLabel(payment.paidOn)}</p>
          </div>
        </div>

        <dl className="grid gap-4 py-5 sm:grid-cols-2">
          <div>
            <dt className="text-xs uppercase tracking-wide text-slate-500">Received from</dt>
            <dd className="font-medium text-navy-900">{member?.fullName ?? "Unknown member"}</dd>
            <dd className="text-sm text-slate-500">
              {member?.memberCode}
              {member?.phone ? ` · ${member.phone}` : ""}
            </dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-slate-500">Kuri scheme</dt>
            <dd className="font-medium text-navy-900">{scheme?.name ?? "Unknown scheme"}</dd>
            <dd className="text-sm text-slate-500">
              {scheme ? `${money(scheme.monthlyAmount, currency)} a month` : ""}
            </dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-slate-500">Contribution month</dt>
            <dd className="font-medium text-navy-900">{monthLabelLong(payment.period)}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-slate-500">Payment method</dt>
            <dd className="font-medium text-navy-900">
              {PAYMENT_METHOD_LABEL[payment.method]}
              {payment.referenceNo ? ` · ${payment.referenceNo}` : ""}
            </dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-slate-500">Received by</dt>
            <dd className="font-medium text-navy-900">{payment.receivedBy}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-slate-500">Recorded by</dt>
            <dd className="font-medium text-navy-900">{payment.createdByName}</dd>
            <dd className="text-sm text-slate-500">{dateTimeLabel(payment.createdAt)}</dd>
          </div>
        </dl>

        <div className="flex items-center justify-between gap-4 rounded-lg bg-navy-50 px-5 py-4">
          <p className="text-sm font-medium text-navy-800">Amount received</p>
          <p className="tabular text-2xl font-semibold text-navy-900">
            {money(payment.amount, currency)}
          </p>
        </div>

        {payment.notes ? (
          <p className="mt-4 whitespace-pre-line text-sm text-slate-600">
            <span className="font-medium text-navy-900">Notes: </span>
            {payment.notes}
          </p>
        ) : null}

        {payment.corrected ? (
          <p className="mt-4 text-xs text-amber-700">
            This record has been corrected. The original figures are preserved in the audit history
            below.
          </p>
        ) : null}

        <p className="mt-6 border-t border-slate-200 pt-4 text-center text-xs text-slate-400">
          Computer-generated receipt · {s.organizationName || BRAND_NAME}
        </p>
      </Card>

      <Card className="mx-auto mt-5 max-w-2xl print:hidden" padded={false}>
        <div className="p-5 pb-2">
          <h2 className="text-base font-semibold text-navy-900">Audit history</h2>
          <p className="mt-0.5 text-sm text-slate-500">
            Every change to this payment, with who made it and why.
          </p>
        </div>
        <Table>
          <thead>
            <tr>
              <Th>When</Th>
              <Th>Action</Th>
              <Th align="right">Amount</Th>
              <Th>By</Th>
              <Th>Reason</Th>
            </tr>
          </thead>
          <tbody>
            {history.map((log) => (
              <Tr key={log.id}>
                <Td className="whitespace-nowrap text-slate-600">{dateTimeLabel(log.at)}</Td>
                <Td>
                  <Badge tone={log.action === "create" ? "success" : "warning"}>
                    {log.action === "create" ? "Recorded" : "Corrected"}
                  </Badge>
                </Td>
                <Td align="right" className="tabular">
                  {log.before && log.before.amount !== log.after.amount ? (
                    <>
                      <span className="text-slate-400 line-through">
                        {money(Number(log.before.amount ?? 0), currency)}
                      </span>{" "}
                      <span className="font-medium">
                        {money(Number(log.after.amount ?? 0), currency)}
                      </span>
                    </>
                  ) : (
                    money(Number(log.after.amount ?? 0), currency)
                  )}
                </Td>
                <Td className="text-slate-600">{log.actorName}</Td>
                <Td className="text-slate-600">{log.reason}</Td>
              </Tr>
            ))}
          </tbody>
        </Table>
      </Card>
    </>
  );
}
