"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";

import {
  Alert,
  Button,
  Card,
  CardHeader,
  Field,
  Input,
  PageHeader,
  Select,
  Textarea,
} from "@/components/ui";
import { useToast } from "@/components/ui/Toast";
import { NoAccess, NotFoundCard } from "@/components/NoAccess";
import { useData } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import { dateTimeLabel, money, monthLabelLong, todayISO } from "@/lib/format";
import { PAYMENT_METHODS, PAYMENT_METHOD_LABEL, type PaymentMethod } from "@/lib/types";

/**
 * Correcting a payment. The record is never replaced silently: the previous
 * values and the reason are written to the audit log, and the period ledger is
 * adjusted in the same transaction.
 */
export default function EditPaymentPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const toast = useToast();
  const { snapshot, run } = useData();
  const { can } = useAuth();
  const currency = snapshot.settings.currencySymbol;

  const payment = snapshot.payments.find((p) => p.id === params.id);
  const member = snapshot.members.find((m) => m.id === payment?.memberId);
  const scheme = snapshot.schemes.find((s) => s.id === payment?.schemeId);

  const [amount, setAmount] = useState(String(payment?.amount ?? ""));
  const [paidOn, setPaidOn] = useState(payment?.paidOn ?? todayISO());
  const [method, setMethod] = useState<PaymentMethod>(payment?.method ?? "cash");
  const [receivedBy, setReceivedBy] = useState(payment?.receivedBy ?? "");
  const [referenceNo, setReferenceNo] = useState(payment?.referenceNo ?? "");
  const [notes, setNotes] = useState(payment?.notes ?? "");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);

  if (!can("payment:edit")) return <NoAccess what="correct payments" />;
  if (!payment) {
    return (
      <NotFoundCard
        title="Payment not found"
        message="This payment record may have been removed, or the link is out of date."
        backHref="/history"
        backLabel="Back to payment history"
      />
    );
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await run((repo, actor) =>
        repo.editPayment(
          payment!.id,
          {
            amount: Number(amount),
            paidOn,
            method,
            receivedBy,
            referenceNo,
            notes,
            reason,
          },
          actor,
        ),
      );
      toast.success("Payment corrected. The original figures are kept in the audit history.");
      router.push(`/payments/${payment!.id}/receipt`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not correct the payment.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <PageHeader
        title={`Correct payment ${payment.receiptNo}`}
        subtitle={`${member?.fullName ?? "Unknown member"} · ${
          scheme?.name ?? "Unknown scheme"
        } · ${monthLabelLong(payment.period)}`}
      />

      <div className="mb-5">
        <Alert tone="warning" title="This is a correction, not a new payment">
          The member, scheme and contribution month cannot be changed here — that would move money
          between periods. If the payment was entered against the wrong member or month, correct
          the amount to the true figure and record the payment again in the right place, noting
          both in the reason.
        </Alert>
      </div>

      <form onSubmit={onSubmit} className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Corrected values" />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field
              label={`Amount (${currency})`}
              required
              hint={scheme ? `Monthly contribution is ${money(scheme.monthlyAmount, currency)}.` : undefined}
            >
              <Input
                type="number"
                min={1}
                step={1}
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
                className="tabular"
              />
            </Field>

            <Field label="Payment date" required>
              <Input
                type="date"
                value={paidOn}
                onChange={(e) => setPaidOn(e.target.value)}
                max={todayISO()}
                required
              />
            </Field>

            <Field label="Payment method" required>
              <Select
                value={method}
                onChange={(e) => setMethod(e.target.value as PaymentMethod)}
                required
              >
                {PAYMENT_METHODS.map((m) => (
                  <option key={m} value={m}>
                    {PAYMENT_METHOD_LABEL[m]}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="Received by" required>
              <Input
                value={receivedBy}
                onChange={(e) => setReceivedBy(e.target.value)}
                required
              />
            </Field>

            <Field label="Reference number">
              <Input value={referenceNo} onChange={(e) => setReferenceNo(e.target.value)} />
            </Field>

            <Field label="Notes" className="sm:col-span-2">
              <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
            </Field>

            <Field
              label="Reason for the correction"
              required
              hint="Stored permanently in the audit history."
              className="sm:col-span-2"
            >
              <Textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                required
                placeholder="e.g. Amount entered as ₹5,000 but ₹4,000 was received; counted again at the meeting."
              />
            </Field>
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            <Button type="submit" loading={busy} disabled={reason.trim().length < 3}>
              Save correction
            </Button>
            <Button type="button" variant="secondary" onClick={() => router.back()}>
              Cancel
            </Button>
          </div>
        </Card>

        <Card>
          <CardHeader title="Current record" subtitle="What is stored right now" />
          <dl className="space-y-3 text-sm">
            <div className="flex justify-between gap-3">
              <dt className="text-slate-500">Amount</dt>
              <dd className="tabular font-medium">{money(payment.amount, currency)}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-slate-500">Paid on</dt>
              <dd className="font-medium">{payment.paidOn}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-slate-500">Method</dt>
              <dd className="font-medium">{PAYMENT_METHOD_LABEL[payment.method]}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-slate-500">Recorded by</dt>
              <dd className="text-right font-medium">{payment.createdByName}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-slate-500">Recorded at</dt>
              <dd className="text-right font-medium">{dateTimeLabel(payment.createdAt)}</dd>
            </div>
            {payment.updatedAt ? (
              <div className="flex justify-between gap-3 border-t border-slate-100 pt-3">
                <dt className="text-slate-500">Last corrected</dt>
                <dd className="text-right font-medium">
                  {dateTimeLabel(payment.updatedAt)}
                  <span className="block text-xs text-slate-500">
                    by {payment.updatedByName}
                  </span>
                </dd>
              </div>
            ) : null}
          </dl>
        </Card>
      </form>
    </>
  );
}
