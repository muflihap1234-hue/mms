"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { BadgeIndianRupee, CheckCircle2, Clock, Plus } from "lucide-react";

import {
  Badge,
  Card,
  CardHeader,
  EmptyState,
  Input,
  LinkButton,
  PageHeader,
  Select,
  Table,
  Td,
  Th,
  Tr,
} from "@/components/ui";
import { ExportBar } from "@/components/ExportBar";
import { useData } from "@/lib/DataProvider";
import { useAuth } from "@/lib/auth/AuthProvider";
import { currentPeriod, money, monthLabel, monthLabelLong } from "@/lib/format";
import { buildLedgerIndex, schemeDueDate, schemePeriods } from "@/lib/kuri";
import { stamp } from "@/lib/export";

/**
 * The collection sheet: one scheme, one month, every member's state. This is
 * the screen a treasurer works from while collecting cash.
 */
export default function PaymentsPage() {
  const { snapshot } = useData();
  const { can } = useAuth();
  const period = currentPeriod();
  const currency = snapshot.settings.currencySymbol;

  const openSchemes = useMemo(
    () => snapshot.schemes.filter((s) => s.status !== "archived"),
    [snapshot.schemes],
  );

  const [schemeId, setSchemeId] = useState(openSchemes[0]?.id ?? "");
  const [month, setMonth] = useState(period);
  const [term, setTerm] = useState("");

  const scheme = openSchemes.find((s) => s.id === schemeId) ?? openSchemes[0];
  const index = useMemo(() => buildLedgerIndex(snapshot.ledgers), [snapshot.ledgers]);

  const months = useMemo(() => (scheme ? schemePeriods(scheme) : []), [scheme]);

  const rows = useMemo(() => {
    if (!scheme) return [];
    const q = term.trim().toLowerCase();
    return snapshot.memberships
      .filter((ms) => ms.schemeId === scheme.id && ms.active)
      .map((ms) => {
        const member = snapshot.members.find((m) => m.id === ms.memberId);
        const paid = index.get(scheme.id, ms.memberId, month)?.paidAmount ?? 0;
        const liable = ms.joinedAt.slice(0, 7) <= month;
        return {
          memberId: ms.memberId,
          name: member?.fullName ?? "Unknown member",
          code: member?.memberCode ?? "—",
          phone: member?.phone ?? "",
          paid,
          liable,
          remaining: liable ? Math.max(0, scheme.monthlyAmount - paid) : 0,
        };
      })
      .filter((r) =>
        q ? r.name.toLowerCase().includes(q) || r.code.toLowerCase().includes(q) : true,
      )
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [scheme, month, snapshot.memberships, snapshot.members, index, term]);

  const liableRows = rows.filter((r) => r.liable);
  const collected = liableRows.reduce((s, r) => s + r.paid, 0);
  const expected = liableRows.length * (scheme?.monthlyAmount ?? 0);
  const settled = liableRows.filter((r) => r.remaining === 0).length;
  const isFuture = month > period;

  if (openSchemes.length === 0) {
    return (
      <>
        <PageHeader title="Payments" subtitle="Record and track monthly contributions." />
        <Card>
          <EmptyState
            icon={<BadgeIndianRupee className="h-8 w-8" aria-hidden />}
            title="No active scheme"
            message="Create a Kuri scheme and assign members to it before recording payments."
            action={
              can("scheme:write") ? (
                <LinkButton href="/schemes/new" size="sm">
                  Create a scheme
                </LinkButton>
              ) : null
            }
          />
        </Card>
      </>
    );
  }

  return (
    <>
      <PageHeader
        title="Payments"
        subtitle="The collection sheet for one scheme and one month."
        actions={
          can("payment:create") ? (
            <LinkButton href="/payments/new" icon={<Plus className="h-4 w-4" aria-hidden />}>
              Record payment
            </LinkButton>
          ) : null
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card>
          <p className="text-sm text-slate-500">Collected · {monthLabel(month)}</p>
          <p className="tabular mt-1 text-2xl font-semibold text-forest-700">
            {money(collected, currency)}
          </p>
          <p className="mt-1 text-xs text-slate-500">of {money(expected, currency)} expected</p>
        </Card>
        <Card>
          <p className="text-sm text-slate-500">Outstanding</p>
          <p className="tabular mt-1 text-2xl font-semibold text-red-600">
            {money(Math.max(0, expected - collected), currency)}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            {liableRows.length - settled} member(s) still to pay
          </p>
        </Card>
        <Card>
          <p className="text-sm text-slate-500">Settled</p>
          <p className="mt-1 text-2xl font-semibold text-navy-900">
            {settled}
            <span className="text-base font-normal text-slate-400"> / {liableRows.length}</span>
          </p>
          <p className="mt-1 text-xs text-slate-500">Paid in full for this month</p>
        </Card>
        <Card>
          <p className="text-sm text-slate-500">Due date</p>
          <p className="mt-1 text-2xl font-semibold text-navy-900">
            {scheme ? schemeDueDate(scheme, month).slice(-2) : "—"}
            <span className="text-base font-normal text-slate-400">
              {" "}
              {monthLabel(month).split(" ")[0]}
            </span>
          </p>
          <p className="mt-1 text-xs text-slate-500">Day {scheme?.dueDay} each month</p>
        </Card>
      </div>

      <Card className="mt-5" padded={false}>
        <div className="p-5 pb-0">
          <CardHeader
            title={`${scheme?.name ?? ""} — ${monthLabelLong(month)}`}
            subtitle={
              isFuture
                ? "This month has not started yet, so nothing is due."
                : "Record a payment against any member who has not settled."
            }
            action={
              <ExportBar
                rows={rows}
                columns={[
                  { header: "Member ID", value: (r) => r.code },
                  { header: "Name", value: (r) => r.name },
                  { header: "Phone", value: (r) => r.phone },
                  { header: "Paid (₹)", value: (r) => r.paid, align: "right" },
                  { header: "Outstanding (₹)", value: (r) => r.remaining, align: "right" },
                  {
                    header: "Status",
                    value: (r) => (!r.liable ? "Not liable" : r.remaining === 0 ? "Paid" : "Pending"),
                  },
                ]}
                filename={stamp(`collection-${month}`)}
                title={`${scheme?.name ?? "Scheme"} — ${monthLabelLong(month)} collection sheet`}
                organization={snapshot.settings.organizationName}
              />
            }
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 border-y border-slate-200 p-4 print:hidden">
          <Select
            value={scheme?.id ?? ""}
            onChange={(e) => setSchemeId(e.target.value)}
            aria-label="Scheme"
            className="sm:max-w-[16rem]"
          >
            {openSchemes.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
          <Select
            value={month}
            onChange={(e) => setMonth(e.target.value)}
            aria-label="Month"
            className="sm:max-w-[12rem]"
          >
            {months.map((m) => (
              <option key={m} value={m}>
                {monthLabel(m)}
              </option>
            ))}
          </Select>
          <Input
            type="search"
            value={term}
            onChange={(e) => setTerm(e.target.value)}
            placeholder="Find a member"
            aria-label="Find a member"
            className="sm:max-w-xs"
          />
        </div>

        {rows.length === 0 ? (
          <div className="p-5">
            <EmptyState
              title="No members in this scheme"
              message="Assign members to the scheme to build the collection sheet."
              action={
                <LinkButton href={`/schemes/${scheme?.id}`} size="sm" variant="secondary">
                  Open scheme
                </LinkButton>
              }
            />
          </div>
        ) : (
          <Table>
            <thead>
              <tr>
                <Th>Member</Th>
                <Th align="right">Paid</Th>
                <Th align="right">Outstanding</Th>
                <Th>Status</Th>
                <Th />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <Tr key={r.memberId}>
                  <Td>
                    <Link href={`/members/${r.memberId}`} className="font-medium hover:underline">
                      {r.name}
                    </Link>
                    <span className="block text-xs text-slate-500">
                      {r.code} · {r.phone}
                    </span>
                  </Td>
                  <Td align="right" className="tabular font-medium text-forest-700">
                    {r.paid > 0 ? money(r.paid, currency) : <span className="text-slate-400">—</span>}
                  </Td>
                  <Td align="right" className="tabular font-medium">
                    {r.remaining > 0 ? (
                      <span className="text-red-600">{money(r.remaining, currency)}</span>
                    ) : (
                      <span className="text-slate-400">—</span>
                    )}
                  </Td>
                  <Td>
                    {!r.liable ? (
                      <Badge>Not liable yet</Badge>
                    ) : r.remaining === 0 ? (
                      <Badge tone="success">
                        <CheckCircle2 className="mr-1 h-3 w-3" aria-hidden />
                        Paid
                      </Badge>
                    ) : r.paid > 0 ? (
                      <Badge tone="warning">Part paid</Badge>
                    ) : (
                      <Badge tone="warning">
                        <Clock className="mr-1 h-3 w-3" aria-hidden />
                        Pending
                      </Badge>
                    )}
                  </Td>
                  <Td align="right">
                    {r.liable && r.remaining > 0 && can("payment:create") ? (
                      <LinkButton
                        href={`/payments/new?member=${r.memberId}&scheme=${scheme?.id ?? ""}`}
                        size="sm"
                        variant="secondary"
                      >
                        Record
                      </LinkButton>
                    ) : null}
                  </Td>
                </Tr>
              ))}
            </tbody>
          </Table>
        )}
      </Card>
    </>
  );
}
