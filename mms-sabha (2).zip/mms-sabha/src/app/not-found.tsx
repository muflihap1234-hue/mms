import Link from "next/link";

export default function NotFound() {
  return (
    <main className="grid min-h-screen place-items-center bg-slate-50 px-6">
      <div className="max-w-md text-center">
        <p className="text-sm font-semibold uppercase tracking-wide text-slate-400">404</p>
        <h1 className="mt-2 text-2xl font-semibold text-navy-900">Page not found</h1>
        <p className="mt-2 text-sm text-slate-500">
          The page you asked for does not exist in this dashboard.
        </p>
        <Link
          href="/dashboard"
          className="mt-6 inline-flex rounded-lg bg-navy-800 px-4 py-2.5 text-sm font-medium text-white hover:bg-navy-900"
        >
          Back to dashboard
        </Link>
      </div>
    </main>
  );
}
